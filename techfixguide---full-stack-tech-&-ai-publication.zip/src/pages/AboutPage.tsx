import React from 'react';
import { useAppStore } from '../lib/store';
import { ShieldCheck, Award, Terminal, Code2, Users, CheckCircle } from 'lucide-react';

export function AboutPage() {
  const { authors } = useAppStore();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
      {/* Header */}
      <div className="space-y-4">
        <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
          <ShieldCheck className="w-4 h-4" />
          <span>Editorial Constitution</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-black text-[#0b1528] tracking-tight">
          About TechFixGuide
        </h1>
        <p className="text-lg text-[#475569] leading-relaxed">
          Independent, peer-reviewed engineering insights, systems diagnosis, and practical artificial intelligence education.
        </p>
      </div>

      {/* Mission */}
      <div className="editorial-prose">
        <h2>The Core Principle: Learn. Fix. Grow.</h2>
        <p>
          Founded on the conviction that technical documentation should prioritize reproducibility above all else, <strong>TechFixGuide</strong> eliminates developer fatigue. Rather than recycling synthetic AI text or superficial listicles, our mission is to publish battle-tested blueprints that solve tangible engineering hurdles.
        </p>

        <h3>Our Editorial Tenets</h3>
        <ul>
          <li><strong>Zero Hallucinated Code:</strong> Every code snippet, Docker container file, and query optimization plan is tested against real production runtimes prior to publication.</li>
          <li><strong>Explicit Dependencies:</strong> We document exact kernel versions, compiler releases, and package digests to eliminate configuration drift.</li>
          <li><strong>E-E-A-T Compliance:</strong> Guides are written and peer-reviewed by active software architects, systems engineers, and research practitioners.</li>
          <li><strong>Respect for Privacy & Readability:</strong> High-contrast typography, zero deceptive advertising, zero aggressive popups, and WCAG 2.1 AA accessibility.</li>
        </ul>
      </div>

      {/* Editorial Staff Profiles */}
      <div className="space-y-6 pt-6 border-t border-[#e2e8f0]">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-[#0062ff]" />
          <h2 className="text-2xl font-bold text-[#0b1528]">Editorial & Research Staff</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {authors.map((author) => (
            <div
              key={author.id}
              className="rounded-2xl border border-[#e2e8f0] bg-white p-6 space-y-4 shadow-xs"
            >
              <img
                src={author.avatar_url}
                alt={author.full_name}
                className="w-16 h-16 rounded-2xl object-cover border border-[#cbd5e1]"
              />
              <div>
                <h3 className="text-base font-bold text-[#0b1528]">{author.full_name}</h3>
                <span className="text-[11px] font-semibold text-[#0062ff] uppercase tracking-wider">
                  {author.role}
                </span>
              </div>
              <p className="text-xs text-[#64748b] leading-relaxed">
                {author.bio}
              </p>
              {author.twitter_handle && (
                <div className="text-xs text-[#0062ff] font-medium">{author.twitter_handle}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
