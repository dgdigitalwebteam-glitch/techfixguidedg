import React from 'react';
import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
  isLight?: boolean;
}

export function Logo({ className = '', isLight = false }: LogoProps) {
  return (
    <Link to="/" className={`flex items-center gap-3 group select-none ${className}`}>
      {/* Modern TF Emblem with electric blue accent and high-contrast navy */}
      <div className={`relative flex items-center justify-center w-10 h-10 rounded-xl transition-transform duration-300 group-hover:scale-105 shadow-sm ${
        isLight ? 'bg-white text-[#0b1528]' : 'bg-[#0b1528] text-white border border-[#1e2c45]'
      }`}>
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 text-[#0062ff]"
        >
          {/* T bar */}
          <path d="M4 6h16" />
          <path d="M10 6v12" />
          {/* F branch */}
          <path d="M14 11h6" />
        </svg>
        <span className="absolute -bottom-1 -right-1 flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#0062ff] opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#0062ff]"></span>
        </span>
      </div>

      <div className="flex flex-col">
        <span className={`font-black text-xl tracking-tight leading-none ${
          isLight ? 'text-white' : 'text-[#0b1528]'
        }`}>
          TechFix<span className="text-[#0062ff]">Guide</span>
        </span>
        <span className={`text-[10px] uppercase font-semibold tracking-widest mt-1 ${
          isLight ? 'text-slate-400' : 'text-[#64748b]'
        }`}>
          Learn · Fix · Grow
        </span>
      </div>
    </Link>
  );
}
