import React, { useState } from 'react';
import { useAppStore, AppStore } from '../../lib/store';
import { formatDate, exportToCSV } from '../../lib/utils';
import { Mail, Download, Trash2, Plus, Search, CheckCircle2, UserCheck } from 'lucide-react';

export function AdminNewsletterPage() {
  const { subscribers } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [addMessage, setAddMessage] = useState<string | null>(null);

  const filtered = subscribers.filter((s) =>
    s.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddSubscriber = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail || !newEmail.includes('@')) return;

    const res = AppStore.subscribeEmail(newEmail);
    setAddMessage(res.message);
    if (res.success) {
      setNewEmail('');
    }
    setTimeout(() => setAddMessage(null), 3000);
  };

  const handleDelete = (id: string, email: string) => {
    if (confirm(`Remove subscriber ${email}?`)) {
      AppStore.deleteSubscriber(id);
    }
  };

  const handleExportCSV = () => {
    const rows = subscribers.map((s) => ({
      ID: s.id,
      Email: s.email,
      Status: s.is_active ? 'Active' : 'Unsubscribed',
      ConfirmedAt: s.confirmed_at,
      CreatedAt: s.created_at,
    }));
    exportToCSV(`techfixguide-subscribers-${new Date().toISOString().split('T')[0]}.csv`, rows);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
            Newsletter Subscribers
          </h1>
          <p className="text-xs text-[#64748b]">
            Manage verified audience members and export subscriber lists for email dispatching.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="inline-flex items-center gap-2 rounded-xl bg-[#0b1528] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#152238] shadow-xs"
        >
          <Download className="w-4 h-4 text-[#0062ff]" />
          Export Subscribers CSV
        </button>
      </div>

      {/* Manual Add & Search Header */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Manual Add Card */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#0b1528]">
            <Plus className="w-4 h-4 text-[#0062ff]" />
            <span>Manually Register Subscriber</span>
          </div>

          <form onSubmit={handleAddSubscriber} className="space-y-3">
            <input
              type="email"
              required
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="lead.architect@company.com"
              className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
            />
            <button
              type="submit"
              className="w-full rounded-xl bg-[#0062ff] py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] transition-all"
            >
              Add to Audience Database
            </button>
          </form>

          {addMessage && (
            <p className="text-xs font-medium text-emerald-700 bg-emerald-50 p-2.5 rounded-lg border border-emerald-200">
              {addMessage}
            </p>
          )}
        </div>

        {/* Stats Summary */}
        <div className="lg:col-span-7 bg-[#0b1528] text-white p-6 rounded-2xl border border-[#1e2c45] flex flex-col justify-between">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-[#0062ff] mb-1">
              Audience Integrity
            </div>
            <div className="text-3xl font-black">{subscribers.length} Verified Subscribers</div>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Subscribers receive automated weekly summaries of newly published guides. Duplicate registration is automatically deduplicated.
            </p>
          </div>
          <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span>Zero bounce addresses · 100% CAN-SPAM compliant</span>
          </div>
        </div>
      </div>

      {/* Subscribers Table */}
      <div className="bg-white rounded-2xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-sm">
            <input
              type="text"
              placeholder="Search subscriber email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-xl border border-[#cbd5e1] pl-9 pr-3 py-1.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
            />
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2" />
          </div>
          <span className="text-xs text-[#64748b]">
            Showing {filtered.length} of {subscribers.length}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#64748b] font-semibold border-b border-[#e2e8f0]">
              <tr>
                <th className="p-4">Subscriber Email</th>
                <th className="p-4">Status</th>
                <th className="p-4">Registration Date</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9] text-[#1e293b]">
              {filtered.map((sub) => (
                <tr key={sub.id} className="hover:bg-[#f8fafc] transition-colors">
                  <td className="p-4 font-mono font-medium text-[#0b1528]">
                    {sub.email}
                  </td>
                  <td className="p-4">
                    <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {sub.is_active ? 'Active' : 'Unsubscribed'}
                    </span>
                  </td>
                  <td className="p-4 text-[#64748b]">
                    {formatDate(sub.created_at)}
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() => handleDelete(sub.id, sub.email)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded transition-colors"
                      title="Remove subscriber"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
