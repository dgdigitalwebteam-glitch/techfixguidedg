import { useState, useEffect } from 'react';
import {
  Article,
  Category,
  Profile,
  Tag,
  MediaItem,
  Comment,
  NewsletterSubscriber,
  ContactMessage,
  AdSettings,
  SiteSettings,
} from '../types';
import { generateSlug, calculateReadingTime } from './utils';
import { FirestoreSyncManager, StoreMemoryState } from './firestoreSync';

// Initial Author Profiles
export const INITIAL_AUTHORS: Profile[] = [
  {
    id: 'author-1',
    full_name: 'Alex Mercer',
    email: 'alex@techfixguide.com',
    avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    bio: 'Senior Infrastructure Engineer and Technical Editor. Specializes in distributed systems, PostgreSQL query optimization, and resilient web architectures.',
    role: 'admin',
    twitter_handle: '@alexmercer_dev',
    github_url: 'https://github.com',
    linkedin_url: 'https://linkedin.com',
  },
  {
    id: 'author-2',
    full_name: 'Dr. Elena Vance',
    email: 'elena@techfixguide.com',
    avatar_url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80',
    bio: 'AI Systems Researcher and former ML Lead. Focuses on parameter-efficient fine-tuning (PEFT), quantization, and local neural agents.',
    role: 'editor',
    twitter_handle: '@elena_vance_ai',
    github_url: 'https://github.com',
  },
  {
    id: 'author-3',
    full_name: 'Marcus Chen',
    email: 'marcus@techfixguide.com',
    avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    bio: 'DevSecOps specialist and cloud architect. Author of defensive hardening playbooks for Kubernetes and modern web apps.',
    role: 'author',
    github_url: 'https://github.com',
  },
];

// 9 Categories as specifically requested
export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-web-dev',
    name: 'Web Development',
    slug: 'web-development',
    description: 'Modern full-stack web engineering, TypeScript, React 19, CSS Subgrid, and resilient API architectures.',
    image_url: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Web Development Guides & Tutorials | TechFixGuide',
    seo_description: 'Master full-stack engineering with deep architectural teardowns, Next.js tutorials, and clean TypeScript patterns.',
  },
  {
    id: 'cat-ai',
    name: 'Artificial Intelligence',
    slug: 'artificial-intelligence',
    description: 'Practical LLM deployment, quantization, prompt engineering pipelines, and neural agent workflows.',
    image_url: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Applied AI Frameworks & Model Guides | TechFixGuide',
    seo_description: 'Actionable blueprints for fine-tuning open weights, local inference benchmarks, and autonomous software workflows.',
  },
  {
    id: 'cat-wordpress',
    name: 'WordPress',
    slug: 'wordpress',
    description: 'Enterprise headless WordPress architectures, object cache tuning, block theme development, and security.',
    image_url: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Headless WordPress Speed & Security | TechFixGuide',
    seo_description: 'Learn enterprise speed optimization, Redis object caching, and headless GraphQL integrations for WordPress.',
  },
  {
    id: 'cat-seo',
    name: 'SEO & Marketing',
    slug: 'seo-marketing',
    description: 'Programmatic SEO, Core Web Vitals optimization, JSON-LD Schema markup, and technical crawl diagnostics.',
    image_url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Technical SEO & Search Strategy | TechFixGuide',
    seo_description: 'Master Core Web Vitals, dynamic XML sitemaps, and internal linking topology for superior search rankings.',
  },
  {
    id: 'cat-tools',
    name: 'Free Online Tools',
    slug: 'free-online-tools',
    description: 'Curated directories, reviews, and benchmark comparisons of free and open-source developer utilities.',
    image_url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Curated Free Online Developer Tools | TechFixGuide',
    seo_description: 'Discover the best free open-source tools for image compression, regex testing, DNS diagnostics, and code profiling.',
  },
  {
    id: 'cat-ecommerce',
    name: 'E-commerce',
    slug: 'ecommerce',
    description: 'Headless commerce, Stripe payment intents, conversion rate engineering, and resilient checkout pipelines.',
    image_url: 'https://images.unsplash.com/photo-1556742049-0a67c5574f73?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Modern E-commerce Architecture & Payment Flows | TechFixGuide',
    seo_description: 'Build fast, fault-tolerant e-commerce platforms with webhooks, cart synchronization, and inventory consistency.',
  },
  {
    id: 'cat-software',
    name: 'Software & Technology',
    slug: 'software-technology',
    description: 'Developer workstations, Linux system administration, database engines, and software stack reviews.',
    image_url: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Software Tooling & Technology Reviews | TechFixGuide',
    seo_description: 'Unbiased performance benchmarks, developer workstation setups, and operating system optimizations.',
  },
  {
    id: 'cat-cybersecurity',
    name: 'Cybersecurity',
    slug: 'cybersecurity',
    description: 'Zero-trust architecture, OWASP defense, identity hardening, encrypted communication, and security audits.',
    image_url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Defensive Cybersecurity & Application Hardening | TechFixGuide',
    seo_description: 'Pragmatic guides to securing API tokens, mitigating SQL injection, preventing XSS, and hardening infrastructure.',
  },
  {
    id: 'cat-tutorials',
    name: 'Tech Tutorials',
    slug: 'tech-tutorials',
    description: 'Step-by-step troubleshooting, bug diagnostics, runtime error solutions, and practical tech fixes.',
    image_url: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Step-by-Step Tech Troubleshooting & Fixes | TechFixGuide',
    seo_description: 'Direct, verified solutions for common operating system errors, database lockups, and package conflicts.',
  },
];

// Initial Realistic Articles (3 Featured, multiple published, 6 drafts)
export const INITIAL_ARTICLES: Article[] = [
  // 1. Featured AI Masterguide
  {
    id: 'art-1',
    title: 'Fine-Tuning Local LLMs: From Raw Dataset to High-Throughput vLLM Inference',
    slug: 'fine-tuning-local-llms-raw-dataset-vllm-inference',
    subtitle: 'A complete production blueprint using LoRA, Unsloth, and Dockerized inference servers with measurable latency benchmarks.',
    excerpt: 'Step-by-step walkthrough of formatting training instructions, quantizing weights to 4-bit AWQ, and serving high-throughput endpoints without vendor lock-in.',
    category_id: 'cat-ai',
    tags: ['AI', 'LLM', 'vLLM', 'PyTorch', 'Inference'],
    author_id: 'author-2',
    status: 'published',
    published_at: '2026-03-24T14:30:00Z',
    scheduled_for: null,
    reading_time: 8,
    is_featured: true,
    is_trending: true,
    is_editors_pick: true,
    featured_image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1400&q=80',
    seo_title: 'Fine-Tuning Local LLMs with LoRA & vLLM Guide | TechFixGuide',
    seo_description: 'Comprehensive technical blueprint for quantizing and serving open-source foundation models with measurable latency benchmarks.',
    canonical_url: 'https://techfixguide.com/blog/fine-tuning-local-llms-raw-dataset-vllm-inference',
    og_image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1400&q=80',
    view_count: 14820,
    created_at: '2026-03-24T10:00:00Z',
    updated_at: '2026-03-26T16:20:00Z',
    content: `
      <h2>The Shift Towards Sovereign Private Intelligence</h2>
      <p>Relying exclusively on proprietary cloud APIs introduces unexpected cost scaling, variable request latency, and enterprise compliance hurdles. Modern parameter-efficient fine-tuning (PEFT) frameworks like LoRA (Low-Rank Adaptation) allow engineering teams to adapt open foundation weights on custom technical documentation for a fraction of the hardware cost.</p>
      
      <blockquote>
        "Constraining weight updates to low-rank decomposition matrices allows 70B parameter models to be trained efficiently on consumer workstations with minimal memory overhead."
      </blockquote>

      <h2>Step 1: Dataset Pipeline & Instruction Formatting</h2>
      <p>Before launching compute, curate high-signal input-response pairs formatted according to the exact chat template expected by the tokenizer. Clean datasets avoid catastrophic forgetting and hallucinations.</p>
      
      <pre><code>// dataset_sample.json
{
  "messages": [
    { "role": "system", "content": "You are a senior PostgreSQL DBA diagnosing query bottlenecks." },
    { "role": "user", "content": "How do I diagnose buffer cache misses during peak writes?" },
    { "role": "assistant", "content": "Query pg_statio_user_tables to calculate heap_blks_read vs heap_blks_hit..." }
  ]
}</code></pre>

      <h2>Step 2: Training with Low-Rank Adaptation (LoRA)</h2>
      <p>Using Unsloth and Hugging Face Transformers, initialize rank <code>r = 16</code> and target attention projection modules (<code>q_proj</code>, <code>k_proj</code>, <code>v_proj</code>, <code>o_proj</code>):</p>
      
      <pre><code>from unsloth import FastLanguageModel
import torch

max_seq_length = 4096
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/meta-llama-3.1-8b-instruct",
    max_seq_length = max_seq_length,
    dtype = None,
    load_in_4bit = True,
)

model = FastLanguageModel.get_peft_model(
    model,
    r = 16,
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    lora_alpha = 16,
    lora_dropout = 0,
    bias = "none",
)</code></pre>

      <h2>Step 3: Quantization & vLLM High-Throughput Serving</h2>
      <p>Once LoRA adapters are merged into the base checkpoint, compile the model into an AWQ or GGUF format and mount it into a container running vLLM. The PagedAttention engine eliminates KV cache fragmentation, delivering up to 4x higher token throughput compared to standard Hugging Face pipelines.</p>

      <pre><code># Launch high-concurrency vLLM container
docker run --runtime nvidia --gpus all \\
  -v /models/custom-llama-3:/model \\
  -p 8000:8000 \\
  vllm/vllm-openai:latest \\
  --model /model \\
  --max-model-len 4096 \\
  --gpu-memory-utilization 0.95 \\
  --tensor-parallel-size 1</code></pre>

      <h2>Performance Benchmarks</h2>
      <table>
        <thead>
          <tr>
            <th>Serving Engine</th>
            <th>Concurrency</th>
            <th>Tokens / Sec</th>
            <th>TTFT (ms)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Standard Transformers</td>
            <td>10 Users</td>
            <td>84.2</td>
            <td>420ms</td>
          </tr>
          <tr>
            <td>vLLM PagedAttention</td>
            <td>10 Users</td>
            <td>386.5</td>
            <td>110ms</td>
          </tr>
          <tr>
            <td>vLLM AWQ Quantized</td>
            <td>50 Users</td>
            <td>740.1</td>
            <td>85ms</td>
          </tr>
        </tbody>
      </table>

      <h3>Key Takeaways</h3>
      <p>Deploying self-hosted language models gives complete ownership of IP, deterministically capped infrastructure expenses, and sub-100ms response times for critical technical user flows.</p>
    `,
  },

  // 2. Featured Web Dev Masterguide
  {
    id: 'art-2',
    title: 'Architecting Zero-Shift Next.js & React 19 Interfaces with CSS Subgrid',
    slug: 'architecting-zero-shift-nextjs-css-subgrid',
    subtitle: 'Eliminate Cumulative Layout Shift (CLS) on high-density editorial publication layouts with modern CSS grid techniques.',
    excerpt: 'Detailed tutorial on coordinating card heights, dynamic headline wraps, and media containers to maintain pristine 100/100 Core Web Vitals.',
    category_id: 'cat-web-dev',
    tags: ['Web Development', 'CSS', 'React 19', 'Core Web Vitals'],
    author_id: 'author-1',
    status: 'published',
    published_at: '2026-03-22T09:15:00Z',
    scheduled_for: null,
    reading_time: 6,
    is_featured: true,
    is_trending: true,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1400&q=80',
    seo_title: 'Zero-Shift Next.js Layouts with CSS Subgrid | TechFixGuide',
    seo_description: 'Master CSS Subgrid and Next.js dynamic image handling to eliminate layout shifts on high-traffic content sites.',
    canonical_url: 'https://techfixguide.com/blog/architecting-zero-shift-nextjs-css-subgrid',
    og_image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1400&q=80',
    view_count: 9340,
    created_at: '2026-03-22T08:00:00Z',
    updated_at: '2026-03-23T11:45:00Z',
    content: `
      <h2>The Problem: Jagged Visual Card Topologies</h2>
      <p>Content-heavy websites struggle with uneven article cards. One title spans three lines while its neighbor takes one. Authors frequently solve this with messy JavaScript resize observers or arbitrary truncation lines that harm SEO. CSS Subgrid provides a native, hardware-accelerated answer.</p>

      <h2>Implementing Subgrid Card Grids</h2>
      <p>By declaring <code>grid-template-rows: subgrid;</code> on child cards, every component (image, metadata, title, excerpt, footer) aligns with its siblings in the same row automatically.</p>

      <pre><code>/* Parent Container */
.editorial-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  grid-auto-rows: auto;
  gap: 1.5rem;
}

/* Child Card spanning 5 internal subgrid rows */
.editorial-card {
  display: grid;
  grid-row: span 5;
  grid-template-rows: subgrid;
}</code></pre>

      <h2>Handling Aspect Ratios to Kill CLS</h2>
      <p>Cumulative Layout Shift occurs when image dimensions are resolved after external web assets download. Always specify intrinsic aspect ratio boxes on image containers:</p>

      <pre><code><div class="relative aspect-[16/9] w-full overflow-hidden bg-slate-100">
  <img 
    src="/featured.webp" 
    alt="Clean architecture" 
    class="object-cover w-full h-full" 
    loading="lazy" 
  />
</div></code></pre>

      <h3>Verification via Lighthouse & Search Console</h3>
      <p>Test your site using WebPageTest with CPU 4x throttling. A score of CLS = 0.000 ensures high crawl frequency and maximum AdSense revenue without accidental clicks.</p>
    `,
  },

  // 3. Featured Cybersecurity Masterguide
  {
    id: 'art-3',
    title: 'Zero-Trust Security Hardening for Modern Cloud Deployments & Microservices',
    slug: 'zero-trust-security-hardening-cloud-microservices',
    subtitle: 'Defensive strategies against token theft, SSRF vectors, supply-chain poisoning, and privilege escalation.',
    excerpt: 'Actionable playbook for locking down API gateways, enforcing mTLS between Kubernetes services, and implementing automated vulnerability scanning in CI/CD.',
    category_id: 'cat-cybersecurity',
    tags: ['Cybersecurity', 'DevSecOps', 'Zero-Trust', 'Cloud'],
    author_id: 'author-3',
    status: 'published',
    published_at: '2026-03-20T16:00:00Z',
    scheduled_for: null,
    reading_time: 7,
    is_featured: true,
    is_trending: false,
    is_editors_pick: true,
    featured_image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1400&q=80',
    seo_title: 'Zero-Trust Security Hardening Playbook | TechFixGuide',
    seo_description: 'Pragmatic defensive security blueprint for engineering teams deploying modern cloud microservices.',
    canonical_url: 'https://techfixguide.com/blog/zero-trust-security-hardening-cloud-microservices',
    og_image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1400&q=80',
    view_count: 8120,
    created_at: '2026-03-20T12:00:00Z',
    updated_at: '2026-03-21T14:10:00Z',
    content: `
      <h2>The Fallacy of the Trusted Internal Perimeter</h2>
      <p>Modern security posture begins with one fundamental premise: assume the internal network is already breached. Zero-Trust Architecture replaces implicit perimeter trust with continuous, cryptographically verified authentication for every single transaction.</p>

      <h2>1. Mutual TLS (mTLS) with SPIFFE/SPIRE</h2>
      <p>Service-to-service communication must never occur over unencrypted HTTP, even within a private Kubernetes VPC. Employ automated certificate authorities that rotate ephemeral x509 credentials every few hours.</p>

      <pre><code># Envoy Proxy Mutual TLS Policy Example
tls_certificates:
  - certificate_chain:
      filename: "/etc/certs/service-cert.pem"
    private_key:
      filename: "/etc/certs/service-key.pem"
validation_context:
  trusted_ca:
    filename: "/etc/certs/mesh-ca.pem"
  require_client_certificate: true</code></pre>

      <h2>2. Defending Against Server-Side Request Forgery (SSRF)</h2>
      <p>Cloud metadata services (such as <code>169.254.169.254</code>) are prime targets. Enforce IMDSv2 and configure outbound network egress firewall rules so worker instances cannot ping internal network interfaces.</p>

      <pre><code># AWS CLI IMDSv2 Enforcement
aws ec2 modify-instance-metadata-options \\
    --instance-id i-0123456789abcdef0 \\
    --http-tokens required \\
    --http-endpoint enabled</code></pre>

      <h3>Audit Checklist</h3>
      <ul>
        <li>Never store API keys in frontend code bundles or client-side storage.</li>
        <li>Pin container base images by SHA256 digest rather than mutable tags.</li>
        <li>Implement strict Content Security Policy (CSP) headers on all public portals.</li>
      </ul>
    `,
  },

  // 4. Tech Tutorials
  {
    id: 'art-4',
    title: 'Diagnosing High PostgreSQL IOPS: Step-by-Step Query Analysis & Index Tuning',
    slug: 'diagnosing-high-postgresql-iops-step-by-step-query-analysis',
    subtitle: 'Locate runaway sequential table scans and buffer cache misses before disk write exhaustion occurs.',
    excerpt: 'How to combine pg_stat_statements, EXPLAIN (ANALYZE, BUFFERS), and partial index construction to drop database CPU by 80%.',
    category_id: 'cat-tutorials',
    tags: ['PostgreSQL', 'Database', 'Performance', 'SQL'],
    author_id: 'author-1',
    status: 'published',
    published_at: '2026-03-18T11:00:00Z',
    scheduled_for: null,
    reading_time: 5,
    is_featured: false,
    is_trending: true,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Diagnosing PostgreSQL IOPS Bottlenecks | TechFixGuide',
    seo_description: 'Practical database troubleshooting tutorial: resolve runaway queries and optimize disk IOPS.',
    canonical_url: 'https://techfixguide.com/blog/diagnosing-high-postgresql-iops-step-by-step-query-analysis',
    og_image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80',
    view_count: 6510,
    created_at: '2026-03-18T09:00:00Z',
    updated_at: '2026-03-18T10:00:00Z',
    content: `
      <h2>Symptoms of Disk IOPS Exhaustion</h2>
      <p>When storage read/write bursts saturate your managed RDS or Supabase disk limit, query execution queues rapidly backlog, leading to <code>504 Gateway Timeout</code> cascading failures.</p>

      <h2>Step 1: Identifying the Top Resource Hogs</h2>
      <pre><code>SELECT 
    query, 
    calls, 
    total_exec_time, 
    mean_exec_time,
    rows 
FROM pg_stat_statements 
ORDER BY total_exec_time DESC 
LIMIT 5;</code></pre>

      <h2>Step 2: Buffer Cache Analysis</h2>
      <p>Always inspect whether queries are fetching rows from warm RAM or dragging them off physical NVMe disks:</p>
      <pre><code>EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM articles 
WHERE status = 'published' 
ORDER BY published_at DESC 
LIMIT 20;</code></pre>
      <p>If you observe <code>Buffers: shared read=18492</code>, that means data was read off the disk instead of memory hit.</p>
    `,
  },

  // 5. WordPress
  {
    id: 'art-5',
    title: 'Headless WordPress at Scale: Next.js Frontend with Redis Object Cache',
    slug: 'headless-wordpress-scale-nextjs-redis-object-cache',
    subtitle: 'Decoupling WordPress to achieve sub-second TTFB while preserving familiar Gutenberg authoring workflows.',
    excerpt: 'Architectural overview of synchronizing headless GraphQL webhooks with on-demand incremental static revalidation.',
    category_id: 'cat-wordpress',
    tags: ['WordPress', 'Headless', 'Next.js', 'Redis'],
    author_id: 'author-1',
    status: 'published',
    published_at: '2026-03-15T10:00:00Z',
    scheduled_for: null,
    reading_time: 5,
    is_featured: false,
    is_trending: false,
    is_editors_pick: true,
    featured_image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Headless WordPress Architecture Guide | TechFixGuide',
    seo_description: 'Build enterprise headless WordPress sites with Next.js frontend and Redis object caching.',
    canonical_url: 'https://techfixguide.com/blog/headless-wordpress-scale-nextjs-redis-object-cache',
    og_image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    view_count: 4230,
    created_at: '2026-03-15T09:00:00Z',
    updated_at: '2026-03-15T09:00:00Z',
    content: `
      <h2>Why Decouple WordPress?</h2>
      <p>Traditional WordPress servers parse PHP and execute dozens of SQL queries per request, creating heavy CPU loads. Decoupling the frontend enables instant global CDN caching and superior security against theme vulnerabilities.</p>
      <h2>Webhook Invalidation Architecture</h2>
      <p>Configure a custom WordPress action on <code>save_post</code> that triggers an authenticated POST request to your frontend's revalidation webhook endpoint.</p>
    `,
  },

  // 6. Free Online Tools
  {
    id: 'art-6',
    title: 'Top 15 Free Online Developer Tools That Save Hours Every Week',
    slug: 'top-15-free-online-developer-tools-save-hours',
    subtitle: 'Tested browser utilities for regex profiling, SSL certificate debugging, SVG minification, and mock API generation.',
    excerpt: 'Our curated directory of no-signup, zero-tracking online engineering tools that belong in every engineer bookmarks bar.',
    category_id: 'cat-tools',
    tags: ['Tools', 'Productivity', 'DevTools', 'Open Source'],
    author_id: 'author-2',
    status: 'published',
    published_at: '2026-03-12T13:00:00Z',
    scheduled_for: null,
    reading_time: 4,
    is_featured: false,
    is_trending: true,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Best Free Online Developer Tools 2026 | TechFixGuide',
    seo_description: 'Discover the top 15 free developer tools for networking, JSON formatting, SVG compression, and regex verification.',
    canonical_url: 'https://techfixguide.com/blog/top-15-free-online-developer-tools-save-hours',
    og_image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
    view_count: 11200,
    created_at: '2026-03-12T10:00:00Z',
    updated_at: '2026-03-12T10:00:00Z',
    content: `
      <h2>The Best Utilities Don't Require Account Signups</h2>
      <p>We evaluated over 60 browser-based developer utilities across four categories: networking, cryptography, frontend compression, and data transformation.</p>
      <h3>1. CyberChef — The Cyber Swiss Army Knife</h3>
      <p>Open-source web utility for encryption, encoding, compression, and data parsing entirely in the browser memory.</p>
      <h3>2. SVGOMG — Pristine Vector Compression</h3>
      <p>Strip unnecessary XML namespaces, editor metadata, and redundant path coordinates with real-time visual difference previews.</p>
    `,
  },

  // 7. SEO & Marketing
  {
    id: 'art-7',
    title: 'Technical SEO for Developers: Programmatic Sitemaps & Schema.org Topologies',
    slug: 'technical-seo-developers-programmatic-sitemaps-schema-topologies',
    subtitle: 'Structuring rich JSON-LD graph models to achieve high Google knowledge panel and snippet visibility.',
    excerpt: 'How to structure automated XML sitemap feeds, canonical URL hierarchy, and article structured data without bloated plugins.',
    category_id: 'cat-seo',
    tags: ['SEO', 'Structured Data', 'Sitemap', 'Google Search'],
    author_id: 'author-1',
    status: 'published',
    published_at: '2026-03-08T15:20:00Z',
    scheduled_for: null,
    reading_time: 6,
    is_featured: false,
    is_trending: false,
    is_editors_pick: true,
    featured_image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Technical SEO & Schema Markup Architecture | TechFixGuide',
    seo_description: 'Master programmatic SEO, JSON-LD Schema graphs, and dynamic XML sitemap generation for engineering publications.',
    canonical_url: 'https://techfixguide.com/blog/technical-seo-developers-programmatic-sitemaps-schema-topologies',
    og_image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
    view_count: 5310,
    created_at: '2026-03-08T12:00:00Z',
    updated_at: '2026-03-08T12:00:00Z',
    content: `
      <h2>Search Crawlers Value Structural Clarity</h2>
      <p>Google Search Central prioritizes sites with explicit structured data trees. By linking <code>NewsArticle</code> or <code>TechArticle</code> nodes directly to verified <code>Person</code> and <code>Organization</code> entities, you validate editorial expertise (E-E-A-T).</p>
      <h2>Nested JSON-LD Implementation</h2>
      <pre><code>{
  "@context": "https://schema.org",
  "@type": "TechArticle",
  "headline": "Technical SEO for Developers",
  "author": {
    "@type": "Person",
    "name": "Alex Mercer"
  }
}</code></pre>
    `,
  },

  // 8. E-commerce
  {
    id: 'art-8',
    title: 'Resilient Payment Webhooks: Handling Stripe Event Idempotency in Production',
    slug: 'resilient-payment-webhooks-stripe-event-idempotency',
    subtitle: 'Preventing double-charges, race conditions, and missed order fulfillment during high-velocity checkout bursts.',
    excerpt: 'Detailed implementation guide for recording webhook event IDs in PostgreSQL before dispatching downstream fulfillment tasks.',
    category_id: 'cat-ecommerce',
    tags: ['E-commerce', 'Stripe', 'Webhooks', 'PostgreSQL'],
    author_id: 'author-3',
    status: 'published',
    published_at: '2026-03-04T12:00:00Z',
    scheduled_for: null,
    reading_time: 5,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1556742049-0a67c5574f73?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Stripe Webhook Idempotency & Resiliency | TechFixGuide',
    seo_description: 'Build safe, idempotent webhook receivers to prevent double fulfillment during network retries.',
    canonical_url: 'https://techfixguide.com/blog/resilient-payment-webhooks-stripe-event-idempotency',
    og_image: 'https://images.unsplash.com/photo-1556742049-0a67c5574f73?auto=format&fit=crop&w=1200&q=80',
    view_count: 3840,
    created_at: '2026-03-04T10:00:00Z',
    updated_at: '2026-03-04T10:00:00Z',
    content: `
      <h2>The Guarantee of At-Least-Once Delivery</h2>
      <p>Payment webhooks are sent with at-least-once delivery guarantees. Under transient network failures, Stripe will retry event notifications, which can trigger duplicate credit allocation if idempotency keys are not enforced.</p>
    `,
  },

  // 9. Software & Technology
  {
    id: 'art-9',
    title: 'Developer Workstations in 2026: ARM vs x86-64 Architecture Benchmarks',
    slug: 'developer-workstations-2026-arm-vs-x86-benchmarks',
    subtitle: 'Real-world compilation times for Rust, Go, TypeScript, and Docker container builds on Apple Silicon, AMD Ryzen, and Intel Ultra chips.',
    excerpt: 'Direct thermal, compilation, and power consumption benchmarks comparing the latest developer silicon architectures.',
    category_id: 'cat-software',
    tags: ['Hardware', 'Silicon', 'Benchmarks', 'Developer Experience'],
    author_id: 'author-1',
    status: 'published',
    published_at: '2026-03-01T14:00:00Z',
    scheduled_for: null,
    reading_time: 6,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Developer Workstation Benchmarks 2026 | TechFixGuide',
    seo_description: 'Comparison of ARM vs x86 compilation speeds for modern full-stack workflows.',
    canonical_url: 'https://techfixguide.com/blog/developer-workstations-2026-arm-vs-x86-benchmarks',
    og_image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=80',
    view_count: 7600,
    created_at: '2026-03-01T10:00:00Z',
    updated_at: '2026-03-01T10:00:00Z',
    content: `
      <h2>Methodology: Measuring Actual Developer Workloads</h2>
      <p>Synthetic geekbench figures rarely reflect software development cycles. We compiled the Linux kernel, a 250,000-line Rust web service, and executed 4,000 Jest test suites across five hardware platforms.</p>
    `,
  },

  // --- 6 ADDITIONAL DRAFTS (As specified in requirement 15: "6 additional article drafts") ---
  {
    id: 'draft-1',
    title: 'Building Custom AI Coding Assistants with Ollama & Model Context Protocol (MCP)',
    slug: 'building-custom-ai-coding-assistants-ollama-mcp',
    subtitle: 'Hooking local intelligence directly into your terminal editor.',
    excerpt: 'Connecting local open-weights to VSCode and Neovim using the emerging Model Context Protocol for secure code completion.',
    category_id: 'cat-ai',
    tags: ['AI', 'Ollama', 'MCP', 'Productivity'],
    author_id: 'author-2',
    status: 'draft',
    published_at: null,
    scheduled_for: null,
    reading_time: 6,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Custom AI Assistants with Ollama & MCP | TechFixGuide',
    seo_description: 'Build your own local AI copilot with Ollama and Model Context Protocol.',
    canonical_url: 'https://techfixguide.com/blog/building-custom-ai-coding-assistants-ollama-mcp',
    og_image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    view_count: 0,
    created_at: '2026-03-25T11:00:00Z',
    updated_at: '2026-03-25T11:00:00Z',
    content: `<h2>Draft: Setting up MCP Host</h2><p>Article under editorial composition.</p>`,
  },
  {
    id: 'draft-2',
    title: 'PostgreSQL 17 Logical Replication Deep Dive: Failover & Sync Lag',
    slug: 'postgresql-17-logical-replication-deep-dive',
    subtitle: 'Zero-downtime database upgrades with publication/subscription slots.',
    excerpt: 'Examining changes in logical slot failover preservation across primary-standby failover clusters in modern PostgreSQL.',
    category_id: 'cat-tutorials',
    tags: ['PostgreSQL', 'High Availability', 'Database'],
    author_id: 'author-1',
    status: 'draft',
    published_at: null,
    scheduled_for: null,
    reading_time: 7,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'PostgreSQL 17 Logical Replication | TechFixGuide',
    seo_description: 'Deep dive into logical replication improvements and failover preservation.',
    canonical_url: 'https://techfixguide.com/blog/postgresql-17-logical-replication-deep-dive',
    og_image: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?auto=format&fit=crop&w=1200&q=80',
    view_count: 0,
    created_at: '2026-03-24T15:00:00Z',
    updated_at: '2026-03-24T15:00:00Z',
    content: `<h2>Draft: Logical Slot Configuration</h2><p>Working draft in peer review.</p>`,
  },
  {
    id: 'draft-3',
    title: 'Migrating Legacy Monoliths to Micro-Frontends: Pitfalls and Realities',
    slug: 'migrating-legacy-monoliths-to-micro-frontends',
    subtitle: 'When module federation saves your release cadence and when it adds pure friction.',
    excerpt: 'An honest retrospective on splitting large SPAs across autonomous engineering squads with Webpack Module Federation.',
    category_id: 'cat-web-dev',
    tags: ['Architecture', 'Frontend', 'Module Federation'],
    author_id: 'author-1',
    status: 'draft',
    published_at: null,
    scheduled_for: null,
    reading_time: 8,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Micro-Frontends Migration Guide | TechFixGuide',
    seo_description: 'Realistic analysis of migrating to micro-frontends with module federation.',
    canonical_url: 'https://techfixguide.com/blog/migrating-legacy-monoliths-to-micro-frontends',
    og_image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=80',
    view_count: 0,
    created_at: '2026-03-23T14:00:00Z',
    updated_at: '2026-03-23T14:00:00Z',
    content: `<h2>Draft: Shared Dependency Tax</h2><p>Draft notes on version synchronization.</p>`,
  },
  {
    id: 'draft-4',
    title: 'Hardening NGINX Against Slowloris & HTTP/2 Rapid Reset Attacks',
    slug: 'hardening-nginx-slowloris-http2-rapid-reset',
    subtitle: 'Rate limiting zones, timeout thresholds, and kernel socket tuning.',
    excerpt: 'Configuration recipes for shielding edge reverse proxies from protocol-level denial-of-service bursts.',
    category_id: 'cat-cybersecurity',
    tags: ['Cybersecurity', 'NGINX', 'DDoS', 'Linux'],
    author_id: 'author-3',
    status: 'draft',
    published_at: null,
    scheduled_for: null,
    reading_time: 5,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'NGINX Hardening Configuration | TechFixGuide',
    seo_description: 'Protect your web servers from HTTP/2 Rapid Reset and Slowloris attacks.',
    canonical_url: 'https://techfixguide.com/blog/hardening-nginx-slowloris-http2-rapid-reset',
    og_image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1200&q=80',
    view_count: 0,
    created_at: '2026-03-22T10:00:00Z',
    updated_at: '2026-03-22T10:00:00Z',
    content: `<h2>Draft: Limit Req Zones</h2><p>Draft under security review.</p>`,
  },
  {
    id: 'draft-5',
    title: 'Automated Core Web Vitals Monitoring via GitHub Actions & Lighthouse CI',
    slug: 'automated-core-web-vitals-monitoring-github-actions',
    subtitle: 'Catch performance regressions in Pull Requests before merging to main.',
    excerpt: 'Setup guide for running automated headless Chrome performance audits on preview URLs with budget assertion thresholds.',
    category_id: 'cat-seo',
    tags: ['SEO', 'Lighthouse', 'CI/CD', 'GitHub Actions'],
    author_id: 'author-1',
    status: 'draft',
    published_at: null,
    scheduled_for: null,
    reading_time: 4,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Lighthouse CI in GitHub Actions | TechFixGuide',
    seo_description: 'Enforce performance budgets in CI pipelines with Lighthouse assertions.',
    canonical_url: 'https://techfixguide.com/blog/automated-core-web-vitals-monitoring-github-actions',
    og_image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    view_count: 0,
    created_at: '2026-03-21T09:00:00Z',
    updated_at: '2026-03-21T09:00:00Z',
    content: `<h2>Draft: Lighthouse Budget Configuration</h2><p>Draft under review.</p>`,
  },
  {
    id: 'draft-6',
    title: 'Self-Hosting S3-Compatible Object Storage with MinIO and Traefik',
    slug: 'self-hosting-s3-compatible-object-storage-minio',
    subtitle: 'Cheap, multi-terabyte media backups with automated SSL certificates.',
    excerpt: 'Deploying high-speed distributed object storage on local NVMe servers with private bucket policies and lifecycle expiration.',
    category_id: 'cat-software',
    tags: ['DevOps', 'Storage', 'MinIO', 'Docker'],
    author_id: 'author-3',
    status: 'draft',
    published_at: null,
    scheduled_for: null,
    reading_time: 6,
    is_featured: false,
    is_trending: false,
    is_editors_pick: false,
    featured_image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Self-Hosted Object Storage with MinIO | TechFixGuide',
    seo_description: 'Learn how to deploy scalable, S3-compatible MinIO clusters behind Traefik reverse proxy.',
    canonical_url: 'https://techfixguide.com/blog/self-hosting-s3-compatible-object-storage-minio',
    og_image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1200&q=80',
    view_count: 0,
    created_at: '2026-03-20T14:00:00Z',
    updated_at: '2026-03-20T14:00:00Z',
    content: `<h2>Draft: MinIO Distributed Erasure Coding</h2><p>Draft in progress.</p>`,
  },
];

// Initial Media Assets
export const INITIAL_MEDIA: MediaItem[] = [
  {
    id: 'med-1',
    name: 'llama-inference-architecture.png',
    url: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1400&q=80',
    size: 482000,
    mime_type: 'image/jpeg',
    alt_text: 'Diagram of parameter-efficient fine-tuning and inference pipelines',
    created_at: '2026-03-24T10:00:00Z',
  },
  {
    id: 'med-2',
    name: 'subgrid-visual-spec.png',
    url: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1400&q=80',
    size: 324000,
    mime_type: 'image/jpeg',
    alt_text: 'Visual alignment of CSS Subgrid nested cards',
    created_at: '2026-03-22T08:00:00Z',
  },
  {
    id: 'med-3',
    name: 'zero-trust-topology.png',
    url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1400&q=80',
    size: 615000,
    mime_type: 'image/jpeg',
    alt_text: 'Zero-trust network architecture and mTLS policy diagram',
    created_at: '2026-03-20T12:00:00Z',
  },
  {
    id: 'med-4',
    name: 'postgresql-iops-metrics.png',
    url: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80',
    size: 290000,
    mime_type: 'image/jpeg',
    alt_text: 'PostgreSQL buffer cache hit ratio vs disk reads chart',
    created_at: '2026-03-18T09:00:00Z',
  },
];

// Initial Moderated Comments
export const INITIAL_COMMENTS: Comment[] = [
  {
    id: 'comm-1',
    article_id: 'art-1',
    author_name: 'David Thorne (Staff SRE)',
    author_email: 'david@cloudscale.io',
    content: 'We migrated our document search summarizer to vLLM AWQ using the exact parameters in your LoRA snippet. Token latency dropped from 380ms down to 92ms under 25 concurrent requests. Outstanding walkthrough.',
    status: 'approved',
    created_at: '2026-03-25T08:14:00Z',
  },
  {
    id: 'comm-2',
    article_id: 'art-1',
    author_name: 'Priya Patel',
    author_email: 'priya@datasystems.com',
    content: 'For tensor-parallel-size > 1 across two RTX 4090s, did you have to configure custom NCCL environment variables in Docker?',
    status: 'approved',
    created_at: '2026-03-25T11:40:00Z',
  },
  {
    id: 'comm-3',
    article_id: 'art-2',
    author_name: 'Soren Lind',
    author_email: 'soren@nordicdev.se',
    content: 'CSS Subgrid browser support is finally over 96% globally. The aspect-ratio trick for zero layout shift is something every junior engineer should be tested on.',
    status: 'approved',
    created_at: '2026-03-23T14:22:00Z',
  },
  {
    id: 'comm-4',
    article_id: 'art-3',
    author_name: 'Pending Reviewer',
    author_email: 'pending_reader@techlab.net',
    content: 'Do you recommend HashiCorp Vault or AWS KMS for managing the root CA certificates in the SPIFFE implementation?',
    status: 'pending', // Pending comment for admin to test moderation!
    created_at: '2026-03-26T09:10:00Z',
  },
];

// Initial Newsletter Subscribers
export const INITIAL_SUBSCRIBERS: NewsletterSubscriber[] = [
  {
    id: 'sub-1',
    email: 'danishbhatttti19@gmail.com',
    is_active: true,
    confirmed_at: '2026-03-26T14:00:00Z',
    created_at: '2026-03-26T14:00:00Z',
  },
  {
    id: 'sub-2',
    email: 'lead.architect@enterprisecloud.com',
    is_active: true,
    confirmed_at: '2026-03-25T18:30:00Z',
    created_at: '2026-03-25T18:30:00Z',
  },
  {
    id: 'sub-3',
    email: 'sarah.k@fintechsystems.io',
    is_active: true,
    confirmed_at: '2026-03-24T12:00:00Z',
    created_at: '2026-03-24T12:00:00Z',
  },
  {
    id: 'sub-4',
    email: 'dev.ops@nordicinfra.net',
    is_active: true,
    confirmed_at: '2026-03-22T09:15:00Z',
    created_at: '2026-03-22T09:15:00Z',
  },
];

// Initial Contact Messages
export const INITIAL_CONTACT_MESSAGES: ContactMessage[] = [
  {
    id: 'msg-1',
    name: 'Jonathan Reynolds',
    email: 'jreynolds@vectorgroup.org',
    subject: 'Syndication Rights for Technical Tutorials',
    message: 'Hello TechFixGuide Editorial Team, we would like to discuss syndicating your PostgreSQL and vLLM performance guides for our internal engineering library. Please connect us with your editorial lead.',
    is_read: false,
    created_at: '2026-03-26T15:10:00Z',
  },
];

// Initial Google AdSense & Ad Inventory Settings
export const INITIAL_AD_SETTINGS: AdSettings = {
  publisher_id: 'pub-9182374619283746',
  is_globally_enabled: true,
  header_ad_enabled: true,
  header_ad_code: `<div style="display:inline-block;padding:12px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;font-size:11px;color:#64748b;text-align:center;width:100%;max-width:728px;"><span style="font-weight:700;color:#0b1528;">Google AdSense Header Placement</span><br/>Leaderboard (728x90 responsive) · Verified slot ID: 881290412</div>`,
  sidebar_ad_enabled: true,
  sidebar_ad_code: `<div style="display:inline-block;padding:24px 16px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;font-size:11px;color:#64748b;text-align:center;width:100%;min-height:250px;"><span style="font-weight:700;color:#0b1528;">Google AdSense Sidebar Box</span><br/>Medium Rectangle (300x250)<br/>Targeted developer software sponsorship</div>`,
  in_article_ad_enabled: true,
  in_article_ad_code: `<div style="display:inline-block;padding:16px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;font-size:11px;color:#64748b;text-align:center;width:100%;"><span style="font-weight:700;color:#0b1528;">Google AdSense In-Article Responsive Slot</span><br/>High-visibility native display unit positioned after primary section</div>`,
  footer_ad_enabled: false,
  footer_ad_code: `<div style="display:inline-block;padding:12px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;font-size:11px;color:#64748b;text-align:center;width:100%;"><span style="font-weight:700;color:#0b1528;">Google AdSense Footer Billboard</span></div>`,
  ads_txt_content: `google.com, pub-9182374619283746, DIRECT, f08c47fec0942fa0`,
  verification_code: `<meta name="google-adsense-account" content="ca-pub-9182374619283746">`,
};

// Initial Site Settings
export const INITIAL_SITE_SETTINGS: SiteSettings = {
  site_name: 'TechFixGuide',
  site_tagline: 'Learn. Fix. Grow.',
  site_description: 'Practical technology education, AI tutorials, web development, software guides and digital productivity.',
  site_url: 'https://techfixguide.com',
  support_email: 'editorial@techfixguide.com',
  comments_enabled_globally: true,
  posts_per_page: 6,
};

// Event Dispatcher for Cross-Component Sync
export const DATA_SYNC_EVENT = 'tfg_store_updated';
function notifyUpdate() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event(DATA_SYNC_EVENT));
  }
}

// Reactive In-Memory Store State (hydrated from Firestore)
const memoryState: StoreMemoryState = {
  articles: [...INITIAL_ARTICLES],
  categories: [...INITIAL_CATEGORIES],
  authors: [...INITIAL_AUTHORS],
  comments: [...INITIAL_COMMENTS],
  media: [...INITIAL_MEDIA],
  subscribers: [...INITIAL_SUBSCRIBERS],
  contactMessages: [...INITIAL_CONTACT_MESSAGES],
  adSettings: { ...INITIAL_AD_SETTINGS },
  siteSettings: { ...INITIAL_SITE_SETTINGS },
  auth: {
    isAuthenticated: false,
    isLoading: typeof window !== 'undefined',
    user: null,
    error: null,
  },
};

const firestoreSync = new FirestoreSyncManager(
  () => memoryState,
  () => ({
    articles: INITIAL_ARTICLES,
    categories: INITIAL_CATEGORIES,
    authors: INITIAL_AUTHORS,
    comments: INITIAL_COMMENTS,
    media: INITIAL_MEDIA,
    subscribers: INITIAL_SUBSCRIBERS,
    contactMessages: INITIAL_CONTACT_MESSAGES,
    adSettings: INITIAL_AD_SETTINGS,
    siteSettings: INITIAL_SITE_SETTINGS,
  }),
  notifyUpdate
);

if (typeof window !== 'undefined') {
  firestoreSync.init();
}

// Data Access Layer
export const AppStore = {
  // Articles
  getArticles(): Article[] {
    return memoryState.articles;
  },

  saveArticles(articles: Article[]) {
    memoryState.articles = articles;
    notifyUpdate();
  },

  getArticleBySlug(slug: string): Article | undefined {
    return memoryState.articles.find((a) => a.slug === slug);
  },

  getArticleById(id: string): Article | undefined {
    return memoryState.articles.find((a) => a.id === id);
  },

  saveArticle(article: Partial<Article> & { id?: string }): Article {
    const now = new Date().toISOString();

    if (article.id) {
      const idx = memoryState.articles.findIndex((a) => a.id === article.id);
      if (idx >= 0) {
        const existing = memoryState.articles[idx];
        const nextSlug =
          article.slug !== undefined
            ? generateSlug(article.slug) || existing.slug
            : existing.slug;
        const updated: Article = {
          ...existing,
          ...article,
          slug: nextSlug,
          tags: (article.tags ?? existing.tags).slice(0, 15),
          reading_time: article.content
            ? calculateReadingTime(article.content)
            : existing.reading_time,
          updated_at: now,
        };
        const nextList = [...memoryState.articles];
        nextList[idx] = updated;
        memoryState.articles = nextList;
        notifyUpdate();
        void firestoreSync.persistArticle(updated, true);
        return updated;
      }
    }

    const newTitle = article.title || 'Untitled Guide';
    const rawSlug = article.slug ? generateSlug(article.slug) : generateSlug(newTitle);
    const newSlug = rawSlug || `article-${Date.now()}`;
    const newArt: Article = {
      id: 'art-' + Date.now(),
      title: newTitle,
      slug: newSlug,
      subtitle: article.subtitle || '',
      excerpt: article.excerpt || '',
      content: article.content || '<p>Start typing technical guide...</p>',
      featured_image:
        article.featured_image ||
        'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
      category_id: article.category_id || memoryState.categories[0]?.id || 'cat-web-dev',
      tags: (article.tags && article.tags.length ? article.tags : ['Tech']).slice(0, 15),
      author_id: article.author_id || memoryState.authors[0]?.id || 'author-1',
      status: article.status || 'draft',
      published_at: article.status === 'published' ? article.published_at || now : null,
      scheduled_for: article.scheduled_for || null,
      reading_time: calculateReadingTime(article.content || ''),
      is_featured: !!article.is_featured,
      is_trending: !!article.is_trending,
      is_editors_pick: !!article.is_editors_pick,
      seo_title: article.seo_title || newTitle,
      seo_description: article.seo_description || article.excerpt || '',
      canonical_url: article.canonical_url || `https://techfixguide.com/blog/${newSlug}`,
      og_image: article.og_image || article.featured_image || '',
      view_count: 0,
      created_at: now,
      updated_at: now,
    };
    memoryState.articles = [newArt, ...memoryState.articles];
    notifyUpdate();
    void firestoreSync.persistArticle(newArt, false);
    return newArt;
  },

  deleteArticle(id: string) {
    memoryState.articles = memoryState.articles.filter((a) => a.id !== id);
    notifyUpdate();
    void firestoreSync.deleteArticle(id);
  },

  incrementViewCount(slug: string) {
    const idx = memoryState.articles.findIndex((a) => a.slug === slug);
    if (idx >= 0) {
      const nextList = [...memoryState.articles];
      nextList[idx] = {
        ...nextList[idx],
        view_count: (nextList[idx].view_count || 0) + 1,
      };
      memoryState.articles = nextList;
      notifyUpdate();
    }
  },

  // Categories
  getCategories(): Category[] {
    return memoryState.categories;
  },

  saveCategories(categories: Category[]) {
    memoryState.categories = categories;
    notifyUpdate();
  },

  saveCategory(cat: Partial<Category> & { id?: string }): Category {
    if (cat.id) {
      const idx = memoryState.categories.findIndex((c) => c.id === cat.id);
      if (idx >= 0) {
        const existing = memoryState.categories[idx];
        const updated: Category = {
          ...existing,
          ...cat,
          slug:
            generateSlug(cat.slug || cat.name || existing.slug) || existing.slug,
        };
        const nextList = [...memoryState.categories];
        nextList[idx] = updated;
        memoryState.categories = nextList;
        notifyUpdate();
        void firestoreSync.persistCategory(updated, true);
        return updated;
      }
    }

    const newCat: Category = {
      id: 'cat-' + Date.now(),
      name: cat.name || 'New Category',
      slug: generateSlug(cat.slug || cat.name || 'new-category') || `cat-${Date.now()}`,
      description: cat.description || '',
      image_url:
        cat.image_url ||
        'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
      seo_title: cat.seo_title || cat.name || '',
      seo_description: cat.seo_description || cat.description || '',
    };
    memoryState.categories = [...memoryState.categories, newCat];
    notifyUpdate();
    void firestoreSync.persistCategory(newCat, false);
    return newCat;
  },

  // Authors
  getAuthors(): Profile[] {
    return memoryState.authors;
  },

  saveAuthors(authors: Profile[]) {
    memoryState.authors = authors;
    notifyUpdate();
    void firestoreSync.persistAuthors(authors);
  },

  // Comments
  getComments(): Comment[] {
    return memoryState.comments;
  },

  saveComments(comments: Comment[]) {
    memoryState.comments = comments;
    notifyUpdate();
  },

  addComment(comment: Omit<Comment, 'id' | 'created_at'>): Comment {
    const newComm: Comment = {
      ...comment,
      status: 'pending',
      id: `comm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      created_at: new Date().toISOString(),
    };
    memoryState.comments = [newComm, ...memoryState.comments];
    notifyUpdate();
    void firestoreSync.persistNewComment(newComm);
    return newComm;
  },

  updateCommentStatus(id: string, status: Comment['status']) {
    memoryState.comments = memoryState.comments.map((c) =>
      c.id === id ? { ...c, status } : c
    );
    notifyUpdate();
    void firestoreSync.updateCommentStatus(id, status);
  },

  deleteComment(id: string) {
    memoryState.comments = memoryState.comments.filter((c) => c.id !== id);
    notifyUpdate();
    void firestoreSync.deleteComment(id);
  },

  // Media Library
  getMedia(): MediaItem[] {
    return memoryState.media;
  },

  saveMedia(media: MediaItem[]) {
    memoryState.media = media;
    notifyUpdate();
  },

  addMediaItem(item: Omit<MediaItem, 'id' | 'created_at'>): MediaItem {
    const newMedia: MediaItem = {
      ...item,
      id: 'med-' + Date.now(),
      created_at: new Date().toISOString(),
    };
    memoryState.media = [newMedia, ...memoryState.media];
    notifyUpdate();
    void firestoreSync.persistMediaItem(newMedia);
    return newMedia;
  },

  deleteMediaItem(id: string) {
    memoryState.media = memoryState.media.filter((m) => m.id !== id);
    notifyUpdate();
    void firestoreSync.deleteMediaItem(id);
  },

  // Newsletter Subscribers
  getSubscribers(): NewsletterSubscriber[] {
    return memoryState.subscribers;
  },

  saveSubscribers(subs: NewsletterSubscriber[]) {
    memoryState.subscribers = subs;
    notifyUpdate();
  },

  subscribeEmail(email: string): { success: boolean; message: string } {
    const normalized = email.toLowerCase().trim();
    if (memoryState.auth.isAuthenticated) {
      const existing = memoryState.subscribers.find((s) => s.email === normalized);
      if (existing) {
        return {
          success: true,
          message: 'You are already registered on our subscriber dispatch!',
        };
      }
    }
    const newSub: NewsletterSubscriber = {
      id: `sub-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      email: normalized,
      is_active: true,
      confirmed_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
    };
    if (memoryState.auth.isAuthenticated) {
      memoryState.subscribers = [newSub, ...memoryState.subscribers];
      notifyUpdate();
    }
    void firestoreSync.persistSubscriber(newSub);
    return {
      success: true,
      message: 'Thank you for subscribing to TechFixGuide Engineering Dispatch!',
    };
  },

  deleteSubscriber(id: string) {
    memoryState.subscribers = memoryState.subscribers.filter((s) => s.id !== id);
    notifyUpdate();
    void firestoreSync.deleteSubscriber(id);
  },

  // Contact Messages
  getContactMessages(): ContactMessage[] {
    return memoryState.contactMessages;
  },

  saveContactMessages(msgs: ContactMessage[]) {
    memoryState.contactMessages = msgs;
    notifyUpdate();
  },

  submitContactMessage(
    data: Omit<ContactMessage, 'id' | 'is_read' | 'created_at'>
  ): ContactMessage {
    const newMsg: ContactMessage = {
      ...data,
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      is_read: false,
      created_at: new Date().toISOString(),
    };
    if (memoryState.auth.isAuthenticated) {
      memoryState.contactMessages = [newMsg, ...memoryState.contactMessages];
      notifyUpdate();
    }
    void firestoreSync.persistContactMessage(newMsg);
    return newMsg;
  },

  markMessageRead(id: string) {
    memoryState.contactMessages = memoryState.contactMessages.map((m) =>
      m.id === id ? { ...m, is_read: true } : m
    );
    notifyUpdate();
    void firestoreSync.markMessageRead(id);
  },

  // Ad Settings
  getAdSettings(): AdSettings {
    return memoryState.adSettings;
  },

  saveAdSettings(ads: AdSettings) {
    memoryState.adSettings = ads;
    notifyUpdate();
    void firestoreSync.persistAdSettings(ads);
  },

  // Site Settings
  getSiteSettings(): SiteSettings {
    return memoryState.siteSettings;
  },

  saveSiteSettings(settings: SiteSettings) {
    memoryState.siteSettings = settings;
    notifyUpdate();
    void firestoreSync.persistSiteSettings(settings);
  },

  // Authentication State (Firebase Auth + Google Sign-In)
  getAuthSession() {
    return memoryState.auth;
  },

  async loginWithGoogle(): Promise<{ success: boolean; error?: string }> {
    return firestoreSync.loginWithGoogle();
  },

  async logout(): Promise<void> {
    await firestoreSync.logout();
  },

  // Reset database to initial sample content (Admin only)
  resetToDefault() {
    memoryState.articles = [...INITIAL_ARTICLES];
    memoryState.categories = [...INITIAL_CATEGORIES];
    memoryState.authors = [...INITIAL_AUTHORS];
    memoryState.comments = [...INITIAL_COMMENTS];
    memoryState.media = [...INITIAL_MEDIA];
    memoryState.subscribers = [...INITIAL_SUBSCRIBERS];
    memoryState.contactMessages = [...INITIAL_CONTACT_MESSAGES];
    memoryState.adSettings = { ...INITIAL_AD_SETTINGS };
    memoryState.siteSettings = { ...INITIAL_SITE_SETTINGS };
    notifyUpdate();
    if (memoryState.auth.isAuthenticated) {
      void firestoreSync.seedInitialFirestoreDataIfEmpty(true);
    }
  },
};

// React hook for live data subscriptions
export function useAppStore() {
  const [version, setVersion] = useState(0);

  useEffect(() => {
    const handleUpdate = () => setVersion((v) => v + 1);
    window.addEventListener(DATA_SYNC_EVENT, handleUpdate);
    return () => {
      window.removeEventListener(DATA_SYNC_EVENT, handleUpdate);
    };
  }, []);

  return {
    articles: AppStore.getArticles(),
    categories: AppStore.getCategories(),
    authors: AppStore.getAuthors(),
    comments: AppStore.getComments(),
    media: AppStore.getMedia(),
    subscribers: AppStore.getSubscribers(),
    contactMessages: AppStore.getContactMessages(),
    adSettings: AppStore.getAdSettings(),
    siteSettings: AppStore.getSiteSettings(),
    auth: AppStore.getAuthSession(),
    refreshKey: version,
  };
}
