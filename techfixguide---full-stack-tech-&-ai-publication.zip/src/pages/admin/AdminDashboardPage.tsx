import React from 'react';
import { Link } from 'react-router-dom';
import { useAppStore, AppStore } from '../../lib/store';
import { formatDate } from '../../lib/utils';
import {
  FileText,
  Clock,
  Mail,
  FolderTree,
  DollarSign,
  PlusCircle,
  Eye,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  TrendingUp,
  MessageSquare,
} from 'lucide-react';

export function AdminDashboardPage() {
  const { articles, categories, subscribers, comments, adSettings } = useAppStore();

  const published = articles.filter((a) => a.status === 'published');
  const drafts = articles.filter((a) => a.status === 'draft');
  const scheduled = articles.filter((a) => a.status === 'scheduled');
  const pendingComments = comments.filter((a) => a.status === 'pending');

  const totalViews = articles.reduce((acc, curr) => acc + (curr.view_count || 0), 0);
  const recentArticles = articles.slice(0, 6);
  const recentSubscribers = subscribers.slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0b1528] tracking-tight">
            Editorial CMS Overview
          </h1>
          <p className="text-xs text-[#64748b]">
            Real-time status of publication content, monetization engines, and subscriber growth.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/admin/articles/new"
            className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] shadow-xs transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            Write New Guide
          </Link>
          <Link
            to="/admin/adsense"
            className="inline-flex items-center gap-2 rounded-xl bg-white border border-[#cbd5e1] px-4 py-2.5 text-xs font-bold text-[#0b1528] hover:bg-[#f8fafc] shadow-xs transition-all"
          >
            <DollarSign className="w-4 h-4 text-[#0062ff]" />
            Ad Engine
          </Link>
        </div>
      </div>

      {/* 5 Real Metrics Cards (No fabricated metrics) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-semibold">Published</span>
            <FileText className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-[#0b1528]">{published.length}</div>
          <span className="text-[10px] text-emerald-600 font-semibold">Active in public index</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-semibold">Working Drafts</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-[#0b1528]">{drafts.length}</div>
          <span className="text-[10px] text-amber-600 font-semibold">Not publicly visible</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-semibold">Subscribers</span>
            <Mail className="w-4 h-4 text-[#0062ff]" />
          </div>
          <div className="text-2xl font-black text-[#0b1528]">{subscribers.length}</div>
          <span className="text-[10px] text-[#0062ff] font-semibold">Verified emails</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-semibold">Categories</span>
            <FolderTree className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-black text-[#0b1528]">{categories.length}</div>
          <span className="text-[10px] text-purple-600 font-semibold">Active hubs</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-semibold">Pending Review</span>
            <MessageSquare className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-black text-[#0b1528]">{pendingComments.length}</div>
          <span className="text-[10px] text-rose-600 font-semibold">Comments to moderate</span>
        </div>
      </div>

      {/* Integration & Verification Status Bar */}
      <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528] mb-3">
          Platform Health & Crawl Verification
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#f8fafc] border border-[#e2e8f0]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <div>
              <div className="font-bold text-[#0b1528]">AdSense Architecture</div>
              <div className="text-[11px] text-[#64748b]">
                {adSettings.is_globally_enabled ? 'Monetization Active' : 'Monetization Paused'} · Pub ID: {adSettings.publisher_id}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#f8fafc] border border-[#e2e8f0]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <div>
              <div className="font-bold text-[#0b1528]">Dynamic XML Sitemap</div>
              <div className="text-[11px] text-[#64748b]">
                Feeds strictly published articles · Excludes {drafts.length} drafts
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#f8fafc] border border-[#e2e8f0]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <div>
              <div className="font-bold text-[#0b1528]">ads.txt Verification</div>
              <div className="text-[11px] text-[#64748b]">Direct publisher record synced</div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Stream & Recent Subscribers */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Recent Articles Table */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="p-5 border-b border-[#f1f5f9] flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#0b1528]">Recently Managed Articles</h3>
            <Link
              to="/admin/articles"
              className="text-xs font-bold text-[#0062ff] hover:underline"
            >
              View Full Index ({articles.length}) →
            </Link>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] font-semibold border-b border-[#e2e8f0]">
                <tr>
                  <th className="p-4">Guide Title</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Date</th>
                  <th className="p-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9] text-[#1e293b]">
                {recentArticles.map((art) => (
                  <tr key={art.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="p-4 font-semibold max-w-xs truncate">
                      <Link
                        to={`/admin/articles/edit/${art.id}`}
                        className="hover:text-[#0062ff]"
                      >
                        {art.title}
                      </Link>
                    </td>
                    <td className="p-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          art.status === 'published'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : art.status === 'draft'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-blue-50 text-blue-700 border border-blue-200'
                        }`}
                      >
                        {art.status}
                      </span>
                    </td>
                    <td className="p-4 text-[#64748b]">
                      {formatDate(art.published_at || art.created_at)}
                    </td>
                    <td className="p-4 text-right">
                      <Link
                        to={`/admin/articles/edit/${art.id}`}
                        className="font-bold text-[#0062ff] hover:underline mr-3"
                      >
                        Edit
                      </Link>
                      {art.status === 'published' && (
                        <Link
                          to={`/blog/${art.slug}`}
                          target="_blank"
                          className="font-medium text-[#64748b] hover:text-[#0b1528]"
                        >
                          View
                        </Link>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Subscribers & Fast Actions */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#0b1528]">Recent Subscribers</h3>
              <Link
                to="/admin/newsletter"
                className="text-xs font-bold text-[#0062ff] hover:underline"
              >
                Manage
              </Link>
            </div>
            <div className="space-y-3 divide-y divide-[#f1f5f9]">
              {recentSubscribers.map((sub, idx) => (
                <div key={sub.id} className={idx > 0 ? 'pt-3' : ''}>
                  <div className="text-xs font-semibold text-[#0b1528] truncate">
                    {sub.email}
                  </div>
                  <div className="text-[10px] text-[#94a3b8]">
                    Registered: {formatDate(sub.created_at)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions Card */}
          <div className="bg-[#0b1528] text-white rounded-2xl p-6 space-y-3">
            <h3 className="text-sm font-bold text-white">Editorial Shortcuts</h3>
            <div className="space-y-2 text-xs">
              <Link
                to="/admin/articles/new"
                className="block p-2.5 rounded-xl bg-[#152238] hover:bg-[#1e2c45] text-slate-200 transition-colors"
              >
                + Draft New Masterguide
              </Link>
              <Link
                to="/admin/comments"
                className="block p-2.5 rounded-xl bg-[#152238] hover:bg-[#1e2c45] text-slate-200 transition-colors"
              >
                Review Comments Queue ({pendingComments.length} pending)
              </Link>
              <Link
                to="/admin/adsense"
                className="block p-2.5 rounded-xl bg-[#152238] hover:bg-[#1e2c45] text-slate-200 transition-colors"
              >
                Configure AdSense Units & ads.txt
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
