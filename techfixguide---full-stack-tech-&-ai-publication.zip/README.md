# TECHFIXGUIDE — Full-Stack Technology & AI Publication
> **Tagline:** Learn. Fix. Grow.  
> **Mission:** Practical technology education, AI tutorials, web development, software guides, and digital productivity.

---

## Architecture Overview

**TechFixGuide** is built as an enterprise-grade technical publication platform pairing a public-facing editorial reader experience with a private administration CMS.

### Key Capabilities
1. **Brand Identity:**
   - Custom modern TF emblem and logotype
   - Editorial palette: Deep navy typography (`#0b1528`), electric blue accent (`#0062ff`), warm soft-gray canvas (`#f8fafc`)
   - Zero-pill metadata discipline (`Category · Date · Read time`) without artificial badges or layout shifts

2. **Public Website Features:**
   - **Homepage (`/`):** Hero with featured engineering masterguide, 6 specialization cards, latest article feed, trending reads, editor's picks, weekly newsletter box, and non-intrusive AdSense units
   - **All Guides Directory (`/blog`):** Category filter tabs, search filter, multi-criteria sorting (Newest, Oldest, Most Read, Longest), pagination, and reading time
   - **Article Details (`/blog/:slug`):** Dynamic SEO meta tags, breadcrumbs, author card with bio and links, auto-generated Table of Contents with smooth jump scrolling, rich HTML prose with code syntax styling, social sharing (Twitter, LinkedIn, Copy Link), related articles, previous/next guide cards, and moderated comments
   - **Category Hubs (`/category/:slug`):** Dedicated landing pages for 9 core disciplines (Web Development, Artificial Intelligence, WordPress, SEO & Marketing, Free Online Tools, E-commerce, Software & Technology, Cybersecurity, Tech Tutorials)
   - **Search Engine (`/search`):** Search by title, excerpt, full body content, category, or tags with live result counters and empty states
   - **Transparency & Legal Pages:** About Us (`/about`), Contact Form with direct database dispatch (`/contact`), Privacy Policy with Google DART cookie disclosures (`/privacy-policy`), Terms & Conditions (`/terms-and-conditions`), Disclaimer (`/disclaimer`), Cookie Policy (`/cookie-policy`), Visual & XML Sitemaps (`/sitemap`), Robots Directives (`/robots.txt`), and Live ads.txt (`/ads.txt`)

3. **Private Admin CMS (`/admin`):**
   - **Protected Route Authentication (`/admin/login`):** Role-based staff credentials. Default credentials provided:
     - **Email:** `admin@techfixguide.com`
     - **Password:** `techfix2026!`
   - **Dashboard Overview (`/admin`):** Real statistics (published count, drafts count, scheduled count, category count, subscriber count, pending comments), platform health checklist, recent articles, recent subscribers
   - **Article Editor (`/admin/articles/new` & `/admin/articles/edit/:id`):** Real rich-text formatting toolbar (H2, H3, Bold, Italic, Code Blocks, Quotes, Lists, Tables, Links), live visual preview tab, auto-generate suggested slug button, featured image media picker, category/author assignment, multi-tag input, SEO meta fields (title, description, canonical URL), reading time live calculator, unsaved edits warning
   - **Category Taxonomy Manager (`/admin/categories`):** Add, edit, and inspect guide counts per hub
   - **Media Library (`/admin/media`):** File upload validation (5MB max), alt text editing, URL copying, and asset deletion
   - **Comments Moderation Desk (`/admin/comments`):** Approve, reject, delete, or mark comments as spam. Only approved comments display publicly
   - **Newsletter Management (`/admin/newsletter`):** Subscriber database, manual subscriber registration, duplicate check, and instant CSV export download
   - **Google AdSense Engine (`/admin/adsense`):** Global monetization toggle, Publisher ID, Header, Sidebar, and In-Article slot configuration, live simulator sandbox, and ads.txt editor
   - **Platform Settings (`/admin/settings`):** Global site metadata, canonical domain, global comments toggle, full JSON database backup download, and reset to initial sample seed

---

## PostgreSQL & Supabase Database Migration

For backend deployment with PostgreSQL/Supabase, execute the SQL schema below in your database console:

```sql
-- 1. Create Enums
CREATE TYPE article_status AS ENUM ('draft', 'scheduled', 'published', 'archived');
CREATE TYPE user_role AS ENUM ('admin', 'editor', 'author');
CREATE TYPE comment_status AS ENUM ('pending', 'approved', 'rejected', 'spam');

-- 2. Profiles
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    avatar_url TEXT,
    bio TEXT,
    role user_role DEFAULT 'author' NOT NULL,
    twitter_handle TEXT,
    github_url TEXT,
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 3. Categories
CREATE TABLE public.categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    description TEXT,
    image_url TEXT,
    seo_title TEXT,
    seo_description TEXT
);

-- 4. Articles
CREATE TABLE public.articles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    subtitle TEXT,
    excerpt TEXT NOT NULL,
    content TEXT NOT NULL,
    featured_image TEXT NOT NULL,
    category_id UUID NOT NULL REFERENCES public.categories(id),
    author_id UUID NOT NULL REFERENCES public.profiles(id),
    status article_status DEFAULT 'draft' NOT NULL,
    published_at TIMESTAMPTZ,
    scheduled_for TIMESTAMPTZ,
    reading_time INT DEFAULT 3 NOT NULL,
    is_featured BOOLEAN DEFAULT FALSE,
    is_trending BOOLEAN DEFAULT FALSE,
    is_editors_pick BOOLEAN DEFAULT FALSE,
    seo_title TEXT,
    seo_description TEXT,
    canonical_url TEXT,
    og_image TEXT,
    view_count INT DEFAULT 0 NOT NULL,
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()) NOT NULL
);

-- 5. Row Level Security (RLS)
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public Read Published Articles" ON public.articles
FOR SELECT USING (status = 'published' AND (published_at IS NULL OR published_at <= NOW()));

CREATE POLICY "Admin Full Access" ON public.articles
FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));
```

---

## Local Development & Build

```bash
# Install dependencies
npm install

# Start development server on port 3000
npm run dev

# Run TypeScript checks
npm run lint

# Build production bundle
npm run build
```

---

## Default Administrator Access
- **Portal URL:** `/admin/login`
- **Email:** `admin@techfixguide.com`
- **Password:** `techfix2026!`
