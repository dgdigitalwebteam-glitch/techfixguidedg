import React from 'react';
import { Cookie } from 'lucide-react';

export function CookiePolicyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-8">
      <div className="space-y-2 border-b border-[#e2e8f0] pb-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
          <Cookie className="w-4 h-4" />
          <span>Storage & Consent</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0b1528] tracking-tight">
          Cookie Policy
        </h1>
        <p className="text-xs text-[#64748b]">Standards & Storage Directives</p>
      </div>

      <div className="editorial-prose text-sm">
        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text fragments stored on your device by your web browser when visiting sites. They allow sites to remember session authentication, preferences, and anonymous analytics.
        </p>

        <h2>How We Use Cookies & Local Storage</h2>
        <ul>
          <li><strong>Essential & Authentication:</strong> Session tokens that keep editorial administrators logged into the private CMS without transmitting plaintext credentials.</li>
          <li><strong>Preference Cookies:</strong> Remembering your custom sorting or view preferences across guide listings.</li>
          <li><strong>Advertising Partners:</strong> Google AdSense uses cookies to serve relevant technical ads and prevent repetitive ad delivery to the same visitor.</li>
        </ul>

        <h2>Managing Your Preferences</h2>
        <p>
          You can adjust cookie acceptance settings through your browser preferences. Disabling essential cookies may prevent administrative login to the CMS, but public article reading remains fully functional.
        </p>
      </div>
    </div>
  );
}
