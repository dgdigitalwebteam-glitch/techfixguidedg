import React from 'react';
import { AlertTriangle } from 'lucide-react';

export function DisclaimerPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-8">
      <div className="space-y-2 border-b border-[#e2e8f0] pb-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
          <AlertTriangle className="w-4 h-4" />
          <span>Transparency Notice</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0b1528] tracking-tight">
          Advertising & Affiliate Disclaimer
        </h1>
        <p className="text-xs text-[#64748b]">FTC & Google Publisher Compliance</p>
      </div>

      <div className="editorial-prose text-sm">
        <h2>1. Advertising Disclosure</h2>
        <p>
          <strong>TechFixGuide</strong> participates in digital advertising programs, including Google AdSense. Third-party advertising networks serve automated advertisements across designated slots on our site.
        </p>
        <p>
          We do not artificially inflate clicks or impressions, nor do we employ deceptive placement tactics. Advertisements are clearly distinguished by labeled borders or header disclosures.
        </p>

        <h2>2. Editorial Independence</h2>
        <p>
          Editorial reviews, hardware benchmarks, and software recommendations are formulated entirely by our editorial team without commercial sponsorship influence. We do not accept paid compensation for positive reviews.
        </p>

        <h2>3. Affiliate Links Disclosure</h2>
        <p>
          Certain links to developer tools, hardware items, or cloud hosting services may be affiliate links. If you make a purchase through these links, TechFixGuide may earn a nominal referral commission at no additional cost to you.
        </p>
      </div>
    </div>
  );
}
