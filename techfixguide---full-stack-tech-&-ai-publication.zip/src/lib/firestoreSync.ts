import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  Unsubscribe,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import {
  ADMIN_BOOTSTRAPPED_EMAIL,
  auth,
  db,
  googleAuthProvider,
  handleFirestoreError,
  OperationType,
} from './firebase';
import {
  AdSettings,
  Article,
  Category,
  Comment,
  ContactMessage,
  MediaItem,
  NewsletterSubscriber,
  Profile,
  SiteSettings,
} from '../types';

export interface AuthSessionState {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: Profile | null;
  error: string | null;
}

export interface StoreMemoryState {
  articles: Article[];
  categories: Category[];
  authors: Profile[];
  comments: Comment[];
  media: MediaItem[];
  subscribers: NewsletterSubscriber[];
  contactMessages: ContactMessage[];
  adSettings: AdSettings;
  siteSettings: SiteSettings;
  auth: AuthSessionState;
}

function toIsoString(value: unknown, fallback = ''): string {
  if (!value) return fallback;
  if (value instanceof Timestamp) return value.toDate().toISOString();
  if (typeof (value as { toDate?: () => Date }).toDate === 'function') {
    return (value as { toDate: () => Date }).toDate().toISOString();
  }
  if (typeof value === 'string') return value;
  return fallback;
}

function sortByDateDesc<T extends { created_at?: string; published_at?: string | null }>(
  items: T[],
  usePublished = false
): T[] {
  return [...items].sort((a, b) => {
    const da = new Date((usePublished ? a.published_at : null) || a.created_at || 0).getTime();
    const dbTime = new Date((usePublished ? b.published_at : null) || b.created_at || 0).getTime();
    return dbTime - da;
  });
}

function sanitizeArticlePayload(article: Article) {
  return {
    id: article.id,
    title: article.title.slice(0, 240),
    slug: article.slug.slice(0, 240),
    subtitle: (article.subtitle || '').slice(0, 400),
    excerpt: (article.excerpt || '').slice(0, 1000),
    content: (article.content || '').slice(0, 250000),
    featured_image: (article.featured_image || '').slice(0, 700000),
    category_id: article.category_id,
    tags: (article.tags || []).slice(0, 15).map((t) => t.slice(0, 50)).filter(Boolean),
    author_id: article.author_id,
    status: article.status,
    published_at: article.published_at ? article.published_at.slice(0, 64) : null,
    scheduled_for: article.scheduled_for ? article.scheduled_for.slice(0, 64) : null,
    reading_time: Math.max(0, Math.min(300, Math.round(article.reading_time || 1))),
    is_featured: Boolean(article.is_featured),
    is_trending: Boolean(article.is_trending),
    is_editors_pick: Boolean(article.is_editors_pick),
    seo_title: (article.seo_title || '').slice(0, 240),
    seo_description: (article.seo_description || '').slice(0, 500),
    canonical_url: (article.canonical_url || '').slice(0, 500),
    og_image: (article.og_image || '').slice(0, 700000),
    view_count: Math.max(0, Number(article.view_count || 0)),
  };
}

function sanitizeProfileForPublic(profile: Profile) {
  const payload: Record<string, string> = {
    id: profile.id,
    full_name: profile.full_name.slice(0, 120),
    avatar_url: (profile.avatar_url || '').slice(0, 1000),
    bio: (profile.bio || '').slice(0, 1000),
    role: profile.role,
  };
  if (profile.twitter_handle !== undefined) {
    payload.twitter_handle = profile.twitter_handle.slice(0, 80);
  }
  if (profile.linkedin_url !== undefined) {
    payload.linkedin_url = profile.linkedin_url.slice(0, 500);
  }
  if (profile.github_url !== undefined) {
    payload.github_url = profile.github_url.slice(0, 500);
  }
  return payload;
}

export class FirestoreSyncManager {
  private initialized = false;
  private adminSubscriptions: Unsubscribe[] = [];
  private publicCommentsMap = new Map<string, Comment>();
  private privateCommentEmails = new Map<string, string>();
  private adminArticlesActive = false;
  private adminCommentsActive = false;
  private seedingPromise: Promise<void> | null = null;

  constructor(
    private getState: () => StoreMemoryState,
    private getDefaults: () => Omit<StoreMemoryState, 'auth'>,
    private notify: () => void
  ) {}

  init() {
    if (this.initialized || typeof window === 'undefined') return;
    this.initialized = true;

    this.startPublicListeners();

    onAuthStateChanged(auth, async (firebaseUser) => {
      if (!firebaseUser) {
        this.teardownAdminListeners();
        this.getState().auth = {
          isAuthenticated: false,
          isLoading: false,
          user: null,
          error: null,
        };
        this.notify();
        return;
      }

      await this.handleAuthenticatedUser(firebaseUser);
    });
  }

  private async isAuthorizedAdmin(firebaseUser: User): Promise<boolean> {
    if (!firebaseUser.emailVerified) return false;
    if (firebaseUser.email === ADMIN_BOOTSTRAPPED_EMAIL) return true;

    const adminRef = doc(db, 'admins', firebaseUser.uid);
    try {
      const snap = await getDoc(adminRef);
      return snap.exists() && snap.data()?.role === 'admin';
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, `admins/${firebaseUser.uid}`);
    }
  }

  private async ensureBootstrappedAdminRecord(firebaseUser: User) {
    if (firebaseUser.email !== ADMIN_BOOTSTRAPPED_EMAIL || !firebaseUser.emailVerified) return;
    const adminRef = doc(db, 'admins', firebaseUser.uid);
    try {
      const snap = await getDoc(adminRef);
      if (!snap.exists()) {
        await setDoc(adminRef, {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          role: 'admin',
          created_at: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `admins/${firebaseUser.uid}`);
    }
  }

  private async handleAuthenticatedUser(firebaseUser: User) {
    try {
      const allowed = await this.isAuthorizedAdmin(firebaseUser);
      if (!allowed) {
        this.teardownAdminListeners();
        await signOut(auth);
        this.getState().auth = {
          isAuthenticated: false,
          isLoading: false,
          user: null,
          error: 'Access denied: this Google account is not authorized as a TechFixGuide administrator.',
        };
        this.notify();
        return;
      }

      await this.ensureBootstrappedAdminRecord(firebaseUser);

      const state = this.getState();
      const matchedAuthor = state.authors.find(
        (a) => a.email && firebaseUser.email && a.email.toLowerCase() === firebaseUser.email.toLowerCase()
      );
      const userProfile: Profile = matchedAuthor || {
        id: state.authors[0]?.id || 'author-1',
        full_name: firebaseUser.displayName || state.authors[0]?.full_name || 'Lead Administrator',
        email: firebaseUser.email || '',
        avatar_url:
          firebaseUser.photoURL ||
          state.authors[0]?.avatar_url ||
          'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        bio: state.authors[0]?.bio || 'TechFixGuide Lead Administrator',
        role: 'admin',
      };

      state.auth = {
        isAuthenticated: true,
        isLoading: false,
        user: userProfile,
        error: null,
      };
      this.notify();

      await this.seedInitialFirestoreDataIfEmpty();
      this.startAdminListeners();
    } catch (error) {
      this.teardownAdminListeners();
      this.getState().auth = {
        isAuthenticated: false,
        isLoading: false,
        user: null,
        error: error instanceof Error ? error.message : 'Authentication verification failed.',
      };
      this.notify();
    }
  }

  private startPublicListeners() {
    const state = this.getState();

    // 1. Public Published Articles
    const pubArticlesQuery = query(collection(db, 'articles'), where('status', '==', 'published'));
    onSnapshot(
      pubArticlesQuery,
      (snap) => {
        if (this.adminArticlesActive || snap.empty) return;
        const docs: Article[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            ...(data as Article),
            id: d.id,
            created_at: toIsoString(data.created_at),
            updated_at: toIsoString(data.updated_at),
          };
        });
        state.articles = sortByDateDesc(docs, true);
        this.notify();
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'articles');
      }
    );

    // 2. Public Categories
    const pubCategoriesQuery = query(collection(db, 'categories'), where('slug', '>', ''));
    onSnapshot(
      pubCategoriesQuery,
      (snap) => {
        if (snap.empty) return;
        state.categories = snap.docs.map((d) => ({
          ...(d.data() as Category),
          id: d.id,
        }));
        this.notify();
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'categories');
      }
    );

    // 3. Public Profiles (No PII)
    const pubProfilesQuery = query(
      collection(db, 'profiles'),
      where('role', 'in', ['admin', 'editor', 'author'])
    );
    onSnapshot(
      pubProfilesQuery,
      (snap) => {
        if (snap.empty) return;
        state.authors = snap.docs.map((d) => ({
          ...(d.data() as Omit<Profile, 'email'>),
          id: d.id,
          email: '',
        }));
        this.notify();
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'profiles');
      }
    );

    // 4. Public Approved Comments (No PII)
    const pubCommentsQuery = query(collection(db, 'comments'), where('status', '==', 'approved'));
    onSnapshot(
      pubCommentsQuery,
      (snap) => {
        if (this.adminCommentsActive || snap.empty) return;
        const docs: Comment[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            article_id: data.article_id,
            author_name: data.author_name,
            author_email: '',
            content: data.content,
            status: data.status,
            created_at: toIsoString(data.created_at),
          };
        });
        state.comments = sortByDateDesc(docs);
        this.notify();
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'comments');
      }
    );

    // 5. Public Ad Settings Singleton
    onSnapshot(
      doc(db, 'ad_settings', 'default'),
      (snap) => {
        if (!snap.exists()) return;
        state.adSettings = snap.data() as AdSettings;
        this.notify();
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'ad_settings/default');
      }
    );

    // 6. Public Site Settings Singleton
    onSnapshot(
      doc(db, 'site_settings', 'default'),
      (snap) => {
        if (!snap.exists()) return;
        state.siteSettings = snap.data() as SiteSettings;
        this.notify();
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, 'site_settings/default');
      }
    );
  }

  private mergeAdminComments() {
    const merged: Comment[] = Array.from(this.publicCommentsMap.values()).map((c) => ({
      ...c,
      author_email: this.privateCommentEmails.get(c.id) || c.author_email || '',
    }));
    this.getState().comments = sortByDateDesc(merged);
    this.notify();
  }

  private startAdminListeners() {
    this.teardownAdminListeners();
    const state = this.getState();

    // 1. All Articles (draft, scheduled, published, archived)
    this.adminArticlesActive = true;
    this.adminSubscriptions.push(
      onSnapshot(
        collection(db, 'articles'),
        (snap) => {
          const docs: Article[] = snap.docs.map((d) => {
            const data = d.data();
            return {
              ...(data as Article),
              id: d.id,
              created_at: toIsoString(data.created_at),
              updated_at: toIsoString(data.updated_at),
            };
          });
          state.articles = sortByDateDesc(docs);
          this.notify();
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'articles');
        }
      )
    );

    // 2. All Comments + Private Emails
    this.adminCommentsActive = true;
    this.adminSubscriptions.push(
      onSnapshot(
        collection(db, 'comments'),
        (snap) => {
          this.publicCommentsMap.clear();
          snap.docs.forEach((d) => {
            const data = d.data();
            this.publicCommentsMap.set(d.id, {
              id: d.id,
              article_id: data.article_id,
              author_name: data.author_name,
              author_email: '',
              content: data.content,
              status: data.status,
              created_at: toIsoString(data.created_at),
            });
          });
          this.mergeAdminComments();
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'comments');
        }
      )
    );

    this.adminSubscriptions.push(
      onSnapshot(
        collection(db, 'comment_private'),
        (snap) => {
          this.privateCommentEmails.clear();
          snap.docs.forEach((d) => {
            const data = d.data();
            this.privateCommentEmails.set(d.id, data.author_email || '');
          });
          if (this.publicCommentsMap.size > 0) {
            this.mergeAdminComments();
          }
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'comment_private');
        }
      )
    );

    // 3. Media Library
    this.adminSubscriptions.push(
      onSnapshot(
        collection(db, 'media'),
        (snap) => {
          const docs: MediaItem[] = snap.docs.map((d) => {
            const data = d.data();
            return {
              ...(data as MediaItem),
              id: d.id,
              created_at: toIsoString(data.created_at),
            };
          });
          state.media = sortByDateDesc(docs);
          this.notify();
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'media');
        }
      )
    );

    // 4. Newsletter Subscribers
    this.adminSubscriptions.push(
      onSnapshot(
        collection(db, 'newsletter_subscribers'),
        (snap) => {
          const docs: NewsletterSubscriber[] = snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              email: data.email,
              is_active: Boolean(data.is_active),
              confirmed_at: toIsoString(data.confirmed_at),
              created_at: toIsoString(data.created_at),
            };
          });
          state.subscribers = sortByDateDesc(docs);
          this.notify();
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'newsletter_subscribers');
        }
      )
    );

    // 5. Contact Messages
    this.adminSubscriptions.push(
      onSnapshot(
        collection(db, 'contact_messages'),
        (snap) => {
          const docs: ContactMessage[] = snap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              name: data.name,
              email: data.email,
              subject: data.subject,
              message: data.message,
              is_read: Boolean(data.is_read),
              created_at: toIsoString(data.created_at),
            };
          });
          state.contactMessages = sortByDateDesc(docs);
          this.notify();
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'contact_messages');
        }
      )
    );
  }

  private teardownAdminListeners() {
    this.adminArticlesActive = false;
    this.adminCommentsActive = false;
    this.adminSubscriptions.forEach((unsub) => unsub());
    this.adminSubscriptions = [];
  }

  async seedInitialFirestoreDataIfEmpty(force = false) {
    if (this.seedingPromise && !force) return this.seedingPromise;

    const run = async () => {
      try {
        if (!force) {
          const existingCats = await getDocs(
            query(collection(db, 'categories'), where('slug', '>', ''))
          );
          if (!existingCats.empty) return;
        }

        const defaults = this.getDefaults();
        const batch = writeBatch(db);

        for (const author of defaults.authors) {
          batch.set(doc(db, 'profiles', author.id), sanitizeProfileForPublic(author));
        }

        for (const cat of defaults.categories) {
          batch.set(doc(db, 'categories', cat.id), {
            id: cat.id,
            name: cat.name,
            slug: cat.slug,
            description: cat.description,
            image_url: cat.image_url,
            seo_title: cat.seo_title,
            seo_description: cat.seo_description,
          });
        }

        for (const art of defaults.articles) {
          batch.set(doc(db, 'articles', art.id), {
            ...sanitizeArticlePayload(art),
            created_at: serverTimestamp(),
            updated_at: serverTimestamp(),
          });
        }

        for (const med of defaults.media) {
          batch.set(doc(db, 'media', med.id), {
            id: med.id,
            name: med.name,
            url: med.url,
            size: med.size,
            mime_type: med.mime_type,
            alt_text: med.alt_text,
            created_at: serverTimestamp(),
          });
        }

        for (const comm of defaults.comments) {
          batch.set(doc(db, 'comments', comm.id), {
            id: comm.id,
            article_id: comm.article_id,
            author_name: comm.author_name,
            content: comm.content,
            status: comm.status,
            created_at: serverTimestamp(),
          });
          batch.set(doc(db, 'comment_private', comm.id), {
            comment_id: comm.id,
            author_email: comm.author_email,
            created_at: serverTimestamp(),
          });
        }

        for (const sub of defaults.subscribers) {
          batch.set(doc(db, 'newsletter_subscribers', sub.id), {
            id: sub.id,
            email: sub.email,
            is_active: true,
            confirmed_at: serverTimestamp(),
            created_at: serverTimestamp(),
          });
        }

        for (const msg of defaults.contactMessages) {
          batch.set(doc(db, 'contact_messages', msg.id), {
            id: msg.id,
            name: msg.name,
            email: msg.email,
            subject: msg.subject,
            message: msg.message,
            is_read: false,
            created_at: serverTimestamp(),
          });
        }

        batch.set(doc(db, 'ad_settings', 'default'), defaults.adSettings);
        batch.set(doc(db, 'site_settings', 'default'), defaults.siteSettings);

        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'initial_seed');
      }
    };

    this.seedingPromise = run().finally(() => {
      this.seedingPromise = null;
    });
    return this.seedingPromise;
  }

  async loginWithGoogle(): Promise<{ success: boolean; error?: string }> {
    try {
      const credential = await signInWithPopup(auth, googleAuthProvider);
      const allowed = await this.isAuthorizedAdmin(credential.user);
      if (!allowed) {
        await signOut(auth);
        const msg =
          'Access denied: this Google account is not authorized as a TechFixGuide administrator.';
        this.getState().auth = {
          isAuthenticated: false,
          isLoading: false,
          user: null,
          error: msg,
        };
        this.notify();
        return { success: false, error: msg };
      }
      await this.handleAuthenticatedUser(credential.user);
      return { success: true };
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Google authentication failed.';
      this.getState().auth = {
        ...this.getState().auth,
        isLoading: false,
        error: msg,
      };
      this.notify();
      return { success: false, error: msg };
    }
  }

  async logout(): Promise<void> {
    this.teardownAdminListeners();
    await signOut(auth);
    this.getState().auth = {
      isAuthenticated: false,
      isLoading: false,
      user: null,
      error: null,
    };
    this.notify();
  }

  async persistArticle(article: Article, isUpdate: boolean) {
    const path = `articles/${article.id}`;
    const payload = sanitizeArticlePayload(article);
    try {
      if (isUpdate) {
        const { id: _id, ...updatable } = payload;
        await updateDoc(doc(db, 'articles', article.id), {
          ...updatable,
          updated_at: serverTimestamp(),
        });
      } else {
        await setDoc(doc(db, 'articles', article.id), {
          ...payload,
          created_at: serverTimestamp(),
          updated_at: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(
        error,
        isUpdate ? OperationType.UPDATE : OperationType.CREATE,
        path
      );
    }
  }

  async deleteArticle(id: string) {
    const path = `articles/${id}`;
    try {
      await deleteDoc(doc(db, 'articles', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  async persistCategory(cat: Category, isUpdate: boolean) {
    const path = `categories/${cat.id}`;
    const fields = {
      name: cat.name.slice(0, 100),
      slug: cat.slug.slice(0, 120),
      description: (cat.description || '').slice(0, 1000),
      image_url: (cat.image_url || '').slice(0, 1000),
      seo_title: (cat.seo_title || '').slice(0, 200),
      seo_description: (cat.seo_description || '').slice(0, 500),
    };
    try {
      if (isUpdate) {
        await updateDoc(doc(db, 'categories', cat.id), fields);
      } else {
        await setDoc(doc(db, 'categories', cat.id), {
          id: cat.id,
          ...fields,
        });
      }
    } catch (error) {
      handleFirestoreError(
        error,
        isUpdate ? OperationType.UPDATE : OperationType.CREATE,
        path
      );
    }
  }

  async persistAuthors(authors: Profile[]) {
    try {
      const batch = writeBatch(db);
      for (const author of authors) {
        batch.set(doc(db, 'profiles', author.id), sanitizeProfileForPublic(author));
      }
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'profiles');
    }
  }

  async persistNewComment(comment: Comment) {
    const path = `comments/${comment.id}`;
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'comments', comment.id), {
        id: comment.id,
        article_id: comment.article_id,
        author_name: comment.author_name.slice(0, 100),
        content: comment.content.slice(0, 3000),
        status: 'pending',
        created_at: serverTimestamp(),
      });
      batch.set(doc(db, 'comment_private', comment.id), {
        comment_id: comment.id,
        author_email: comment.author_email.slice(0, 254),
        created_at: serverTimestamp(),
      });
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }

  async updateCommentStatus(id: string, status: Comment['status']) {
    const path = `comments/${id}`;
    try {
      await updateDoc(doc(db, 'comments', id), { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  async deleteComment(id: string) {
    const path = `comments/${id}`;
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'comments', id));
      batch.delete(doc(db, 'comment_private', id));
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  async persistMediaItem(item: MediaItem) {
    const path = `media/${item.id}`;
    try {
      await setDoc(doc(db, 'media', item.id), {
        id: item.id,
        name: item.name.slice(0, 255),
        url: item.url.slice(0, 700000),
        size: Math.max(0, Number(item.size || 0)),
        mime_type: item.mime_type.slice(0, 100),
        alt_text: (item.alt_text || '').slice(0, 300),
        created_at: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }

  async deleteMediaItem(id: string) {
    const path = `media/${id}`;
    try {
      await deleteDoc(doc(db, 'media', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  async persistSubscriber(sub: NewsletterSubscriber) {
    const path = `newsletter_subscribers/${sub.id}`;
    try {
      await setDoc(doc(db, 'newsletter_subscribers', sub.id), {
        id: sub.id,
        email: sub.email.slice(0, 254),
        is_active: true,
        confirmed_at: serverTimestamp(),
        created_at: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }

  async deleteSubscriber(id: string) {
    const path = `newsletter_subscribers/${id}`;
    try {
      await deleteDoc(doc(db, 'newsletter_subscribers', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  async persistContactMessage(msg: ContactMessage) {
    const path = `contact_messages/${msg.id}`;
    try {
      await setDoc(doc(db, 'contact_messages', msg.id), {
        id: msg.id,
        name: msg.name.slice(0, 120),
        email: msg.email.slice(0, 254),
        subject: msg.subject.slice(0, 200),
        message: msg.message.slice(0, 5000),
        is_read: false,
        created_at: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }

  async markMessageRead(id: string) {
    const path = `contact_messages/${id}`;
    try {
      await updateDoc(doc(db, 'contact_messages', id), { is_read: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  async persistAdSettings(ads: AdSettings) {
    const path = 'ad_settings/default';
    try {
      await setDoc(doc(db, 'ad_settings', 'default'), {
        publisher_id: (ads.publisher_id || '').slice(0, 100),
        is_globally_enabled: Boolean(ads.is_globally_enabled),
        header_ad_code: (ads.header_ad_code || '').slice(0, 5000),
        header_ad_enabled: Boolean(ads.header_ad_enabled),
        sidebar_ad_code: (ads.sidebar_ad_code || '').slice(0, 5000),
        sidebar_ad_enabled: Boolean(ads.sidebar_ad_enabled),
        in_article_ad_code: (ads.in_article_ad_code || '').slice(0, 5000),
        in_article_ad_enabled: Boolean(ads.in_article_ad_enabled),
        footer_ad_code: (ads.footer_ad_code || '').slice(0, 5000),
        footer_ad_enabled: Boolean(ads.footer_ad_enabled),
        ads_txt_content: (ads.ads_txt_content || '').slice(0, 5000),
        verification_code: (ads.verification_code || '').slice(0, 1000),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  async persistSiteSettings(settings: SiteSettings) {
    const path = 'site_settings/default';
    try {
      await setDoc(doc(db, 'site_settings', 'default'), {
        site_name: settings.site_name.slice(0, 120),
        site_tagline: (settings.site_tagline || '').slice(0, 200),
        site_description: (settings.site_description || '').slice(0, 500),
        site_url: (settings.site_url || '').slice(0, 300),
        support_email: settings.support_email.slice(0, 254),
        comments_enabled_globally: Boolean(settings.comments_enabled_globally),
        posts_per_page: Math.max(1, Math.min(100, Number(settings.posts_per_page || 6))),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
}
