import React from 'react';
import { Link } from 'react-router-dom';
import { useAppStore } from '../lib/store';
import { ArticleCard } from '../components/articles/ArticleCard';
import { AdSlot } from '../components/ads/AdSlot';
import { NewsletterBox } from '../components/forms/NewsletterBox';
import {
  Sparkles,
  TrendingUp,
  Award,
  ArrowRight,
  Cpu,
  Layers,
  Terminal,
  ShieldCheck,
  BookOpen,
} from 'lucide-react';

export function HomePage() {
  const { articles, categories } = useAppStore();

  const published = articles.filter((a) => a.status === 'published');
  const featuredArticle = published.find((a) => a.is_featured) || published[0];
  const trendingArticles = published.filter((a) => a.is_trending).slice(0, 4);
  const editorsPicks = published.filter((a) => a.is_editors_pick).slice(0, 3);
  const latestArticles = published.filter((a) => a.id !== featuredArticle?.id).slice(0, 6);

  return (
    <div className="space-y-16 py-6">
      {/* Header Ad Slot (if configured and enabled) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdSlot type="header" />
      </div>

      {/* Hero Showcase Section */}
      {featuredArticle && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-3xl bg-[#0b1528] text-white shadow-xl border border-[#1e2c45]">
            <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
              <div className="p-8 sm:p-12 lg:p-16 lg:col-span-7 space-y-6">
                <div className="inline-flex items-center gap-2 rounded-full bg-[#0062ff]/15 px-3.5 py-1 text-xs font-semibold text-[#60a5fa] border border-[#0062ff]/30">
                  <Sparkles className="w-3.5 h-3.5 text-[#0062ff]" />
                  <span>Featured Engineering Masterguide</span>
                </div>

                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
                  <Link
                    to={`/blog/${featuredArticle.slug}`}
                    className="hover:text-blue-300 transition-colors"
                  >
                    {featuredArticle.title}
                  </Link>
                </h1>

                <p className="text-base sm:text-lg text-slate-300 line-clamp-3 leading-relaxed">
                  {featuredArticle.excerpt}
                </p>

                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <Link
                    to={`/blog/${featuredArticle.slug}`}
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#0062ff] px-6 py-3.5 text-xs font-bold text-white shadow-md hover:bg-[#004ecc] transition-all"
                  >
                    Read Complete Blueprint
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                  <span className="text-xs text-slate-400 font-medium">
                    {featuredArticle.reading_time} min read · Tested code included
                  </span>
                </div>
              </div>

              <div className="relative h-64 lg:h-full lg:col-span-5 min-h-[380px] bg-slate-900">
                <img
                  src={featuredArticle.featured_image}
                  alt={featuredArticle.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b1528] via-transparent to-transparent lg:hidden" />
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Specialization Category Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-[#0b1528] tracking-tight">
              Explore Core Specializations
            </h2>
            <p className="text-xs text-[#64748b]">
              Peer-reviewed technical blueprints arranged by engineering domain
            </p>
          </div>
          <Link
            to="/blog"
            className="text-xs font-bold text-[#0062ff] hover:text-[#004ecc] flex items-center gap-1"
          >
            All Guides <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {categories.slice(0, 6).map((cat) => (
            <Link
              key={cat.id}
              to={`/category/${cat.slug}`}
              className="flex flex-col items-center justify-center p-4 rounded-xl bg-white border border-[#e2e8f0] hover:border-[#0062ff] hover:shadow-sm transition-all text-center group"
            >
              <span className="text-xs font-bold text-[#1e293b] group-hover:text-[#0062ff] transition-colors">
                {cat.name}
              </span>
              <span className="text-[10px] text-[#94a3b8] mt-1 font-medium">
                {articles.filter((a) => a.category_id === cat.id && a.status === 'published').length} Guides
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Main Editorial Feed & Sidebar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Main Content Column */}
          <div className="lg:col-span-8 space-y-8">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-4">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#0062ff]" />
                <h2 className="text-2xl font-extrabold text-[#0b1528] tracking-tight">
                  Latest Technical Insights
                </h2>
              </div>
              <span className="text-xs text-[#64748b] font-medium">Updated Daily</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {latestArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>

            {latestArticles.length === 0 && (
              <div className="p-12 text-center rounded-2xl bg-white border border-[#e2e8f0]">
                <p className="text-xs text-[#64748b]">No articles currently published.</p>
              </div>
            )}

            <div className="pt-4 text-center">
              <Link
                to="/blog"
                className="inline-flex items-center gap-2 rounded-xl border border-[#cbd5e1] bg-white px-6 py-3 text-xs font-bold text-[#0b1528] hover:border-[#0062ff] hover:text-[#0062ff] shadow-xs transition-all"
              >
                Browse Complete Archive ({published.length} articles)
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* In-Feed Advertisement */}
            <AdSlot type="in-article" />
          </div>

          {/* Editorial Sidebar */}
          <aside className="lg:col-span-4 space-y-8">
            {/* Newsletter Dispatch Widget */}
            <NewsletterBox compact={true} />

            {/* Sidebar Ad Placement */}
            <AdSlot type="sidebar" />

            {/* Trending Articles Widget */}
            {trendingArticles.length > 0 && (
              <div className="rounded-2xl bg-white border border-[#e2e8f0] p-6 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0b1528] mb-4">
                  <TrendingUp className="w-4 h-4 text-[#0062ff]" />
                  Trending Reads
                </div>
                <div className="space-y-4 divide-y divide-[#f1f5f9]">
                  {trendingArticles.map((item, idx) => (
                    <div key={item.id} className={idx > 0 ? 'pt-4' : ''}>
                      <Link
                        to={`/blog/${item.slug}`}
                        className="group block space-y-1"
                      >
                        <h4 className="text-xs font-bold text-[#1e293b] group-hover:text-[#0062ff] transition-colors line-clamp-2 leading-snug">
                          {item.title}
                        </h4>
                        <div className="flex items-center gap-2 text-[11px] text-[#94a3b8]">
                          <span>{item.reading_time} min read</span>
                          <span aria-hidden="true">·</span>
                          <span>{item.view_count.toLocaleString()} views</span>
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Editor's Choice Picks */}
            {editorsPicks.length > 0 && (
              <div className="rounded-2xl bg-white border border-[#e2e8f0] p-6 shadow-xs">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0b1528] mb-4">
                  <Award className="w-4 h-4 text-[#0062ff]" />
                  Editor&apos;s Picks
                </div>
                <div className="space-y-4 divide-y divide-[#f1f5f9]">
                  {editorsPicks.map((item, idx) => (
                    <div key={item.id} className={idx > 0 ? 'pt-4' : ''}>
                      <Link
                        to={`/blog/${item.slug}`}
                        className="group block space-y-1"
                      >
                        <h4 className="text-xs font-bold text-[#1e293b] group-hover:text-[#0062ff] transition-colors line-clamp-2 leading-snug">
                          {item.title}
                        </h4>
                        <p className="text-[11px] text-[#64748b] line-clamp-2">
                          {item.excerpt}
                        </p>
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Editorial Standard Assurance */}
            <div className="rounded-2xl bg-[#f8fafc] border border-[#e2e8f0] p-6 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-[#0b1528]">
                <ShieldCheck className="w-4 h-4 text-[#0062ff]" />
                Zero-Slop Quality Assurance
              </div>
              <p className="text-xs text-[#64748b] leading-relaxed">
                Every code snippet and CLI guide is run against actual production runtimes before publication. No automated hallucinated text.
              </p>
            </div>
          </aside>
        </div>
      </section>

      {/* Full-Width Newsletter Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <NewsletterBox compact={false} />
      </section>
    </div>
  );
}
