import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from '../ui/Logo';
import { ShieldCheck, FileText, ExternalLink, Rss } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-[#1e2c45] bg-[#0b1528] text-slate-300 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4">
            <Logo isLight={true} />
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              Empowering engineers, systems architects, and developers through verifiable technical tutorials, web architecture teardowns, and actionable AI guides.
            </p>
            <div className="flex items-center gap-3 pt-2 text-xs text-slate-400">
              <span className="flex items-center gap-1 text-[#0062ff] font-semibold">
                <ShieldCheck className="w-4 h-4" />
                No Hallucinated Benchmarks
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Tested Runtimes</span>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Core Specializations
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/category/artificial-intelligence" className="hover:text-white transition-colors">
                  Artificial Intelligence
                </Link>
              </li>
              <li>
                <Link to="/category/web-development" className="hover:text-white transition-colors">
                  Web Development
                </Link>
              </li>
              <li>
                <Link to="/category/cybersecurity" className="hover:text-white transition-colors">
                  Cybersecurity
                </Link>
              </li>
              <li>
                <Link to="/category/tech-tutorials" className="hover:text-white transition-colors">
                  Tech Tutorials
                </Link>
              </li>
              <li>
                <Link to="/category/free-online-tools" className="hover:text-white transition-colors">
                  Free Online Tools
                </Link>
              </li>
              <li>
                <Link to="/category/wordpress" className="hover:text-white transition-colors">
                  WordPress & Headless
                </Link>
              </li>
            </ul>
          </div>

          {/* Editorial & Legal */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Editorial & Legal
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Contact Editorial
                </Link>
              </li>
              <li>
                <Link to="/privacy-policy" className="hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms-and-conditions" className="hover:text-white transition-colors">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link to="/disclaimer" className="hover:text-white transition-colors">
                  Affiliate & Ad Disclaimer
                </Link>
              </li>
              <li>
                <Link to="/cookie-policy" className="hover:text-white transition-colors">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* SEO & Crawl Feeds */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Index Feeds & Ads
            </h4>
            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              Machine-readable endpoints for search engine spiders and AdSense crawlers.
            </p>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/sitemap" className="text-[#0062ff] hover:underline flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5" />
                  XML Sitemap Feed
                </Link>
              </li>
              <li>
                <Link to="/robots.txt" className="text-[#0062ff] hover:underline flex items-center gap-1">
                  <ExternalLink className="w-3.5 h-3.5" />
                  Robots.txt Directives
                </Link>
              </li>
              <li>
                <Link to="/ads.txt" className="text-[#0062ff] hover:underline flex items-center gap-1">
                  <ExternalLink className="w-3.5 h-3.5" />
                  Publisher Verification (ads.txt)
                </Link>
              </li>
              <li className="pt-2">
                <Link to="/admin" className="text-slate-400 hover:text-white flex items-center gap-1">
                  CMS Administration
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-[#1e2c45] text-xs text-slate-400 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>© {currentYear} TechFixGuide. Built with precision for the modern software industry.</p>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Google AdSense Compliant</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span>WCAG 2.1 AA Accessible</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span>Zero-Shift CSS</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
