import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAppStore } from '../lib/store';
import { ArticleCard } from '../components/articles/ArticleCard';
import { AdSlot } from '../components/ads/AdSlot';
import { ArrowLeft, BookOpen, Layers } from 'lucide-react';

export function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const { categories, articles } = useAppStore();

  const category = categories.find((c) => c.slug === slug);

  useEffect(() => {
    if (category) {
      document.title = `${category.seo_title || category.name} | TechFixGuide`;
    }
  }, [category]);

  if (!category) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <h1 className="text-3xl font-extrabold text-[#0b1528]">Category Not Found</h1>
        <p className="text-sm text-[#64748b]">The requested discipline does not exist.</p>
        <Link
          to="/blog"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0062ff] text-white text-xs font-bold"
        >
          <ArrowLeft className="w-4 h-4" />
          View All Categories
        </Link>
      </div>
    );
  }

  const categoryArticles = articles.filter(
    (a) => a.category_id === category.id && a.status === 'published'
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Category Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-[#0b1528] text-white border border-[#1e2c45] shadow-lg">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
          <div className="p-8 sm:p-12 lg:col-span-8 space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
              <Layers className="w-4 h-4" />
              <span>Specialized Knowledge Hub</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight">
              {category.name}
            </h1>
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
              {category.description}
            </p>
            <div className="text-xs text-slate-400 pt-2 flex items-center gap-4">
              <span>{categoryArticles.length} Published Blueprint{categoryArticles.length === 1 ? '' : 's'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>100% Peer-Reviewed</span>
            </div>
          </div>

          <div className="relative h-48 lg:h-full lg:col-span-4 min-h-[220px]">
            <img
              src={category.image_url}
              alt={category.name}
              className="w-full h-full object-cover opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0b1528] via-transparent to-transparent lg:hidden" />
          </div>
        </div>
      </div>

      {/* Header Ad Slot */}
      <AdSlot type="header" />

      {/* Articles Listing */}
      <div className="space-y-6">
        <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-4">
          <h2 className="text-xl font-bold text-[#0b1528]">
            Curated Guides in {category.name}
          </h2>
          <span className="text-xs text-[#64748b]">Sorted by Publication Date</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categoryArticles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>

        {categoryArticles.length === 0 && (
          <div className="p-16 text-center rounded-2xl bg-white border border-[#e2e8f0] space-y-4">
            <BookOpen className="w-8 h-8 text-[#94a3b8] mx-auto" />
            <h3 className="text-base font-bold text-[#0b1528]">No articles yet in this category</h3>
            <p className="text-xs text-[#64748b] max-w-sm mx-auto">
              Our engineering team is drafting guides for {category.name}. Check back soon or view our other categories.
            </p>
            <Link
              to="/blog"
              className="inline-block px-4 py-2 rounded-xl bg-[#0b1528] text-white text-xs font-bold"
            >
              Explore Other Categories
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
