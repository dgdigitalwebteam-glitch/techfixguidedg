/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Link, Outlet } from 'react-router-dom';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { ErrorBoundary } from './components/ui/ErrorBoundary';

// Public Pages
import { HomePage } from './pages/HomePage';
import { BlogListingPage } from './pages/BlogListingPage';
import { ArticleDetailPage } from './pages/ArticleDetailPage';
import { CategoryPage } from './pages/CategoryPage';
import { SearchPage } from './pages/SearchPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { TermsPage } from './pages/TermsPage';
import { DisclaimerPage } from './pages/DisclaimerPage';
import { CookiePolicyPage } from './pages/CookiePolicyPage';
import { SitemapPage } from './pages/SitemapPage';
import { RobotsTxtPage } from './pages/RobotsTxtPage';
import { AdsTxtPage } from './pages/AdsTxtPage';

// Admin CMS Components & Pages
import { AdminLayout } from './components/admin/AdminLayout';
import { AdminLoginPage } from './pages/admin/AdminLoginPage';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminArticlesListPage } from './pages/admin/AdminArticlesListPage';
import { AdminArticleEditorPage } from './pages/admin/AdminArticleEditorPage';
import { AdminCategoriesPage } from './pages/admin/AdminCategoriesPage';
import { AdminMediaPage } from './pages/admin/AdminMediaPage';
import { AdminCommentsPage } from './pages/admin/AdminCommentsPage';
import { AdminNewsletterPage } from './pages/admin/AdminNewsletterPage';
import { AdminAdSensePage } from './pages/admin/AdminAdSensePage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';
import { AdminProfilePage } from './pages/admin/AdminProfilePage';

// Public Layout Container
function PublicLayout() {
  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc] text-[#0b1528] selection:bg-[#0062ff] selection:text-white">
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

// 404 Not Found Page
function NotFoundPage() {
  return (
    <div className="max-w-xl mx-auto px-4 py-24 text-center space-y-6">
      <div className="text-6xl font-black text-[#0062ff]">404</div>
      <h1 className="text-3xl font-black text-[#0b1528]">Resource Unavailable</h1>
      <p className="text-xs text-[#64748b] leading-relaxed">
        The requested URL was not located in our technical publication index. It may have been renamed or archived during an architectural upgrade.
      </p>
      <div className="flex justify-center gap-3">
        <Link
          to="/"
          className="px-5 py-2.5 rounded-xl bg-[#0062ff] text-white text-xs font-bold hover:bg-[#004ecc] transition-all"
        >
          Return to Publication Home
        </Link>
        <Link
          to="/blog"
          className="px-5 py-2.5 rounded-xl border border-[#cbd5e1] text-[#0b1528] text-xs font-bold hover:bg-slate-100 transition-all"
        >
          Browse All Guides
        </Link>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          {/* Public Website Routes */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/blog" element={<BlogListingPage />} />
            <Route path="/blog/:slug" element={<ArticleDetailPage />} />
            <Route path="/category/:slug" element={<CategoryPage />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
            <Route path="/terms-and-conditions" element={<TermsPage />} />
            <Route path="/disclaimer" element={<DisclaimerPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
            <Route path="/sitemap" element={<SitemapPage />} />
            <Route path="/sitemap.xml" element={<SitemapPage />} />
            <Route path="/robots.txt" element={<RobotsTxtPage />} />
            <Route path="/ads.txt" element={<AdsTxtPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>

          {/* Admin Login Route */}
          <Route path="/admin/login" element={<AdminLoginPage />} />

          {/* Protected Admin CMS Routes */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboardPage />} />
            <Route path="articles" element={<AdminArticlesListPage />} />
            <Route path="articles/new" element={<AdminArticleEditorPage />} />
            <Route path="articles/edit/:id" element={<AdminArticleEditorPage />} />
            <Route path="categories" element={<AdminCategoriesPage />} />
            <Route path="media" element={<AdminMediaPage />} />
            <Route path="comments" element={<AdminCommentsPage />} />
            <Route path="newsletter" element={<AdminNewsletterPage />} />
            <Route path="adsense" element={<AdminAdSensePage />} />
            <Route path="settings" element={<AdminSettingsPage />} />
            <Route path="profile" element={<AdminProfilePage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
