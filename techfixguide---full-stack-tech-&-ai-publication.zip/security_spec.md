# Security Specification — TechFixGuide Firestore Rules

## Data Invariants
1. Public readers may only `get` or `list` articles where `status == 'published'`. Draft, scheduled, and archived articles are strictly restricted to authenticated administrators.
2. Public readers may only `get` or `list` comments where `status == 'approved'`. Commenter email addresses (`comment_private`) are isolated from public reads.
3. Public comment creation must set `status == 'pending'`, reference an existing published article (`exists(/databases/$(database)/documents/articles/$(article_id))`), and use server `request.time` for `created_at` (or validated ISO string within bounds when synced via client, wait: we should use server timestamps or strict validation—let's enforce `request.time` on `created_at` / `serverTimestamp()` in Firestore!).
4. `newsletter_subscribers` and `contact_messages` contain PII and are strictly write-only (create) for public users and read/update/delete only for authenticated administrators.
5. `admins`, `media`, `categories`, `profiles`, `ad_settings`, and `site_settings` are modifiable only by verified administrators (`request.auth.token.email_verified == true` and bootstrapped admin email or `admins/{uid}` record).
6. Every document ID path variable is validated with `isValidId()` on single-document operations (`get`, `create`, `update`, `delete`), and every string/list field has explicit `.size()` constraints.

## Dirty Dozen Adversarial Payloads (Expected: PERMISSION_DENIED)
1. **Shadow Field Injection on Comment**: `{ id: 'c1', article_id: 'art-1', author_name: 'Alice', content: 'Hello', status: 'pending', created_at: request.time, isAdmin: true }` -> Blocked by `keys().hasOnly(...)`.
2. **Comment Auto-Approval Bypass**: `{ ..., status: 'approved' }` submitted by non-admin -> Blocked by `incoming().status == 'pending'`.
3. **Orphaned Comment**: `{ ..., article_id: 'non-existent-article' }` -> Blocked by `exists(/databases/$(database)/documents/articles/$(incoming().article_id))`.
4. **Backdated Comment Timestamp**: `{ ..., created_at: '2020-01-01T00:00:00Z' }` -> Blocked by `incoming().created_at == request.time`.
5. **Unauthenticated Draft Article Read**: `get(/articles/draft-1)` by anonymous user -> Blocked by `existing().status == 'published'`.
6. **Public Listing of Drafts**: `list(/articles)` without `where('status', '==', 'published')` -> Blocked by `resource.data.status == 'published'`.
7. **PII Scraping on Newsletter Subscribers**: `list(/newsletter_subscribers)` by non-admin -> Blocked by `isBootstrappedAdmin()`.
8. **PII Scraping on Contact Messages**: `get(/contact_messages/msg-1)` by non-admin -> Blocked by `isAdmin()`.
9. **ID Poisoning Attack**: `create(/comments/aaaa...[200 chars])` -> Blocked by `isValidId(commentId)`.
10. **Oversized Payload / Denial of Wallet**: `create(/contact_messages/m1)` with 50KB `message` -> Blocked by `data.message.size() <= 5000`.
11. **Unverified Admin Email Spoof**: Token with `email: 'danishbhatttti19@gmail.com'` and `email_verified: false` -> Blocked by `request.auth.token.email_verified == true`.
12. **Role Self-Escalation**: Non-admin attempting `create(/admins/my-uid)` -> Blocked by `isBootstrappedAdmin()`.
