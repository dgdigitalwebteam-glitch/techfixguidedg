import React, { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useAppStore } from '../lib/store';
import { ArticleCard } from '../components/articles/ArticleCard';
import { AdSlot } from '../components/ads/AdSlot';
import { Search, Filter, ArrowLeft, ArrowRight, BookOpen } from 'lucide-react';

export function BlogListingPage() {
  const { articles, categories, siteSettings } = useAppStore();
  const [searchParams, setSearchParams] = useSearchParams();

  const selectedCategory = searchParams.get('category') || 'all';
  const sortParam = searchParams.get('sort') || 'newest';
  const [currentPage, setCurrentPage] = useState(1);
  const [filterText, setFilterText] = useState('');

  const postsPerPage = siteSettings.posts_per_page || 6;

  // Filter published articles only
  const filteredArticles = useMemo(() => {
    let list = articles.filter((a) => a.status === 'published');

    if (selectedCategory !== 'all') {
      list = list.filter((a) => a.category_id === selectedCategory);
    }

    if (filterText.trim()) {
      const q = filterText.toLowerCase();
      list = list.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.excerpt.toLowerCase().includes(q) ||
          a.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    // Sort
    switch (sortParam) {
      case 'popular':
        return list.sort((a, b) => b.view_count - a.view_count);
      case 'reading-time':
        return list.sort((a, b) => b.reading_time - a.reading_time);
      case 'oldest':
        return list.sort((a, b) => new Date(a.published_at || '').getTime() - new Date(b.published_at || '').getTime());
      case 'newest':
      default:
        return list.sort((a, b) => new Date(b.published_at || '').getTime() - new Date(a.published_at || '').getTime());
    }
  }, [articles, selectedCategory, sortParam, filterText]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredArticles.length / postsPerPage) || 1;
  const paginatedArticles = filteredArticles.slice(
    (currentPage - 1) * postsPerPage,
    currentPage * postsPerPage
  );

  const handleCategorySelect = (catId: string) => {
    setCurrentPage(1);
    if (catId === 'all') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', catId);
    }
    setSearchParams(searchParams);
  };

  const handleSortChange = (newSort: string) => {
    setCurrentPage(1);
    searchParams.set('sort', newSort);
    setSearchParams(searchParams);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Header Banner */}
      <div className="border-b border-[#e2e8f0] pb-8 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
          <BookOpen className="w-4 h-4" />
          <span>Editorial Directory</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0b1528] tracking-tight">
          All Guides, Fixes & Blueprints
        </h1>
        <p className="text-sm text-[#64748b] max-w-2xl leading-relaxed">
          Comprehensive, reproducible technical tutorials covering cloud infrastructure, local AI execution, full-stack web engineering, and defensive cybersecurity.
        </p>
      </div>

      {/* Header Ad Slot */}
      <AdSlot type="header" />

      {/* Functional Interactive Filter Controls (Segmented bar allowed per frontend-design skill) */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
          <button
            onClick={() => handleCategorySelect('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-[#0b1528] text-white shadow-xs'
                : 'bg-white border border-[#cbd5e1] text-[#475569] hover:text-[#0b1528]'
            }`}
          >
            All Disciplines
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategorySelect(cat.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-[#0062ff] text-white shadow-xs'
                  : 'bg-white border border-[#cbd5e1] text-[#475569] hover:text-[#0b1528]'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Filter Input and Sort Control */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 sm:w-56">
            <input
              type="text"
              placeholder="Filter keyword..."
              value={filterText}
              onChange={(e) => {
                setFilterText(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full rounded-xl border border-[#cbd5e1] bg-white pl-8 pr-3 py-1.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
            />
            <Search className="w-3.5 h-3.5 text-[#94a3b8] absolute left-2.5 top-2.5" />
          </div>

          <select
            value={sortParam}
            onChange={(e) => handleSortChange(e.target.value)}
            className="rounded-xl border border-[#cbd5e1] bg-white px-3 py-1.5 text-xs font-medium text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
          >
            <option value="newest">Sort: Newest First</option>
            <option value="oldest">Sort: Oldest First</option>
            <option value="popular">Sort: Most Read</option>
            <option value="reading-time">Sort: Longest Read</option>
          </select>
        </div>
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {paginatedArticles.map((article) => (
          <ArticleCard key={article.id} article={article} />
        ))}
      </div>

      {/* Empty State */}
      {paginatedArticles.length === 0 && (
        <div className="p-16 text-center rounded-2xl bg-white border border-[#e2e8f0] space-y-4">
          <div className="w-12 h-12 rounded-full bg-[#f1f5f9] flex items-center justify-center mx-auto text-[#64748b]">
            <Filter className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-[#0b1528]">No articles found</h3>
          <p className="text-xs text-[#64748b] max-w-sm mx-auto">
            Try adjusting your search keywords or switching category filters.
          </p>
          <button
            onClick={() => {
              setFilterText('');
              handleCategorySelect('all');
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0b1528] text-white text-xs font-bold hover:bg-[#1e2c45]"
          >
            Clear All Filters
          </button>
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-6 border-t border-[#e2e8f0]">
          <span className="text-xs text-[#64748b]">
            Showing {(currentPage - 1) * postsPerPage + 1} to{' '}
            {Math.min(currentPage * postsPerPage, filteredArticles.length)} of{' '}
            {filteredArticles.length} guides
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1.5 rounded-lg border border-[#cbd5e1] text-xs font-semibold text-[#0b1528] hover:bg-[#f8fafc] disabled:opacity-40 flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Previous
            </button>
            <span className="text-xs font-bold text-[#0b1528] px-2">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1.5 rounded-lg border border-[#cbd5e1] text-xs font-semibold text-[#0b1528] hover:bg-[#f8fafc] disabled:opacity-40 flex items-center gap-1"
            >
              Next
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
