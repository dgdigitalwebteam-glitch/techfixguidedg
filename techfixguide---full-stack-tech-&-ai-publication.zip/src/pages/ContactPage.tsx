import React, { useState } from 'react';
import { AppStore } from '../lib/store';
import { Mail, Send, CheckCircle2, MapPin, Clock, MessageSquare } from 'lucide-react';

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState<{ success: boolean; message: string } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !subject.trim() || message.trim().length < 5) {
      setStatus({
        success: false,
        message: 'Please complete all fields and provide a message of at least 5 characters.',
      });
      return;
    }

    setIsSubmitting(true);
    setStatus(null);

    setTimeout(() => {
      AppStore.submitContactMessage({
        name: name.trim(),
        email: email.trim(),
        subject: subject.trim(),
        message: message.trim(),
      });

      setIsSubmitting(false);
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
      setStatus({
        success: true,
        message: 'Your inquiry has been logged in our editorial system. Our technical staff responds within 24-48 business hours.',
      });
    }, 400);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Page Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff] bg-blue-50 px-3 py-1 rounded-full">
          <Mail className="w-3.5 h-3.5" />
          Editorial & Staff Desk
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0b1528] tracking-tight">
          Contact TechFixGuide
        </h1>
        <p className="text-sm text-[#64748b] leading-relaxed">
          Submit technical bug corrections, proposal pitches, software review requests, or advertising inquiries.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Contact Info Sidebar */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-2xl border border-[#e2e8f0] bg-white p-6 space-y-6 shadow-xs">
            <h3 className="text-base font-bold text-[#0b1528]">Direct Communications</h3>

            <div className="space-y-4 text-xs text-[#64748b]">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0062ff] flex items-center justify-center flex-shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-[#0b1528]">Editorial Staff</div>
                  <div>editorial@techfixguide.com</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0062ff] flex items-center justify-center flex-shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-[#0b1528]">Review SLA</div>
                  <div>Peer review response: 24-48 hours</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0062ff] flex items-center justify-center flex-shrink-0">
                  <MessageSquare className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-[#0b1528]">Security Vulnerabilities</div>
                  <div>security@techfixguide.com (PGP available upon request)</div>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-[#0b1528] text-white p-6 space-y-3">
            <h4 className="text-sm font-bold text-[#60a5fa]">Submitting a Tech Fix?</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              When reporting code bugs or benchmark anomalies, please include operating system, compiler version, and minimal reproducible repo links.
            </p>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7">
          <form
            onSubmit={handleSubmit}
            className="rounded-2xl border border-[#e2e8f0] bg-white p-8 space-y-5 shadow-xs"
          >
            <h3 className="text-lg font-bold text-[#0b1528]">Send an In-Depth Message</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Sarah Connor"
                  className="w-full rounded-xl border border-[#cbd5e1] p-3 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">Professional Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sarah@corp.com"
                  className="w-full rounded-xl border border-[#cbd5e1] p-3 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">Subject Topic</label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Clarification regarding vLLM tensor parallelism benchmarks"
                className="w-full rounded-xl border border-[#cbd5e1] p-3 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">Message Content</label>
              <textarea
                required
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Provide detailed explanation or requirements..."
                className="w-full rounded-xl border border-[#cbd5e1] p-3 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-[#0062ff] px-6 py-3 text-xs font-bold text-white hover:bg-[#004ecc] transition-all disabled:opacity-50 shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              {isSubmitting ? 'Transmitting Inbound Message...' : 'Dispatch Message'}
            </button>

            {status && (
              <div
                className={`flex items-start gap-2.5 p-3.5 rounded-xl text-xs ${
                  status.success
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-red-50 text-red-800 border border-red-200'
                }`}
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <span>{status.message}</span>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
