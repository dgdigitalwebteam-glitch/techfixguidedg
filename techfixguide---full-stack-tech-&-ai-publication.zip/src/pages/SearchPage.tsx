import React, { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useAppStore } from '../lib/store';
import { ArticleCard } from '../components/articles/ArticleCard';
import { Search, Tag as TagIcon, X, Filter } from 'lucide-react';

export function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTag, setSelectedTag] = useState<string>('all');

  const { articles, categories } = useAppStore();

  // Aggregate all unique tags from published articles
  const allTags = useMemo(() => {
    const set = new Set<string>();
    articles.forEach((a) => {
      if (a.status === 'published' && a.tags) {
        a.tags.forEach((t) => set.add(t));
      }
    });
    return Array.from(set).sort();
  }, [articles]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ q: query });
  };

  const results = useMemo(() => {
    let list = articles.filter((a) => a.status === 'published');

    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.subtitle?.toLowerCase().includes(q) ||
          a.excerpt.toLowerCase().includes(q) ||
          a.content.toLowerCase().includes(q) ||
          a.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    if (selectedCategory !== 'all') {
      list = list.filter((a) => a.category_id === selectedCategory);
    }

    if (selectedTag !== 'all') {
      list = list.filter((a) => a.tags && a.tags.includes(selectedTag));
    }

    return list;
  }, [articles, query, selectedCategory, selectedTag]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Search Bar & Header */}
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <h1 className="text-3xl font-extrabold text-[#0b1528] tracking-tight">
          Search Technical Blueprints
        </h1>
        <p className="text-xs text-[#64748b]">
          Find diagnostic guides, code snippets, AI frameworks, and software fixes.
        </p>

        <form onSubmit={handleSearchSubmit} className="relative mt-4">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search keywords (e.g. vLLM, PostgreSQL, CSS Subgrid, mTLS)..."
            className="w-full rounded-2xl border border-[#cbd5e1] bg-white pl-12 pr-28 py-3.5 text-sm text-[#0b1528] shadow-xs focus:outline-none focus:border-[#0062ff] focus:ring-1 focus:ring-[#0062ff]"
          />
          <Search className="w-5 h-5 text-[#94a3b8] absolute left-4 top-4" />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setSearchParams({});
              }}
              className="absolute right-24 top-3.5 p-1 text-[#94a3b8] hover:text-[#0b1528]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            type="submit"
            className="absolute right-2 top-2 rounded-xl bg-[#0062ff] px-4 py-2 text-xs font-bold text-white hover:bg-[#004ecc] transition-all"
          >
            Search
          </button>
        </form>
      </div>

      {/* Filter Chips Bar (interactive tabs allowed by frontend design skill) */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-[#e2e8f0]">
        {/* Category Selector */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-[#64748b]" />
          <span className="text-xs font-semibold text-[#0b1528]">Category:</span>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="rounded-lg border border-[#cbd5e1] px-2.5 py-1 text-xs text-[#0b1528] bg-[#f8fafc]"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        {/* Tag Selector */}
        <div className="flex items-center gap-2">
          <TagIcon className="w-3.5 h-3.5 text-[#64748b]" />
          <span className="text-xs font-semibold text-[#0b1528]">Filter Tag:</span>
          <select
            value={selectedTag}
            onChange={(e) => setSelectedTag(e.target.value)}
            className="rounded-lg border border-[#cbd5e1] px-2.5 py-1 text-xs text-[#0b1528] bg-[#f8fafc]"
          >
            <option value="all">All Tags</option>
            {allTags.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        <div className="text-xs text-[#64748b] font-medium">
          {results.length} result{results.length === 1 ? '' : 's'} found
        </div>
      </div>

      {/* Results Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {results.map((article) => (
          <ArticleCard key={article.id} article={article} />
        ))}
      </div>

      {/* Empty State */}
      {results.length === 0 && (
        <div className="p-16 text-center rounded-2xl bg-white border border-[#e2e8f0] space-y-4 max-w-xl mx-auto">
          <div className="w-12 h-12 rounded-full bg-[#f1f5f9] flex items-center justify-center mx-auto text-[#64748b]">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-[#0b1528]">
            No matching guides found
          </h3>
          <p className="text-xs text-[#64748b] leading-relaxed">
            We couldn&apos;t find any published tutorials matching &quot;{query}&quot;. Try broader technical terms or explore our popular categories.
          </p>
          <div className="flex flex-wrap justify-center gap-2 pt-2">
            <button
              onClick={() => {
                setQuery('AI');
                setSearchParams({ q: 'AI' });
              }}
              className="px-3 py-1 bg-[#f1f5f9] text-xs font-semibold rounded-lg text-[#0b1528] hover:bg-slate-200"
            >
              #AI
            </button>
            <button
              onClick={() => {
                setQuery('PostgreSQL');
                setSearchParams({ q: 'PostgreSQL' });
              }}
              className="px-3 py-1 bg-[#f1f5f9] text-xs font-semibold rounded-lg text-[#0b1528] hover:bg-slate-200"
            >
              #PostgreSQL
            </button>
            <button
              onClick={() => {
                setQuery('CSS');
                setSearchParams({ q: 'CSS' });
              }}
              className="px-3 py-1 bg-[#f1f5f9] text-xs font-semibold rounded-lg text-[#0b1528] hover:bg-slate-200"
            >
              #CSS
            </button>
            <button
              onClick={() => {
                setQuery('Zero-Trust');
                setSearchParams({ q: 'Zero-Trust' });
              }}
              className="px-3 py-1 bg-[#f1f5f9] text-xs font-semibold rounded-lg text-[#0b1528] hover:bg-slate-200"
            >
              #Zero-Trust
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
