import React from 'react';
import { useAppStore } from '../../lib/store';

interface AdSlotProps {
  type: 'header' | 'sidebar' | 'in-article' | 'footer';
  className?: string;
}

export function AdSlot({ type, className = '' }: AdSlotProps) {
  const { adSettings } = useAppStore();

  if (!adSettings.is_globally_enabled) {
    return null;
  }

  let isEnabled = false;
  let code = '';
  let slotLabel = '';
  let minHeight = 'min-h-[90px]';

  switch (type) {
    case 'header':
      isEnabled = adSettings.header_ad_enabled;
      code = adSettings.header_ad_code;
      slotLabel = 'Header Advertisement (Leaderboard 728x90)';
      minHeight = 'min-h-[90px]';
      break;
    case 'sidebar':
      isEnabled = adSettings.sidebar_ad_enabled;
      code = adSettings.sidebar_ad_code;
      slotLabel = 'Sidebar Advertisement (Rectangle 300x250)';
      minHeight = 'min-h-[250px]';
      break;
    case 'in-article':
      isEnabled = adSettings.in_article_ad_enabled;
      code = adSettings.in_article_ad_code;
      slotLabel = 'In-Article Display (Responsive Native)';
      minHeight = 'min-h-[120px]';
      break;
    case 'footer':
      isEnabled = adSettings.footer_ad_enabled;
      code = adSettings.footer_ad_code;
      slotLabel = 'Footer Advertisement';
      minHeight = 'min-h-[90px]';
      break;
  }

  if (!isEnabled || !code.trim()) {
    return null;
  }

  return (
    <aside
      aria-label="Advertisement"
      className={`my-6 flex flex-col items-center justify-center rounded-xl border border-dashed border-[#cbd5e1] bg-[#f8fafc] p-3 text-center transition-all ${className}`}
    >
      <div className="flex items-center gap-2 mb-2 text-[10px] font-bold uppercase tracking-wider text-[#94a3b8]">
        <span>Advertisement</span>
        <span aria-hidden="true">·</span>
        <span>Google AdSense</span>
      </div>
      <div
        className={`w-full overflow-hidden flex items-center justify-center ${minHeight}`}
        dangerouslySetInnerHTML={{ __html: code }}
      />
    </aside>
  );
}
