import React, { useState } from 'react';
import { useAppStore, AppStore } from '../../lib/store';
import { generateSlug } from '../../lib/utils';
import { Category } from '../../types';
import { FolderTree, Plus, Edit2, Check, X } from 'lucide-react';

export function AdminCategoriesPage() {
  const { categories, articles } = useAppStore();

  const [editingCat, setEditingCat] = useState<Partial<Category> | null>(null);
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDescription, setSeoDescription] = useState('');

  const startEdit = (cat?: Category) => {
    if (cat) {
      setEditingCat(cat);
      setName(cat.name);
      setSlug(cat.slug);
      setDescription(cat.description || '');
      setImageUrl(cat.image_url || '');
      setSeoTitle(cat.seo_title || '');
      setSeoDescription(cat.seo_description || '');
    } else {
      setEditingCat({});
      setName('');
      setSlug('');
      setDescription('');
      setImageUrl('https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80');
      setSeoTitle('');
      setSeoDescription('');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    AppStore.saveCategory({
      id: editingCat?.id,
      name: name.trim(),
      slug: slug.trim() ? generateSlug(slug) : generateSlug(name),
      description: description.trim(),
      image_url: imageUrl.trim(),
      seo_title: seoTitle.trim() || name.trim(),
      seo_description: seoDescription.trim() || description.trim(),
    });

    setEditingCat(null);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
            Specialization Categories
          </h1>
          <p className="text-xs text-[#64748b]">
            Configure topic taxonomies, hero imagery, and SEO metadata for each publication hub.
          </p>
        </div>

        <button
          onClick={() => startEdit()}
          className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] shadow-xs"
        >
          <Plus className="w-4 h-4" />
          Add Specialization
        </button>
      </div>

      {/* Editing Form Modal / Inline Box */}
      {editingCat && (
        <form onSubmit={handleSave} className="bg-white p-6 rounded-2xl border border-[#cbd5e1] shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-[#f1f5f9] pb-3">
            <h3 className="text-sm font-bold text-[#0b1528]">
              {editingCat.id ? `Edit Category: ${editingCat.name}` : 'Create New Category'}
            </h3>
            <button
              type="button"
              onClick={() => setEditingCat(null)}
              className="p-1 text-slate-400 hover:text-[#0b1528]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">Category Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (!editingCat.id) setSlug(generateSlug(e.target.value));
                }}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">Slug URL</label>
              <input
                type="text"
                required
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] font-mono focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-[#475569] mb-1">Hero Image URL</label>
              <input
                type="url"
                required
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-[#475569] mb-1">Hub Description</label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setEditingCat(null)}
              className="px-4 py-2 rounded-xl border border-[#cbd5e1] text-xs font-semibold text-[#0b1528]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#0062ff] text-white text-xs font-bold hover:bg-[#004ecc]"
            >
              Save Category
            </button>
          </div>
        </form>
      )}

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat) => {
          const articleCount = articles.filter((a) => a.category_id === cat.id).length;

          return (
            <div
              key={cat.id}
              className="bg-white rounded-2xl border border-[#e2e8f0] shadow-xs overflow-hidden flex flex-col justify-between"
            >
              <div className="relative h-32 w-full bg-slate-100">
                <img src={cat.image_url} alt={cat.name} className="w-full h-full object-cover" />
                <div className="absolute top-3 right-3 bg-[#0b1528]/80 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                  {articleCount} Guides
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-base font-bold text-[#0b1528]">{cat.name}</h3>
                  <div className="text-[11px] font-mono text-[#0062ff]">/category/{cat.slug}</div>
                  <p className="text-xs text-[#64748b] line-clamp-2 mt-2 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-between text-xs">
                  <a
                    href={`/category/${cat.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#64748b] hover:text-[#0b1528]"
                  >
                    View Public Hub ↗
                  </a>
                  <button
                    onClick={() => startEdit(cat)}
                    className="text-[#0062ff] font-bold hover:underline flex items-center gap-1"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> Edit
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
