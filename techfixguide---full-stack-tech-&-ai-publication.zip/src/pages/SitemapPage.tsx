import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAppStore } from '../lib/store';
import { formatDate } from '../lib/utils';
import { FileCode, Globe, Copy, Check, ExternalLink } from 'lucide-react';

export function SitemapPage() {
  const { articles, categories, siteSettings } = useAppStore();
  const [viewMode, setViewMode] = useState<'visual' | 'xml'>('visual');
  const [copied, setCopied] = useState(false);

  const publishedArticles = articles.filter((a) => a.status === 'published');
  const baseUrl = siteSettings.site_url || 'https://techfixguide.com';

  const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <!-- Core Static Routes -->
  <url>
    <loc>${baseUrl}/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${baseUrl}/blog</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${baseUrl}/about</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>${baseUrl}/contact</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>

  <!-- Categories -->
${categories
  .map(
    (c) => `  <url>
    <loc>${baseUrl}/category/${c.slug}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`
  )
  .join('\n')}

  <!-- Published, Indexable Articles Only (Drafts Excluded) -->
${publishedArticles
  .map(
    (a) => `  <url>
    <loc>${baseUrl}/blog/${a.slug}</loc>
    <lastmod>${(a.updated_at || a.created_at).split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`
  )
  .join('\n')}
</urlset>`;

  const handleCopyXML = () => {
    navigator.clipboard.writeText(xmlContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-6">
        <div>
          <h1 className="text-3xl font-extrabold text-[#0b1528] tracking-tight">
            Index Sitemap & Crawl Feeds
          </h1>
          <p className="text-xs text-[#64748b] mt-1">
            Real-time sitemap reflecting strictly published & indexable URLs (drafts blocked).
          </p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-[#f1f5f9] rounded-xl border border-[#cbd5e1]">
          <button
            onClick={() => setViewMode('visual')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              viewMode === 'visual'
                ? 'bg-white text-[#0b1528] shadow-xs'
                : 'text-[#64748b] hover:text-[#0b1528]'
            }`}
          >
            Visual Directory
          </button>
          <button
            onClick={() => setViewMode('xml')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              viewMode === 'xml'
                ? 'bg-white text-[#0b1528] shadow-xs'
                : 'text-[#64748b] hover:text-[#0b1528]'
            }`}
          >
            Raw XML Feed
          </button>
        </div>
      </div>

      {viewMode === 'visual' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Categories */}
          <div className="rounded-2xl border border-[#e2e8f0] bg-white p-6 space-y-4 shadow-xs">
            <h3 className="text-base font-bold text-[#0b1528]">Specialization Hubs ({categories.length})</h3>
            <ul className="space-y-2 text-xs">
              {categories.map((c) => (
                <li key={c.id}>
                  <Link
                    to={`/category/${c.slug}`}
                    className="text-[#0062ff] hover:underline font-semibold flex items-center justify-between"
                  >
                    <span>{c.name}</span>
                    <span className="text-[#94a3b8] font-normal">/category/{c.slug}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Published Articles */}
          <div className="rounded-2xl border border-[#e2e8f0] bg-white p-6 space-y-4 shadow-xs">
            <h3 className="text-base font-bold text-[#0b1528]">
              Published & Indexable Guides ({publishedArticles.length})
            </h3>
            <ul className="space-y-3 text-xs max-h-[420px] overflow-y-auto pr-2 divide-y divide-[#f1f5f9]">
              {publishedArticles.map((a) => (
                <li key={a.id} className="pt-2 first:pt-0">
                  <Link
                    to={`/blog/${a.slug}`}
                    className="text-[#0b1528] hover:text-[#0062ff] font-semibold line-clamp-1"
                  >
                    {a.title}
                  </Link>
                  <div className="text-[11px] text-[#94a3b8] mt-0.5">
                    Updated: {formatDate(a.updated_at || a.published_at)}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-[#64748b]">Content-Type: application/xml</span>
            <button
              onClick={handleCopyXML}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0b1528] text-white text-xs font-semibold hover:bg-[#1e2c45]"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied XML' : 'Copy Sitemap XML'}
            </button>
          </div>
          <pre className="p-4 rounded-2xl bg-[#0b1528] text-slate-100 font-mono text-xs overflow-x-auto border border-[#1e2c45] max-h-[500px]">
            {xmlContent}
          </pre>
        </div>
      )}
    </div>
  );
}
