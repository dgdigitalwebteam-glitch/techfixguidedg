import React, { useState } from 'react';
import { Link, useLocation, useNavigate, Outlet, Navigate } from 'react-router-dom';
import { useAppStore, AppStore } from '../../lib/store';
import { Logo } from '../ui/Logo';
import {
  LayoutDashboard,
  FileText,
  PlusCircle,
  FolderTree,
  Image as ImageIcon,
  MessageSquare,
  Mail,
  DollarSign,
  Sliders,
  User,
  LogOut,
  ExternalLink,
  Menu,
  X,
} from 'lucide-react';

export function AdminLayout() {
  const { auth, comments } = useAppStore();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  if (auth.isLoading) {
    return (
      <div className="min-h-screen bg-[#0b1528] flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-2 border-[#0062ff] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-300">
            Verifying editorial session...
          </p>
        </div>
      </div>
    );
  }

  // Protected route enforcement
  if (!auth.isAuthenticated) {
    return <Navigate to="/admin/login" replace />;
  }

  const pendingCommentsCount = comments.filter((c) => c.status === 'pending').length;

  const NAV_ITEMS = [
    { label: 'Overview', href: '/admin', icon: LayoutDashboard },
    { label: 'All Articles', href: '/admin/articles', icon: FileText },
    { label: 'New Article', href: '/admin/articles/new', icon: PlusCircle },
    { label: 'Categories', href: '/admin/categories', icon: FolderTree },
    { label: 'Media Library', href: '/admin/media', icon: ImageIcon },
    {
      label: 'Comments',
      href: '/admin/comments',
      icon: MessageSquare,
      badge: pendingCommentsCount > 0 ? pendingCommentsCount : undefined,
    },
    { label: 'Newsletter', href: '/admin/newsletter', icon: Mail },
    { label: 'AdSense Engine', href: '/admin/adsense', icon: DollarSign },
    { label: 'Site Settings', href: '/admin/settings', icon: Sliders },
    { label: 'Staff Profile', href: '/admin/profile', icon: User },
  ];

  const handleLogout = async () => {
    await AppStore.logout();
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-[#f1f5f9] flex flex-col lg:flex-row">
      {/* Mobile Top Header */}
      <div className="lg:hidden bg-[#0b1528] text-white px-4 py-3 flex items-center justify-between border-b border-[#1e2c45]">
        <Logo isLight={true} />
        <button
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          className="p-1.5 text-slate-300 hover:text-white"
        >
          {mobileSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Sidebar Navigation */}
      <aside
        className={`fixed lg:sticky top-0 z-50 h-screen w-64 bg-[#0b1528] text-slate-300 border-r border-[#1e2c45] flex flex-col justify-between transition-transform duration-300 ${
          mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-6 space-y-6 overflow-y-auto">
          <div className="flex items-center justify-between">
            <Logo isLight={true} />
            <button
              onClick={() => setMobileSidebarOpen(false)}
              className="lg:hidden text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
            Editorial Management
          </div>

          <nav className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive =
                item.href === '/admin'
                  ? location.pathname === '/admin'
                  : location.pathname.startsWith(item.href);

              return (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setMobileSidebarOpen(false)}
                  className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#0062ff] text-white shadow-xs'
                      : 'text-slate-400 hover:bg-[#152238] hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className="bg-amber-500 text-[#0b1528] font-bold text-[10px] px-1.5 py-0.2 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* User Card & Actions */}
        <div className="p-6 border-t border-[#1e2c45] space-y-3 bg-[#070d1e]">
          <div className="flex items-center gap-3">
            <img
              src={
                auth.user?.avatar_url ||
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'
              }
              alt={auth.user?.full_name || 'Admin'}
              className="w-8 h-8 rounded-full object-cover border border-slate-700"
            />
            <div className="overflow-hidden">
              <div className="text-xs font-bold text-white truncate">
                {auth.user?.full_name || 'Lead Administrator'}
              </div>
              <div className="text-[10px] text-slate-400 capitalize">
                Role: {auth.user?.role || 'admin'}
              </div>
            </div>
          </div>

          <div className="pt-2 flex flex-col space-y-1 text-xs">
            <Link
              to="/"
              target="_blank"
              className="flex items-center justify-between text-slate-400 hover:text-white py-1 px-1.5 rounded"
            >
              <span className="flex items-center gap-1.5">
                <ExternalLink className="w-3.5 h-3.5 text-[#0062ff]" />
                View Public Site
              </span>
            </Link>

            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 text-red-400 hover:text-red-300 py-1 px-1.5 rounded text-left transition-colors font-semibold"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign Out Session
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-8 lg:p-10 max-h-screen overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}
