import React from 'react';
import { Link } from 'react-router-dom';
import { Article } from '../../types';
import { formatDate } from '../../lib/utils';
import { useAppStore } from '../../lib/store';
import { Clock, Eye, ArrowUpRight } from 'lucide-react';

interface ArticleCardProps {
  article: Article;
  featured?: boolean;
}

export function ArticleCard({ article, featured = false }: ArticleCardProps) {
  const { categories, authors } = useAppStore();
  const category = categories.find((c) => c.id === article.category_id);
  const author = authors.find((a) => a.id === article.author_id);

  if (featured) {
    return (
      <article className="group relative overflow-hidden rounded-2xl bg-white border border-[#e2e8f0] shadow-sm hover:shadow-md transition-all duration-300">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 items-center">
          <div className="relative aspect-[16/10] lg:aspect-auto lg:h-full lg:col-span-7 overflow-hidden bg-[#f1f5f9]">
            <img
              src={article.featured_image}
              alt={article.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              loading="lazy"
            />
          </div>

          <div className="p-6 sm:p-8 lg:p-10 lg:col-span-5 flex flex-col justify-between">
            <div>
              {/* Quiet unboxed text metadata with typographic separators */}
              <div className="flex items-center gap-2 text-xs font-semibold text-[#0062ff] uppercase tracking-wider mb-3">
                <span>{category?.name || 'Technical Guide'}</span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className="text-[#64748b] font-medium lowercase first-letter:uppercase">{formatDate(article.published_at)}</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-[#0b1528] tracking-tight leading-snug group-hover:text-[#0062ff] transition-colors mb-3">
                <Link to={`/blog/${article.slug}`}>
                  {article.title}
                </Link>
              </h3>

              <p className="text-sm text-[#475569] line-clamp-3 leading-relaxed mb-6">
                {article.excerpt}
              </p>
            </div>

            <div className="pt-4 border-t border-[#f1f5f9] flex items-center justify-between text-xs text-[#64748b]">
              <div className="flex items-center gap-2.5">
                <img
                  src={author?.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                  alt={author?.full_name || 'Author'}
                  className="w-7 h-7 rounded-full object-cover border border-[#cbd5e1]"
                />
                <span className="font-semibold text-[#0b1528]">{author?.full_name || 'TechFix Editorial'}</span>
              </div>

              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 font-medium">
                  <Clock className="w-3.5 h-3.5 text-[#0062ff]" />
                  {article.reading_time} min
                </span>
                <Link
                  to={`/blog/${article.slug}`}
                  className="font-bold text-[#0062ff] hover:text-[#004ecc] flex items-center gap-0.5"
                >
                  Read
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </article>
    );
  }

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl bg-white border border-[#e2e8f0] shadow-xs hover:shadow-md transition-all duration-300">
      <Link to={`/blog/${article.slug}`} className="relative aspect-[16/9] w-full overflow-hidden bg-[#f1f5f9]">
        <img
          src={article.featured_image}
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
      </Link>

      <div className="flex flex-1 flex-col p-6">
        {/* Quiet unboxed metadata */}
        <div className="flex items-center gap-2 text-xs text-[#64748b] mb-2.5">
          <Link
            to={`/category/${category?.slug || 'tech'}`}
            className="font-semibold text-[#0062ff] hover:underline"
          >
            {category?.name || 'General Tech'}
          </Link>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>{formatDate(article.published_at)}</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-[#94a3b8]" />
            {article.reading_time} min
          </span>
        </div>

        <h3 className="text-lg font-bold text-[#0b1528] group-hover:text-[#0062ff] transition-colors line-clamp-2 mb-2 leading-snug">
          <Link to={`/blog/${article.slug}`}>{article.title}</Link>
        </h3>

        <p className="text-xs text-[#475569] line-clamp-2 leading-relaxed mb-6 flex-1">
          {article.excerpt}
        </p>

        <div className="flex items-center justify-between pt-4 border-t border-[#f1f5f9] text-xs text-[#64748b]">
          <span className="font-semibold text-[#0b1528] truncate max-w-[150px]">
            {author?.full_name || 'Staff Editor'}
          </span>
          <Link
            to={`/blog/${article.slug}`}
            className="font-bold text-[#0062ff] hover:text-[#004ecc] flex items-center gap-0.5"
          >
            Read Guide
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </article>
  );
}
