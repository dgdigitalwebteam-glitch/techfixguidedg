import React, { useState } from 'react';
import { AppStore } from '../../lib/store';
import { Mail, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';

interface NewsletterBoxProps {
  compact?: boolean;
}

export function NewsletterBox({ compact = false }: NewsletterBoxProps) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<{ success: boolean; message: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setStatus({ success: false, message: 'Please provide a valid email address.' });
      return;
    }

    setIsSubmitting(true);
    setStatus(null);

    setTimeout(() => {
      const res = AppStore.subscribeEmail(email);
      setStatus(res);
      setIsSubmitting(false);
      if (res.success) {
        setEmail('');
      }
    }, 350);
  };

  if (compact) {
    return (
      <div className="rounded-2xl bg-white border border-[#e2e8f0] p-6 shadow-xs">
        <div className="flex items-center gap-2 text-[#0062ff] font-bold text-xs uppercase tracking-wider mb-2">
          <Mail className="w-4 h-4" />
          Engineering Dispatch
        </div>
        <h3 className="text-base font-bold text-[#0b1528] mb-2">
          Get Tested Code & AI Fixes Weekly
        </h3>
        <p className="text-xs text-[#64748b] leading-relaxed mb-4">
          Join 8,400+ engineers. Zero fluff or vendor marketing. Just direct benchmarks and reproducible architecture guides.
        </p>

        <form onSubmit={handleSubmit} className="space-y-2.5">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder="colleague@domain.com"
            className="w-full rounded-xl border border-[#cbd5e1] bg-[#f8fafc] px-3.5 py-2.5 text-xs text-[#0b1528] placeholder-[#94a3b8] focus:outline-none focus:border-[#0062ff] focus:bg-white transition-all"
          />
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full rounded-xl bg-[#0062ff] px-4 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-[#004ecc] transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
          >
            {isSubmitting ? 'Registering...' : 'Subscribe Free'}
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        {status && (
          <div
            className={`mt-3 flex items-start gap-2 p-2.5 rounded-lg text-xs ${
              status.success
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : 'bg-red-50 text-red-800 border border-red-200'
            }`}
          >
            {status.success ? (
              <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-600 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-600 mt-0.5" />
            )}
            <span>{status.message}</span>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-3xl bg-[#0b1528] text-white p-8 sm:p-12 border border-[#1e2c45] shadow-xl">
      <div className="relative z-10 max-w-2xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff] bg-[#0062ff]/10 px-3 py-1 rounded-full border border-[#0062ff]/20">
          <Mail className="w-3.5 h-3.5" />
          Weekly Editorial Dispatch
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Level Up Your Technical Stack. No Slop, Guaranteed.
        </h2>
        <p className="text-sm text-slate-300 leading-relaxed max-w-xl mx-auto">
          Every Tuesday, we deliver peer-reviewed code teardowns, local AI fine-tuning recipes, and PostgreSQL performance solutions directly to your inbox.
        </p>

        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto pt-2">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder="Enter your work email address"
            className="flex-1 rounded-xl border border-slate-700 bg-slate-900/80 px-4 py-3 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-[#0062ff] focus:ring-1 focus:ring-[#0062ff]"
          />
          <button
            type="submit"
            disabled={isSubmitting}
            className="rounded-xl bg-[#0062ff] px-6 py-3 text-xs font-bold text-white shadow-md hover:bg-[#004ecc] transition-all disabled:opacity-50 whitespace-nowrap"
          >
            {isSubmitting ? 'Joining...' : 'Get Weekly Guides'}
          </button>
        </form>

        {status && (
          <div
            className={`max-w-md mx-auto mt-3 flex items-center justify-center gap-2 p-3 rounded-xl text-xs ${
              status.success
                ? 'bg-emerald-950/80 text-emerald-200 border border-emerald-700'
                : 'bg-red-950/80 text-red-200 border border-red-700'
            }`}
          >
            {status.success ? (
              <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400" />
            )}
            <span>{status.message}</span>
          </div>
        )}

        <p className="text-[11px] text-slate-500">
          Unsubscribe with 1-click at any time. We strictly adhere to CAN-SPAM and GDPR privacy standards.
        </p>
      </div>
    </div>
  );
}
