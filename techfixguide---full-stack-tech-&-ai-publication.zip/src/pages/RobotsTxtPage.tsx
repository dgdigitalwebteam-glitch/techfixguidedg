import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export function RobotsTxtPage() {
  const robotsContent = `User-agent: *
Allow: /

Disallow: /admin/
Disallow: /api/

Sitemap: https://techfixguide.com/sitemap.xml
`;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-[#0b1528]">Robots.txt Crawl Policy</h1>
        <Link to="/" className="text-xs text-[#0062ff] font-semibold flex items-center gap-1">
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Home
        </Link>
      </div>
      <p className="text-xs text-[#64748b]">
        Standard directives informing search crawlers (Googlebot, Bingbot) of public index boundaries while shielding private admin routes.
      </p>
      <pre className="p-4 rounded-xl bg-[#0b1528] text-emerald-400 font-mono text-xs overflow-x-auto border border-[#1e2c45]">
        {robotsContent}
      </pre>
    </div>
  );
}
