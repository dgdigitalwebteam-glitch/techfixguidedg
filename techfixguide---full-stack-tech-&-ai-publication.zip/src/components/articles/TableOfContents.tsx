import React, { useEffect, useState } from 'react';
import { List, ChevronRight } from 'lucide-react';

interface TOCItem {
  id: string;
  text: string;
  level: number;
}

interface TableOfContentsProps {
  content: string;
}

export function TableOfContents({ content }: TableOfContentsProps) {
  const [headings, setHeadings] = useState<TOCItem[]>([]);
  const [activeId, setActiveId] = useState<string>('');

  useEffect(() => {
    // Parse h2 and h3 elements from HTML content
    const parser = new DOMParser();
    const doc = parser.parseFromString(content, 'text/html');
    const elements = Array.from(doc.querySelectorAll('h2, h3'));

    const items: TOCItem[] = elements.map((el, index) => {
      const text = el.textContent || `Section ${index + 1}`;
      // Generate clean ID from heading text
      const id = text
        .toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/[\s_-]+/g, '-')
        .replace(/^-+|-+$/g, '') || `heading-${index}`;

      return {
        id,
        text,
        level: el.tagName === 'H2' ? 2 : 3,
      };
    });

    setHeadings(items);
  }, [content]);

  const scrollToHeading = (id: string, text: string) => {
    // Look for matching heading in the article body by text content or id
    const headings = document.querySelectorAll('.editorial-prose h2, .editorial-prose h3');
    for (let i = 0; i < headings.length; i++) {
      if (headings[i].textContent?.trim() === text.trim() || headings[i].id === id) {
        headings[i].scrollIntoView({ behavior: 'smooth', block: 'start' });
        setActiveId(id);
        break;
      }
    }
  };

  if (headings.length === 0) return null;

  return (
    <nav aria-label="Table of contents" className="rounded-2xl border border-[#e2e8f0] bg-white p-6 shadow-xs sticky top-28">
      <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-[#0b1528] mb-4">
        <List className="w-4 h-4 text-[#0062ff]" />
        Table of Contents
      </div>
      <ul className="space-y-2 text-xs">
        {headings.map((item, index) => (
          <li
            key={index}
            className={`${item.level === 3 ? 'ml-3 text-[#64748b]' : 'text-[#1e293b] font-medium'}`}
          >
            <button
              onClick={() => scrollToHeading(item.id, item.text)}
              className={`text-left hover:text-[#0062ff] transition-colors line-clamp-1 py-0.5 flex items-center gap-1.5 w-full ${
                activeId === item.id ? 'text-[#0062ff] font-bold' : ''
              }`}
            >
              <ChevronRight className="w-3 h-3 text-slate-300 flex-shrink-0" />
              <span>{item.text}</span>
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}
