import React, { useState } from 'react';
import { useAppStore, AppStore } from '../../lib/store';
import { formatDate } from '../../lib/utils';
import { CommentStatus } from '../../types';
import {
  MessageSquare,
  CheckCircle,
  XCircle,
  Trash2,
  AlertOctagon,
  ExternalLink,
} from 'lucide-react';
import { Link } from 'react-router-dom';

export function AdminCommentsPage() {
  const { comments, articles, siteSettings } = useAppStore();
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredComments = comments.filter((c) => {
    if (filterStatus === 'all') return true;
    return c.status === filterStatus;
  });

  const handleUpdateStatus = (id: string, newStatus: CommentStatus) => {
    AppStore.updateCommentStatus(id, newStatus);
  };

  const handleDelete = (id: string) => {
    if (confirm('Permanently delete this comment?')) {
      AppStore.deleteComment(id);
    }
  };

  const pendingCount = comments.filter((c) => c.status === 'pending').length;

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
            Comment Moderation Desk
          </h1>
          <p className="text-xs text-[#64748b]">
            Screen incoming reader observations, verify technical signal, and prevent spam.
          </p>
        </div>

        {/* Global Comments Toggle Notification */}
        <div className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-[#cbd5e1] bg-white text-[#0b1528] flex items-center gap-2">
          <span>Global Comments:</span>
          <span
            className={`font-bold ${
              siteSettings.comments_enabled_globally ? 'text-emerald-600' : 'text-amber-600'
            }`}
          >
            {siteSettings.comments_enabled_globally ? 'Enabled' : 'Disabled'}
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold">
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            filterStatus === 'all'
              ? 'bg-[#0b1528] text-white'
              : 'bg-white border border-[#cbd5e1] text-[#64748b] hover:text-[#0b1528]'
          }`}
        >
          All ({comments.length})
        </button>
        <button
          onClick={() => setFilterStatus('pending')}
          className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
            filterStatus === 'pending'
              ? 'bg-amber-500 text-[#0b1528] font-bold'
              : 'bg-white border border-[#cbd5e1] text-[#64748b] hover:text-[#0b1528]'
          }`}
        >
          <span>Pending Review</span>
          {pendingCount > 0 && (
            <span className="bg-amber-600 text-white text-[10px] px-1.5 rounded-full font-mono">
              {pendingCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setFilterStatus('approved')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            filterStatus === 'approved'
              ? 'bg-emerald-600 text-white'
              : 'bg-white border border-[#cbd5e1] text-[#64748b] hover:text-[#0b1528]'
          }`}
        >
          Approved ({comments.filter((c) => c.status === 'approved').length})
        </button>
        <button
          onClick={() => setFilterStatus('rejected')}
          className={`px-3 py-1.5 rounded-lg transition-colors ${
            filterStatus === 'rejected'
              ? 'bg-rose-600 text-white'
              : 'bg-white border border-[#cbd5e1] text-[#64748b] hover:text-[#0b1528]'
          }`}
        >
          Rejected ({comments.filter((c) => c.status === 'rejected').length})
        </button>
      </div>

      {/* Comments List */}
      <div className="space-y-4">
        {filteredComments.map((comment) => {
          const article = articles.find((a) => a.id === comment.article_id);

          return (
            <div
              key={comment.id}
              className={`bg-white rounded-2xl border p-5 space-y-3 shadow-xs transition-all ${
                comment.status === 'pending'
                  ? 'border-amber-300 ring-1 ring-amber-100'
                  : 'border-[#e2e8f0]'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[#0b1528]">{comment.author_name}</span>
                  <span className="text-[#64748b] font-mono text-[11px]">&lt;{comment.author_email}&gt;</span>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      comment.status === 'approved'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : comment.status === 'pending'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}
                  >
                    {comment.status}
                  </span>
                  <span className="text-[#94a3b8] text-[11px]">
                    {formatDate(comment.created_at)}
                  </span>
                </div>
              </div>

              {/* Reference Article */}
              {article && (
                <div className="text-[11px] text-[#0062ff] font-medium flex items-center gap-1">
                  <span>Target Guide:</span>
                  <Link
                    to={`/blog/${article.slug}`}
                    target="_blank"
                    className="hover:underline flex items-center gap-0.5 font-bold"
                  >
                    {article.title}
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
              )}

              {/* Comment Content */}
              <p className="text-xs text-[#334155] leading-relaxed bg-[#f8fafc] p-3 rounded-xl border border-[#e2e8f0]">
                {comment.content}
              </p>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-1 text-xs">
                {comment.status !== 'approved' && (
                  <button
                    onClick={() => handleUpdateStatus(comment.id, 'approved')}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold hover:bg-emerald-700 transition-colors"
                  >
                    <CheckCircle className="w-3.5 h-3.5" /> Approve & Publish
                  </button>
                )}

                {comment.status !== 'rejected' && (
                  <button
                    onClick={() => handleUpdateStatus(comment.id, 'rejected')}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#cbd5e1] text-[#475569] font-semibold hover:bg-slate-100 transition-colors"
                  >
                    <XCircle className="w-3.5 h-3.5" /> Reject
                  </button>
                )}

                <button
                  onClick={() => handleUpdateStatus(comment.id, 'spam')}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-amber-200 text-amber-700 font-semibold hover:bg-amber-50"
                  title="Mark as Spam"
                >
                  <AlertOctagon className="w-3.5 h-3.5" /> Spam
                </button>

                <button
                  onClick={() => handleDelete(comment.id)}
                  className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                  title="Delete comment permanently"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}

        {filteredComments.length === 0 && (
          <div className="p-12 text-center rounded-2xl bg-white border border-[#e2e8f0] text-xs text-[#64748b]">
            No comments match this filter state.
          </div>
        )}
      </div>
    </div>
  );
}
