import React from 'react';
import { FileText } from 'lucide-react';

export function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-8">
      <div className="space-y-2 border-b border-[#e2e8f0] pb-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
          <FileText className="w-4 h-4" />
          <span>Legal Agreement</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0b1528] tracking-tight">
          Terms & Conditions
        </h1>
        <p className="text-xs text-[#64748b]">Last Updated: March 2026</p>
      </div>

      <div className="editorial-prose text-sm">
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing or reading content on <strong>TechFixGuide</strong>, you agree to comply with and be bound by these Terms and Conditions. If you do not agree with any part of these terms, please discontinue use of the site.
        </p>

        <h2>2. Intellectual Property Rights</h2>
        <p>
          All proprietary articles, diagrams, custom logo assets, and editorial text published on TechFixGuide are the intellectual property of TechFixGuide and its respective authors. You may reference excerpts and code blocks with proper attribution and a canonical backlink to the original article URL.
        </p>

        <h2>3. Code Snippets & Permissive License</h2>
        <p>
          Unless explicitly stated otherwise, individual software code snippets published within tutorials are provided under the MIT License for educational and commercial integration into your own software projects.
        </p>

        <h2>4. Limitation of Liability</h2>
        <p>
          Technology guides and configurations are presented &quot;as is&quot; without warranties of any kind. TechFixGuide and its contributors shall not be held liable for system downtime, data loss, or misconfigurations incurred from applying guides in unverified production environments. Always test scripts in staging first.
        </p>
      </div>
    </div>
  );
}
