export type ArticleStatus = 'draft' | 'scheduled' | 'published' | 'archived';
export type UserRole = 'admin' | 'editor' | 'author';
export type CommentStatus = 'pending' | 'approved' | 'rejected' | 'spam';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  avatar_url: string;
  bio: string;
  role: UserRole;
  twitter_handle?: string;
  linkedin_url?: string;
  github_url?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image_url: string;
  seo_title: string;
  seo_description: string;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  subtitle: string;
  excerpt: string;
  content: string; // Rich HTML format
  featured_image: string;
  category_id: string;
  tags: string[];
  author_id: string;
  status: ArticleStatus;
  published_at: string | null;
  scheduled_for: string | null;
  reading_time: number;
  is_featured: boolean;
  is_trending: boolean;
  is_editors_pick: boolean;
  seo_title: string;
  seo_description: string;
  canonical_url: string;
  og_image: string;
  view_count: number;
  created_at: string;
  updated_at: string;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  size: number;
  mime_type: string;
  alt_text: string;
  created_at: string;
}

export interface Comment {
  id: string;
  article_id: string;
  author_name: string;
  author_email: string;
  content: string;
  status: CommentStatus;
  created_at: string;
}

export interface NewsletterSubscriber {
  id: string;
  email: string;
  is_active: boolean;
  confirmed_at: string;
  created_at: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface AdSettings {
  publisher_id: string;
  is_globally_enabled: boolean;
  header_ad_code: string;
  header_ad_enabled: boolean;
  sidebar_ad_code: string;
  sidebar_ad_enabled: boolean;
  in_article_ad_code: string;
  in_article_ad_enabled: boolean;
  footer_ad_code: string;
  footer_ad_enabled: boolean;
  ads_txt_content: string;
  verification_code: string;
}

export interface SiteSettings {
  site_name: string;
  site_tagline: string;
  site_description: string;
  site_url: string;
  support_email: string;
  comments_enabled_globally: boolean;
  posts_per_page: number;
}
