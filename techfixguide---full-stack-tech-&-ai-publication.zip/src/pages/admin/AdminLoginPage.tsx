import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AppStore, useAppStore } from '../../lib/store';
import { Logo } from '../../components/ui/Logo';
import { ShieldAlert, ArrowRight, ShieldCheck } from 'lucide-react';

export function AdminLoginPage() {
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { auth } = useAppStore();

  useEffect(() => {
    if (auth.isAuthenticated) {
      navigate('/admin', { replace: true });
    }
  }, [auth.isAuthenticated, navigate]);

  const activeError = errorMsg || auth.error;

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setErrorMsg(null);

    const res = await AppStore.loginWithGoogle();
    setIsLoading(false);

    if (res.success) {
      navigate('/admin', { replace: true });
    } else if (res.error) {
      setErrorMsg(res.error);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b1528] flex flex-col justify-center items-center px-4 py-12">
      <div className="w-full max-w-md bg-white rounded-3xl border border-[#cbd5e1] shadow-2xl p-8 sm:p-10 space-y-6">
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-3">
            <Logo />
          </div>
          <h1 className="text-xl font-black text-[#0b1528]">
            Editorial CMS Portal
          </h1>
          <p className="text-xs text-[#64748b]">
            Authenticate with your authorized administrator Google account
          </p>
        </div>

        <div className="rounded-xl bg-[#eff6ff] border border-[#bfdbfe] p-3.5 space-y-1 text-xs text-[#1e40af]">
          <div className="flex items-center gap-1.5 font-bold text-[#0062ff]">
            <ShieldCheck className="w-4 h-4" />
            <span>Verified Administrator Access</span>
          </div>
          <p className="text-[11px] text-[#1e3a8a] leading-relaxed">
            Protected by Firebase Authentication and Firestore security rules. Only verified administrator accounts can access the editorial CMS.
          </p>
        </div>

        {activeError && (
          <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs">
            <ShieldAlert className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{activeError}</span>
          </div>
        )}

        <button
          type="button"
          onClick={handleGoogleLogin}
          disabled={isLoading || auth.isLoading}
          className="w-full rounded-xl bg-[#0062ff] text-white py-3.5 px-4 text-xs font-bold hover:bg-[#004ecc] transition-all disabled:opacity-50 flex items-center justify-center gap-2.5 shadow-sm cursor-pointer"
        >
          <svg className="w-4 h-4 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96z"
            />
          </svg>
          <span>
            {isLoading || auth.isLoading
              ? 'Verifying Editorial Session...'
              : 'Sign in with Google'}
          </span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        <div className="pt-2 border-t border-[#f1f5f9] text-center">
          <Link to="/" className="text-xs text-[#64748b] hover:text-[#0062ff]">
            ← Return to Public Publication
          </Link>
        </div>
      </div>
    </div>
  );
}
