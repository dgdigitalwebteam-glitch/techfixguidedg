import React, { useState } from 'react';
import { Comment } from '../../types';
import { AppStore, useAppStore } from '../../lib/store';
import { formatDate } from '../../lib/utils';
import { MessageSquare, Send, CheckCircle2, ShieldAlert } from 'lucide-react';

interface CommentSectionProps {
  articleId: string;
}

export function CommentSection({ articleId }: CommentSectionProps) {
  const { comments, siteSettings } = useAppStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [content, setContent] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filter approved comments for this specific article
  const approvedComments = comments.filter(
    (c) => c.article_id === articleId && c.status === 'approved'
  );

  if (!siteSettings.comments_enabled_globally) {
    return (
      <div className="rounded-xl border border-[#e2e8f0] bg-[#f8fafc] p-6 text-center text-xs text-[#64748b]">
        Comments are currently disabled for this publication.
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || content.trim().length < 2) {
      setStatusMessage('Please enter your name, valid email, and at least 2 characters for your comment.');
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    setTimeout(() => {
      AppStore.addComment({
        article_id: articleId,
        author_name: name.trim(),
        author_email: email.trim(),
        content: content.trim(),
        status: 'pending', // Strict moderation requirement: goes to Admin CMS for approval!
      });

      setIsSubmitting(false);
      setName('');
      setEmail('');
      setContent('');
      setStatusMessage('Thank you. Your comment has been submitted for editorial moderation to prevent spam and ensure signal quality.');
    }, 400);
  };

  return (
    <div className="space-y-8">
      {/* Submission Form */}
      <form onSubmit={handleSubmit} className="rounded-2xl border border-[#e2e8f0] bg-white p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-[#0062ff]" />
          <h4 className="text-sm font-bold text-[#0b1528]">Join Technical Discussion</h4>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">Your Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Linus V."
              className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">Email (Never published)</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="linus@domain.com"
              className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-[#475569] mb-1">Technical Observation / Feedback</label>
          <textarea
            required
            rows={3}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Share your reproduction steps, benchmarks, or clarifications..."
            className="w-full rounded-xl border border-[#cbd5e1] p-3 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
          />
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
          <span className="text-[11px] text-[#64748b]">
            All contributions are pre-moderated to maintain high engineering signal.
          </span>
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#0b1528] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#1e2c45] transition-all disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            {isSubmitting ? 'Submitting...' : 'Post for Review'}
          </button>
        </div>

        {statusMessage && (
          <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
            <CheckCircle2 className="w-4 h-4 text-[#0062ff] flex-shrink-0 mt-0.5" />
            <span>{statusMessage}</span>
          </div>
        )}
      </form>

      {/* Approved Comments List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
            Peer Comments ({approvedComments.length})
          </h4>
          <span className="text-[11px] text-[#64748b]">Editorial Standards Verified</span>
        </div>

        {approvedComments.map((comment) => (
          <div key={comment.id} className="p-4 rounded-xl border border-[#e2e8f0] bg-white space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-[#0b1528]">{comment.author_name}</span>
              <span className="text-[#94a3b8]">{formatDate(comment.created_at)}</span>
            </div>
            <p className="text-xs text-[#334155] leading-relaxed whitespace-pre-line">
              {comment.content}
            </p>
          </div>
        ))}

        {approvedComments.length === 0 && (
          <div className="p-6 text-center rounded-xl bg-white border border-[#e2e8f0] text-xs text-[#64748b]">
            No verified comments on this guide yet. Be the first to share an observation.
          </div>
        )}
      </div>
    </div>
  );
}
