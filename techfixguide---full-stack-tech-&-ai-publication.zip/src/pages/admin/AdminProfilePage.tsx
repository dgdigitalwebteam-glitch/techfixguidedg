import React, { useState, useEffect } from 'react';
import { useAppStore, AppStore } from '../../lib/store';
import { User, Save, CheckCircle2, Shield } from 'lucide-react';

export function AdminProfilePage() {
  const { auth, authors } = useAppStore();

  const currentAuthor = authors.find((a) => a.id === auth.user?.id) || authors[0];

  const [fullName, setFullName] = useState(currentAuthor?.full_name || '');
  const [avatarUrl, setAvatarUrl] = useState(currentAuthor?.avatar_url || '');
  const [bio, setBio] = useState(currentAuthor?.bio || '');
  const [twitter, setTwitter] = useState(currentAuthor?.twitter_handle || '');
  const [github, setGithub] = useState(currentAuthor?.github_url || '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    if (currentAuthor) {
      setFullName(currentAuthor.full_name || '');
      setAvatarUrl(currentAuthor.avatar_url || '');
      setBio(currentAuthor.bio || '');
      setTwitter(currentAuthor.twitter_handle || '');
      setGithub(currentAuthor.github_url || '');
    }
  }, [currentAuthor?.id]);

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAuthor) return;

    const updatedAuthors = authors.map((a) => {
      if (a.id === currentAuthor.id) {
        return {
          ...a,
          full_name: fullName.trim(),
          avatar_url: avatarUrl.trim(),
          bio: bio.trim(),
          twitter_handle: twitter.trim(),
          github_url: github.trim(),
        };
      }
      return a;
    });

    AppStore.saveAuthors(updatedAuthors);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="border-b border-[#e2e8f0] pb-4">
        <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
          Staff Profile & Security
        </h1>
        <p className="text-xs text-[#64748b]">
          Update public editorial author attribution credentials and biography.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>Staff profile and author attribution updated in Firestore.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Profile Card */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#0b1528] flex items-center gap-2">
            <User className="w-4 h-4 text-[#0062ff]" />
            <span>Editorial Attribution Details</span>
          </h3>

          <form onSubmit={handleProfileSave} className="space-y-4">
            <div className="flex items-center gap-4 pb-2">
              <img
                src={avatarUrl}
                alt={fullName}
                className="w-16 h-16 rounded-2xl object-cover border border-[#cbd5e1]"
              />
              <div className="flex-1">
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Avatar Image URL
                </label>
                <input
                  type="url"
                  required
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Full Display Name
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Professional Bio (Shown on Article Cards)
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Twitter / X Handle
                </label>
                <input
                  type="text"
                  value={twitter}
                  onChange={(e) => setTwitter(e.target.value)}
                  placeholder="@handle"
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  GitHub Profile URL
                </label>
                <input
                  type="url"
                  value={github}
                  onChange={(e) => setGithub(e.target.value)}
                  placeholder="https://github.com/..."
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] shadow-xs"
            >
              <Save className="w-4 h-4" />
              Update Profile Information
            </button>
          </form>
        </div>

        {/* Firebase Auth Security Card */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#0b1528] flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#0062ff]" />
            <span>Authenticated Session</span>
          </h3>

          <div className="rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-4 space-y-2 text-xs">
            <div>
              <span className="text-[#64748b] block text-[11px]">Signed-in Account</span>
              <span className="font-bold text-[#0b1528]">
                {auth.user?.email || 'Verified Administrator'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[11px]">Authentication Provider</span>
              <span className="font-semibold text-[#0b1528]">Google Sign-In (Firebase Auth)</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[11px]">Access Role</span>
              <span className="font-semibold text-[#0062ff] capitalize">
                {auth.user?.role || 'admin'}
              </span>
            </div>
          </div>

          <div className="pt-2 text-[11px] text-[#64748b] leading-relaxed">
            Administrator credentials and email verification are managed directly through Firebase Authentication and Google Identity. Public author profiles exclude private email addresses.
          </div>
        </div>
      </div>
    </div>
  );
}
