import React from 'react';
import { Shield } from 'lucide-react';

export function PrivacyPolicyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-8">
      <div className="space-y-2 border-b border-[#e2e8f0] pb-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
          <Shield className="w-4 h-4" />
          <span>Transparency & Data Security</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0b1528] tracking-tight">
          Privacy Policy
        </h1>
        <p className="text-xs text-[#64748b]">Effective Date: March 2026</p>
      </div>

      <div className="editorial-prose text-sm">
        <h2>1. Overview and Commitment</h2>
        <p>
          At <strong>TechFixGuide</strong> (accessible at techfixguide.com), reader privacy is paramount. This Privacy Policy documents the types of information collected and how it is protected in accordance with global regulations including GDPR, CCPA, and standard internet protocols.
        </p>

        <h2>2. Information We Collect</h2>
        <p>
          We strictly limit data collection to what is necessary for site performance and communication:
        </p>
        <ul>
          <li><strong>Newsletter Subscription:</strong> When you subscribe to our dispatch, we store your email address solely to deliver requested articles and technical roundups. We never sell or rent mailing lists.</li>
          <li><strong>Comments and Contact Submissions:</strong> Names and email addresses submitted via comments or contact forms are stored securely for moderation and editorial reply.</li>
          <li><strong>Standard Log Files:</strong> Like standard web hosts, our servers log IP addresses, browser agents, referring URLs, and request timestamps to monitor infrastructure reliability and prevent malicious denial-of-service traffic.</li>
        </ul>

        <h2>3. Google AdSense & DART Cookies</h2>
        <p>
          Google is a third-party vendor on our website. Google uses cookies, known as DART cookies, to serve advertisements to site visitors based upon their visit to techfixguide.com and other websites across the internet.
        </p>
        <p>
          Readers may opt out of the use of DART cookies by visiting the Google Ad and Content Network Privacy Policy at: <a href="https://policies.google.com/technologies/ads" target="_blank" rel="noopener noreferrer">https://policies.google.com/technologies/ads</a>.
        </p>

        <h2>4. Your Data Protection Rights</h2>
        <p>
          Under European (GDPR) and California (CCPA) privacy laws, readers have the right to request access to, correction of, or permanent erasure of their personal data (such as newsletter subscriptions). To execute these rights, contact us at <code>privacy@techfixguide.com</code>.
        </p>
      </div>
    </div>
  );
}
