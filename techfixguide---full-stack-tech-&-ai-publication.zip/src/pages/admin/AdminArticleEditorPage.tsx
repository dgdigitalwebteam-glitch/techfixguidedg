import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAppStore, AppStore } from '../../lib/store';
import { generateSlug, calculateReadingTime } from '../../lib/utils';
import { Article, ArticleStatus } from '../../types';
import {
  ArrowLeft,
  Save,
  Eye,
  Edit3,
  Sparkles,
  Image as ImageIcon,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Code,
  Heading2,
  Heading3,
  Bold,
  Italic,
  List,
  ListOrdered,
  Quote,
  Table as TableIcon,
  Link as LinkIcon,
  X,
} from 'lucide-react';

export function AdminArticleEditorPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { categories, authors, media } = useAppStore();

  const isEditing = Boolean(id);
  const existingArticle = isEditing ? AppStore.getArticleById(id!) : null;

  // Form State
  const [title, setTitle] = useState(existingArticle?.title || '');
  const [slug, setSlug] = useState(existingArticle?.slug || '');
  const [subtitle, setSubtitle] = useState(existingArticle?.subtitle || '');
  const [excerpt, setExcerpt] = useState(existingArticle?.excerpt || '');
  const [content, setContent] = useState(
    existingArticle?.content ||
      `<h2>1. Architectural Overview</h2>
<p>Begin documenting the system components and runtime considerations...</p>

<blockquote>
  "Key architectural takeaway or quote here."
</blockquote>

<h2>2. Reproducible Implementation</h2>
<pre><code>// Production code snippet
console.log("Ready for deployment");</code></pre>`
  );
  const [featuredImage, setFeaturedImage] = useState(
    existingArticle?.featured_image ||
      'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'
  );
  const [categoryId, setCategoryId] = useState(
    existingArticle?.category_id || categories[0]?.id || 'cat-web-dev'
  );
  const [authorId, setAuthorId] = useState(
    existingArticle?.author_id || authors[0]?.id || 'author-1'
  );
  const [status, setStatus] = useState<ArticleStatus>(existingArticle?.status || 'draft');
  const [scheduledFor, setScheduledFor] = useState(existingArticle?.scheduled_for || '');
  const [tagsInput, setTagsInput] = useState(existingArticle?.tags?.join(', ') || 'Tech, Architecture');
  const [isFeatured, setIsFeatured] = useState(existingArticle?.is_featured || false);
  const [isTrending, setIsTrending] = useState(existingArticle?.is_trending || false);
  const [isEditorsPick, setIsEditorsPick] = useState(existingArticle?.is_editors_pick || false);

  // SEO Fields
  const [seoTitle, setSeoTitle] = useState(existingArticle?.seo_title || '');
  const [seoDescription, setSeoDescription] = useState(existingArticle?.seo_description || '');
  const [canonicalUrl, setCanonicalUrl] = useState(existingArticle?.canonical_url || '');

  // UI State
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-generate suggested slug if creating new
  const handleGenerateSlug = () => {
    if (title) {
      setSlug(generateSlug(title));
      setIsDirty(true);
    }
  };

  // Helper to insert rich text formatting tag at cursor
  const insertFormatting = (prefix: string, suffix: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    const replacement = `${prefix}${selectedText || 'Text here'}${suffix}`;

    const newContent = content.substring(0, start) + replacement + content.substring(end);
    setContent(newContent);
    setIsDirty(true);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + prefix.length, start + replacement.length - suffix.length);
    }, 50);
  };

  // Save Article
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      alert('Article title is required.');
      return;
    }

    const tagsArray = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const effectiveSlug = slug.trim() ? generateSlug(slug) : generateSlug(title);

    const saved = AppStore.saveArticle({
      id: existingArticle?.id,
      title: title.trim(),
      slug: effectiveSlug,
      subtitle: subtitle.trim(),
      excerpt: excerpt.trim() || title.trim(),
      content: content.trim(),
      featured_image: featuredImage.trim(),
      category_id: categoryId,
      author_id: authorId,
      status,
      scheduled_for: status === 'scheduled' ? scheduledFor : null,
      tags: tagsArray,
      is_featured: isFeatured,
      is_trending: isTrending,
      is_editors_pick: isEditorsPick,
      seo_title: seoTitle.trim() || title.trim(),
      seo_description: seoDescription.trim() || excerpt.trim(),
      canonical_url: canonicalUrl.trim() || `https://techfixguide.com/blog/${effectiveSlug}`,
    });

    setIsDirty(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);

    if (!isEditing) {
      navigate(`/admin/articles/edit/${saved.id}`);
    }
  };

  // Unsaved edits navigation warning
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty]);

  const readingTime = calculateReadingTime(content);

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
        <div className="flex items-center gap-3">
          <Link
            to="/admin/articles"
            className="p-2 rounded-xl bg-white border border-[#cbd5e1] hover:bg-[#f8fafc] text-[#0b1528] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-[#0b1528]">
              {isEditing ? `Edit: ${existingArticle?.title}` : 'Draft New Masterguide'}
            </h1>
            <div className="text-[11px] text-[#64748b]">
              Estimated Reading Time: <strong>{readingTime} min</strong> · Rich HTML format
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {saveSuccess && (
            <span className="flex items-center gap-1.5 text-xs text-emerald-700 font-bold bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
              <CheckCircle2 className="w-4 h-4" />
              Saved to Database
            </span>
          )}

          <div className="flex items-center p-1 bg-white border border-[#cbd5e1] rounded-xl text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('editor')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'editor' ? 'bg-[#0b1528] text-white' : 'text-[#64748b] hover:text-[#0b1528]'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              Editor
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${
                activeTab === 'preview' ? 'bg-[#0062ff] text-white' : 'text-[#64748b] hover:text-[#0b1528]'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Live Preview
            </button>
          </div>

          <button
            onClick={handleSave}
            type="button"
            className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] shadow-xs"
          >
            <Save className="w-4 h-4" />
            Save Guide
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Editing Column */}
          <div className="lg:col-span-8 space-y-6">
            {/* Title & Slug */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#1e293b] mb-1">
                  Article Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder="e.g. Fine-Tuning Local LLMs: From Raw Dataset to vLLM Inference"
                  className="w-full rounded-xl border border-[#cbd5e1] p-3 text-sm font-semibold text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-[#1e293b]">
                    URL Slug
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateSlug}
                    className="text-[11px] font-bold text-[#0062ff] hover:underline flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" /> Auto-Suggest Slug
                  </button>
                </div>
                <div className="flex items-center">
                  <span className="px-3 py-2.5 bg-[#f8fafc] border border-r-0 border-[#cbd5e1] rounded-l-xl text-xs text-[#64748b]">
                    /blog/
                  </span>
                  <input
                    type="text"
                    value={slug}
                    onChange={(e) => {
                      setSlug(e.target.value);
                      setIsDirty(true);
                    }}
                    placeholder="fine-tuning-local-llms-vllm-inference"
                    className="w-full rounded-r-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] font-mono focus:outline-none focus:border-[#0062ff]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1e293b] mb-1">
                  Subtitle (Optional)
                </label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => {
                    setSubtitle(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder="A comprehensive production blueprint with reproducible benchmarks"
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1e293b] mb-1">
                  Article Excerpt / Abstract <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={excerpt}
                  onChange={(e) => {
                    setExcerpt(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder="2-3 sentence overview highlighting the engineering outcome..."
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>
            </div>

            {/* Rich Text Editor or Preview */}
            <div className="bg-white rounded-2xl border border-[#e2e8f0] shadow-xs overflow-hidden">
              {/* Rich-Text Formatting Toolbar */}
              {activeTab === 'editor' && (
                <div className="p-3 bg-[#f8fafc] border-b border-[#e2e8f0] flex flex-wrap items-center gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => insertFormatting('<h2>', '</h2>')}
                    className="px-2.5 py-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100 font-bold flex items-center gap-1"
                    title="Insert Heading 2"
                  >
                    <Heading2 className="w-3.5 h-3.5" /> H2
                  </button>
                  <button
                    type="button"
                    onClick={() => insertFormatting('<h3>', '</h3>')}
                    className="px-2.5 py-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100 font-bold flex items-center gap-1"
                    title="Insert Heading 3"
                  >
                    <Heading3 className="w-3.5 h-3.5" /> H3
                  </button>
                  <button
                    type="button"
                    onClick={() => insertFormatting('<strong>', '</strong>')}
                    className="p-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100"
                    title="Bold text"
                  >
                    <Bold className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => insertFormatting('<em>', '</em>')}
                    className="p-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100"
                    title="Italic text"
                  >
                    <Italic className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => insertFormatting('<pre><code>', '</code></pre>')}
                    className="px-2.5 py-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100 font-mono text-[11px] flex items-center gap-1"
                    title="Insert Code Block"
                  >
                    <Code className="w-3.5 h-3.5" /> Code Block
                  </button>
                  <button
                    type="button"
                    onClick={() => insertFormatting('<blockquote>\n  "', '"\n</blockquote>')}
                    className="p-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100"
                    title="Insert Blockquote"
                  >
                    <Quote className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => insertFormatting('<ul>\n  <li>', '</li>\n  <li>Item 2</li>\n</ul>')}
                    className="p-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100"
                    title="Bullet List"
                  >
                    <List className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      insertFormatting(
                        '<table>\n  <thead>\n    <tr><th>Component</th><th>Latency</th></tr>\n  </thead>\n  <tbody>\n    <tr><td>vLLM</td><td>85ms</td></tr>\n  </tbody>\n</table>'
                      )
                    }
                    className="px-2 py-1 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100 flex items-center gap-1"
                    title="Insert Table"
                  >
                    <TableIcon className="w-3.5 h-3.5" /> Table
                  </button>
                  <button
                    type="button"
                    onClick={() => insertFormatting('<a href="https://example.com">', '</a>')}
                    className="p-1.5 bg-white border border-[#cbd5e1] rounded-lg text-[#0b1528] hover:bg-slate-100"
                    title="Insert Link"
                  >
                    <LinkIcon className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Editor Mode */}
              {activeTab === 'editor' ? (
                <div className="p-4">
                  <textarea
                    ref={textareaRef}
                    required
                    rows={20}
                    value={content}
                    onChange={(e) => {
                      setContent(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full font-mono text-xs text-[#0b1528] leading-relaxed p-2 focus:outline-none resize-y"
                    placeholder="Compose structured HTML article..."
                  />
                </div>
              ) : (
                /* Live Preview Mode */
                <div className="p-8 max-h-[600px] overflow-y-auto">
                  <div className="border-b border-[#e2e8f0] pb-4 mb-6">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#0062ff]">
                      Live Visual Renderer
                    </span>
                    <h2 className="text-2xl font-black text-[#0b1528] mt-1">{title || 'Untitled Article'}</h2>
                    {subtitle && <p className="text-sm text-[#475569] mt-1">{subtitle}</p>}
                  </div>
                  <div
                    className="editorial-prose"
                    dangerouslySetInnerHTML={{ __html: content }}
                  />
                </div>
              )}
            </div>

            {/* SEO Configuration Section */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-[#0b1528] flex items-center gap-2">
                <span>Search Engine Optimization (SEO) & OpenGraph</span>
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Meta Title Tag (Recommended &lt; 60 chars)
                  </label>
                  <input
                    type="text"
                    value={seoTitle}
                    onChange={(e) => {
                      setSeoTitle(e.target.value);
                      setIsDirty(true);
                    }}
                    placeholder={title || 'Custom SEO Title...'}
                    className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Meta Description Tag (Recommended 140-160 chars)
                  </label>
                  <textarea
                    rows={2}
                    value={seoDescription}
                    onChange={(e) => {
                      setSeoDescription(e.target.value);
                      setIsDirty(true);
                    }}
                    placeholder={excerpt || 'Concise search engine summary...'}
                    className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Canonical URL Override
                  </label>
                  <input
                    type="text"
                    value={canonicalUrl}
                    onChange={(e) => {
                      setCanonicalUrl(e.target.value);
                      setIsDirty(true);
                    }}
                    placeholder={`https://techfixguide.com/blog/${slug || 'article-slug'}`}
                    className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] font-mono focus:outline-none focus:border-[#0062ff]"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Sidebar Controls */}
          <div className="lg:col-span-4 space-y-6">
            {/* Publishing Status Card */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
                Publishing Controls
              </h3>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Article Status
                </label>
                <select
                  value={status}
                  onChange={(e) => {
                    setStatus(e.target.value as ArticleStatus);
                    setIsDirty(true);
                  }}
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] bg-[#f8fafc] font-semibold"
                >
                  <option value="draft">Draft (Private in CMS)</option>
                  <option value="published">Published (Live & Indexed)</option>
                  <option value="scheduled">Scheduled (Future Date)</option>
                  <option value="archived">Archived</option>
                </select>
              </div>

              {status === 'scheduled' && (
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Scheduled Publication Time
                  </label>
                  <input
                    type="datetime-local"
                    value={scheduledFor}
                    onChange={(e) => {
                      setScheduledFor(e.target.value);
                      setIsDirty(true);
                    }}
                    className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] bg-[#f8fafc]"
                  />
                </div>
              )}

              {/* Toggles */}
              <div className="space-y-2 pt-2 border-t border-[#f1f5f9]">
                <label className="flex items-center gap-2.5 text-xs font-semibold text-[#1e293b] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => {
                      setIsFeatured(e.target.checked);
                      setIsDirty(true);
                    }}
                    className="w-4 h-4 rounded text-[#0062ff]"
                  />
                  Featured Masterguide (Homepage Hero)
                </label>

                <label className="flex items-center gap-2.5 text-xs font-semibold text-[#1e293b] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isTrending}
                    onChange={(e) => {
                      setIsTrending(e.target.checked);
                      setIsDirty(true);
                    }}
                    className="w-4 h-4 rounded text-[#0062ff]"
                  />
                  Trending Article Stream
                </label>

                <label className="flex items-center gap-2.5 text-xs font-semibold text-[#1e293b] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isEditorsPick}
                    onChange={(e) => {
                      setIsEditorsPick(e.target.checked);
                      setIsDirty(true);
                    }}
                    className="w-4 h-4 rounded text-[#0062ff]"
                  />
                  Editor&apos;s Pick Badge
                </label>
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-[#0062ff] py-3 text-xs font-bold text-white hover:bg-[#004ecc] transition-all flex items-center justify-center gap-2 shadow-xs"
              >
                <Save className="w-4 h-4" />
                Commit Changes
              </button>
            </div>

            {/* Categorization & Metadata */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
                Categorization & Author
              </h3>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Primary Specialization
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => {
                    setCategoryId(e.target.value);
                    setIsDirty(true);
                  }}
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] bg-[#f8fafc]"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Assigned Author Profile
                </label>
                <select
                  value={authorId}
                  onChange={(e) => {
                    setAuthorId(e.target.value);
                    setIsDirty(true);
                  }}
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] bg-[#f8fafc]"
                >
                  {authors.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.full_name} ({a.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Tags (Comma separated)
                </label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => {
                    setTagsInput(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder="AI, vLLM, PyTorch, Docker"
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>
            </div>

            {/* Featured Image Management */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
                  Featured Media Asset
                </h3>
                <button
                  type="button"
                  onClick={() => setShowMediaPicker(true)}
                  className="text-[11px] font-bold text-[#0062ff] hover:underline flex items-center gap-1"
                >
                  <ImageIcon className="w-3.5 h-3.5" /> Media Library
                </button>
              </div>

              <div>
                <input
                  type="url"
                  required
                  value={featuredImage}
                  onChange={(e) => {
                    setFeaturedImage(e.target.value);
                    setIsDirty(true);
                  }}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              {featuredImage && (
                <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden bg-slate-100 border border-[#cbd5e1]">
                  <img
                    src={featuredImage}
                    alt="Featured preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </form>

      {/* Media Library Picker Modal */}
      {showMediaPicker && (
        <div className="fixed inset-0 z-50 bg-[#0b1528]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#cbd5e1] max-w-2xl w-full p-6 space-y-4 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="text-base font-bold text-[#0b1528]">Select from Media Library</h3>
              <button
                type="button"
                onClick={() => setShowMediaPicker(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 overflow-y-auto p-1 flex-1">
              {media.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    setFeaturedImage(item.url);
                    setIsDirty(true);
                    setShowMediaPicker(false);
                  }}
                  className="group relative aspect-[16/9] rounded-xl overflow-hidden border border-[#cbd5e1] cursor-pointer hover:border-[#0062ff] transition-all bg-slate-100"
                >
                  <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-[11px] font-bold p-2 text-center">
                    Select Image
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-[#e2e8f0]">
              <Link
                to="/admin/media"
                target="_blank"
                className="text-xs text-[#0062ff] font-bold hover:underline"
              >
                Upload New Image to Storage →
              </Link>
              <button
                type="button"
                onClick={() => setShowMediaPicker(false)}
                className="px-4 py-2 rounded-xl bg-slate-100 text-[#0b1528] text-xs font-semibold hover:bg-slate-200"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
