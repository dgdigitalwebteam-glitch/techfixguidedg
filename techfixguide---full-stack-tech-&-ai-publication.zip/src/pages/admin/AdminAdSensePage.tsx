import React, { useState, useEffect } from 'react';
import { useAppStore, AppStore } from '../../lib/store';
import { AdSettings } from '../../types';
import {
  DollarSign,
  Save,
  CheckCircle2,
  AlertTriangle,
  Eye,
  ShieldCheck,
  FileCode,
  Sliders,
} from 'lucide-react';

export function AdminAdSensePage() {
  const { adSettings } = useAppStore();

  const [settings, setSettings] = useState<AdSettings>({ ...adSettings });
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [activePreview, setActivePreview] = useState<'header' | 'sidebar' | 'in-article' | 'footer'>('header');

  useEffect(() => {
    setSettings({ ...adSettings });
  }, [adSettings]);

  const handleToggle = (key: keyof AdSettings) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    AppStore.saveAdSettings(settings);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
            Google AdSense & Ad Inventory Management
          </h1>
          <p className="text-xs text-[#64748b]">
            Monetization controls, placement toggles, responsive containers, and ads.txt directives.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] shadow-xs"
        >
          <Save className="w-4 h-4" />
          Save Ad Policies
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>AdSense configuration and ads.txt directive updated successfully across all views.</span>
        </div>
      )}

      {/* Global Master Switch */}
      <div className="rounded-2xl border border-[#cbd5e1] bg-white p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
            <DollarSign className="w-4 h-4" />
            <span>Master Commercial Controller</span>
          </div>
          <h3 className="text-base font-bold text-[#0b1528] mt-1">
            Global Advertising Engine
          </h3>
          <p className="text-xs text-[#64748b] max-w-xl mt-0.5">
            When turned OFF, all ad containers across the homepage, sidebar, and articles collapse completely with zero layout shift.
          </p>
        </div>

        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={settings.is_globally_enabled}
            onChange={() => handleToggle('is_globally_enabled')}
            className="sr-only peer"
          />
          <div className="w-14 h-7 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#0062ff]"></div>
        </label>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Settings Left Column */}
          <div className="lg:col-span-7 space-y-6">
            {/* Publisher Verification */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
                Publisher Identity & Verification
              </h3>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Google AdSense Publisher ID
                </label>
                <input
                  type="text"
                  required
                  value={settings.publisher_id}
                  onChange={(e) => setSettings({ ...settings, publisher_id: e.target.value })}
                  placeholder="pub-XXXXXXXXXXXXXXXX"
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] font-mono focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  HTML Head Verification Code Snippet
                </label>
                <input
                  type="text"
                  value={settings.verification_code}
                  onChange={(e) => setSettings({ ...settings, verification_code: e.target.value })}
                  placeholder='<meta name="google-adsense-account" content="ca-pub-...">"'
                  className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] font-mono focus:outline-none focus:border-[#0062ff]"
                />
              </div>
            </div>

            {/* Individual Placement Toggles */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
                Placement Slots & Code Injection
              </h3>

              {/* Header Ad Slot */}
              <div className="border border-[#e2e8f0] rounded-xl p-4 space-y-2.5 bg-[#f8fafc]">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0b1528]">
                    Header Banner Placement (Leaderboard 728x90)
                  </span>
                  <label className="flex items-center gap-2 text-xs font-semibold text-[#0b1528] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.header_ad_enabled}
                      onChange={() => handleToggle('header_ad_enabled')}
                      className="rounded text-[#0062ff]"
                    />
                    Enabled
                  </label>
                </div>
                <textarea
                  rows={2}
                  value={settings.header_ad_code}
                  onChange={(e) => setSettings({ ...settings, header_ad_code: e.target.value })}
                  placeholder="<ins class='adsbygoogle' ...></ins>"
                  className="w-full rounded-lg border border-[#cbd5e1] p-2 font-mono text-[11px] text-[#0b1528] bg-white focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              {/* Sidebar Ad Slot */}
              <div className="border border-[#e2e8f0] rounded-xl p-4 space-y-2.5 bg-[#f8fafc]">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0b1528]">
                    Sidebar Box Placement (Rectangle 300x250)
                  </span>
                  <label className="flex items-center gap-2 text-xs font-semibold text-[#0b1528] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.sidebar_ad_enabled}
                      onChange={() => handleToggle('sidebar_ad_enabled')}
                      className="rounded text-[#0062ff]"
                    />
                    Enabled
                  </label>
                </div>
                <textarea
                  rows={2}
                  value={settings.sidebar_ad_code}
                  onChange={(e) => setSettings({ ...settings, sidebar_ad_code: e.target.value })}
                  placeholder="<ins class='adsbygoogle' ...></ins>"
                  className="w-full rounded-lg border border-[#cbd5e1] p-2 font-mono text-[11px] text-[#0b1528] bg-white focus:outline-none focus:border-[#0062ff]"
                />
              </div>

              {/* In-Article Ad Slot */}
              <div className="border border-[#e2e8f0] rounded-xl p-4 space-y-2.5 bg-[#f8fafc]">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0b1528]">
                    In-Article Native Responsive Placement
                  </span>
                  <label className="flex items-center gap-2 text-xs font-semibold text-[#0b1528] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.in_article_ad_enabled}
                      onChange={() => handleToggle('in_article_ad_enabled')}
                      className="rounded text-[#0062ff]"
                    />
                    Enabled
                  </label>
                </div>
                <textarea
                  rows={2}
                  value={settings.in_article_ad_code}
                  onChange={(e) => setSettings({ ...settings, in_article_ad_code: e.target.value })}
                  placeholder="<ins class='adsbygoogle' ...></ins>"
                  className="w-full rounded-lg border border-[#cbd5e1] p-2 font-mono text-[11px] text-[#0b1528] bg-white focus:outline-none focus:border-[#0062ff]"
                />
              </div>
            </div>

            {/* ads.txt Configuration */}
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528] flex items-center gap-1.5">
                  <FileCode className="w-4 h-4 text-[#0062ff]" />
                  <span>ads.txt Configuration</span>
                </h3>
                <a
                  href="/ads.txt"
                  target="_blank"
                  className="text-[11px] text-[#0062ff] font-bold hover:underline"
                >
                  View Live /ads.txt ↗
                </a>
              </div>
              <p className="text-xs text-[#64748b]">
                Authorized seller directives published at the domain root for automated crawl validation.
              </p>
              <textarea
                rows={3}
                value={settings.ads_txt_content}
                onChange={(e) => setSettings({ ...settings, ads_txt_content: e.target.value })}
                className="w-full font-mono text-xs rounded-xl border border-[#cbd5e1] p-3 text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>
          </div>

          {/* Right Column: Live Responsive Preview Simulator */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528] flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-[#0062ff]" />
                  <span>Ad Preview Simulator</span>
                </h3>
                <span className="text-[11px] font-semibold text-slate-400">Layout Safe</span>
              </div>

              {/* Selector */}
              <div className="flex items-center gap-1 p-1 bg-[#f1f5f9] rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setActivePreview('header')}
                  className={`flex-1 py-1.5 rounded-lg transition-colors ${
                    activePreview === 'header' ? 'bg-white text-[#0b1528] shadow-xs' : 'text-[#64748b]'
                  }`}
                >
                  Header
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreview('sidebar')}
                  className={`flex-1 py-1.5 rounded-lg transition-colors ${
                    activePreview === 'sidebar' ? 'bg-white text-[#0b1528] shadow-xs' : 'text-[#64748b]'
                  }`}
                >
                  Sidebar
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreview('in-article')}
                  className={`flex-1 py-1.5 rounded-lg transition-colors ${
                    activePreview === 'in-article' ? 'bg-white text-[#0b1528] shadow-xs' : 'text-[#64748b]'
                  }`}
                >
                  In-Article
                </button>
              </div>

              {/* Simulation Sandbox */}
              <div className="border border-dashed border-[#cbd5e1] rounded-xl p-4 bg-[#f8fafc] text-center min-h-[220px] flex flex-col justify-center items-center">
                <div className="text-[10px] uppercase font-bold text-[#94a3b8] mb-2">
                  Advertisement · Simulation
                </div>

                {settings.is_globally_enabled ? (
                  <div
                    className="w-full overflow-hidden flex items-center justify-center"
                    dangerouslySetInnerHTML={{
                      __html:
                        activePreview === 'header'
                          ? settings.header_ad_code
                          : activePreview === 'sidebar'
                          ? settings.sidebar_ad_code
                          : settings.in_article_ad_code,
                    }}
                  />
                ) : (
                  <div className="text-xs text-[#64748b] italic">
                    Advertising is globally disabled. This container will not render on the public website.
                  </div>
                )}
              </div>

              <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#0062ff]" />
                  <span>Google Publisher Compliance Guaranteed</span>
                </div>
                <p className="text-[11px] text-blue-800 leading-relaxed">
                  TechFixGuide complies strictly with Google AdSense terms: zero deceptive layouts, zero simulated clicks, and zero layout shift.
                </p>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
