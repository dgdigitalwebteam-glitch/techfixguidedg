import React, { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { AppStore, useAppStore } from '../lib/store';
import { formatDate, calculateReadingTime, getWordCount } from '../lib/utils';
import { AdSlot } from '../components/ads/AdSlot';
import { TableOfContents } from '../components/articles/TableOfContents';
import { ShareButtons } from '../components/articles/ShareButtons';
import { CommentSection } from '../components/forms/CommentSection';
import {
  Clock,
  Calendar,
  ArrowLeft,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  Twitter,
  Github,
  Linkedin,
} from 'lucide-react';

export function ArticleDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { articles, categories, authors } = useAppStore();

  const article = articles.find((a) => a.slug === slug);

  // Increment view count once per visit
  useEffect(() => {
    if (slug) {
      AppStore.incrementViewCount(slug);
    }
  }, [slug]);

  // Update dynamic document title & metadata
  useEffect(() => {
    if (article) {
      document.title = `${article.seo_title || article.title} | TechFixGuide`;
    }
  }, [article]);

  if (!article) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <h1 className="text-3xl font-extrabold text-[#0b1528]">Article Not Found</h1>
        <p className="text-sm text-[#64748b]">
          The guide you are looking for may have been relocated or unpublished.
        </p>
        <Link
          to="/blog"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0062ff] text-white text-xs font-bold hover:bg-[#004ecc]"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to All Guides
        </Link>
      </div>
    );
  }

  const category = categories.find((c) => c.id === article.category_id);
  const author = authors.find((a) => a.id === article.author_id);
  const wordCount = getWordCount(article.content);
  const estimatedReadingTime = calculateReadingTime(article.content);

  // Related articles in same category
  const related = articles
    .filter((a) => a.category_id === article.category_id && a.id !== article.id && a.status === 'published')
    .slice(0, 3);

  // Previous & Next navigation
  const publishedArticles = articles.filter((a) => a.status === 'published');
  const currentIndex = publishedArticles.findIndex((a) => a.id === article.id);
  const prevArticle = currentIndex > 0 ? publishedArticles[currentIndex - 1] : null;
  const nextArticle =
    currentIndex >= 0 && currentIndex < publishedArticles.length - 1
      ? publishedArticles[currentIndex + 1]
      : null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : `https://techfixguide.com/blog/${article.slug}`;

  return (
    <article className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Breadcrumbs */}
      <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-2 text-xs text-[#64748b]">
        <Link to="/" className="hover:text-[#0062ff] transition-colors">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        <Link to="/blog" className="hover:text-[#0062ff] transition-colors">Guides</Link>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        {category && (
          <>
            <Link to={`/category/${category.slug}`} className="hover:text-[#0062ff] transition-colors">
              {category.name}
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </>
        )}
        <span className="text-[#0b1528] font-medium truncate max-w-xs">{article.title}</span>
      </nav>

      {/* Article Header */}
      <header className="max-w-4xl space-y-4 mb-8">
        {/* Category & Status Text */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0062ff]">
          <span>{category?.name || 'Technical Tutorial'}</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span className="text-[#10b981] flex items-center gap-1 font-semibold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Verified Runtime
          </span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span
            className="text-[#475569] normal-case tracking-normal font-medium flex items-center gap-1"
            title={`Calculated from ${wordCount.toLocaleString()} words`}
          >
            <Clock className="w-3.5 h-3.5 text-[#0062ff]" />
            Estimated reading time: {estimatedReadingTime} min ({wordCount.toLocaleString()} words)
          </span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#0b1528] tracking-tight leading-tight">
          {article.title}
        </h1>

        {article.subtitle && (
          <p className="text-lg sm:text-xl text-[#475569] leading-relaxed font-normal">
            {article.subtitle}
          </p>
        )}

        {/* Metadata Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-[#e2e8f0] text-xs text-[#64748b]">
          <div className="flex items-center gap-3">
            <img
              src={author?.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80'}
              alt={author?.full_name || 'Author'}
              className="w-10 h-10 rounded-full object-cover border border-[#cbd5e1]"
            />
            <div>
              <div className="font-bold text-[#0b1528]">{author?.full_name || 'TechFix Editorial Team'}</div>
              <div className="text-[11px] text-[#64748b]">{author?.bio?.split('.')[0] || 'Technical Staff'}</div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              Published {formatDate(article.published_at)}
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-[#0062ff]" />
              {estimatedReadingTime} min read
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <ShareButtons title={article.title} url={currentUrl} />
          </div>
        </div>
      </header>

      {/* Featured Hero Image */}
      <div className="relative aspect-[21/9] w-full overflow-hidden rounded-2xl bg-[#f1f5f9] mb-10 shadow-sm border border-[#e2e8f0]">
        <img
          src={article.featured_image}
          alt={article.title}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Main Grid: Body Content vs Sticky Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Core Article Body */}
        <div className="lg:col-span-8">
          {/* In-Article Advertisement */}
          <AdSlot type="in-article" />

          {/* Rich Content */}
          <div
            className="editorial-prose"
            dangerouslySetInnerHTML={{ __html: article.content }}
          />

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="mt-10 pt-6 border-t border-[#e2e8f0] flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-[#64748b] mr-2">Discipline Tags:</span>
              {article.tags.map((tag) => (
                <Link
                  key={tag}
                  to={`/search?q=${encodeURIComponent(tag)}`}
                  className="px-3 py-1 text-xs font-medium bg-[#f1f5f9] text-[#1e293b] hover:bg-[#0062ff] hover:text-white rounded-lg transition-colors"
                >
                  #{tag}
                </Link>
              ))}
            </div>
          )}

          {/* Author Card Box */}
          {author && (
            <div className="mt-12 rounded-2xl border border-[#e2e8f0] bg-white p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center gap-5">
              <img
                src={author.avatar_url}
                alt={author.full_name}
                className="w-16 h-16 rounded-2xl object-cover border border-[#cbd5e1] flex-shrink-0"
              />
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-base font-bold text-[#0b1528]">{author.full_name}</h4>
                  <span className="text-[10px] uppercase font-bold text-[#0062ff] bg-blue-50 px-2 py-0.5 rounded">
                    Staff Author
                  </span>
                </div>
                <p className="text-xs text-[#64748b] leading-relaxed">
                  {author.bio}
                </p>
                <div className="flex items-center gap-3 pt-1 text-xs text-[#64748b]">
                  {author.twitter_handle && (
                    <span className="text-[#0062ff] font-medium">{author.twitter_handle}</span>
                  )}
                  {author.github_url && (
                    <a href={author.github_url} target="_blank" rel="noopener noreferrer" className="hover:text-[#0b1528]">
                      GitHub
                    </a>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Previous / Next Article Navigation */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 gap-4 pt-8 border-t border-[#e2e8f0]">
            {prevArticle ? (
              <Link
                to={`/blog/${prevArticle.slug}`}
                className="p-4 rounded-xl border border-[#e2e8f0] bg-white hover:border-[#0062ff] group transition-all"
              >
                <div className="text-[11px] font-semibold text-[#64748b] flex items-center gap-1 mb-1">
                  <ArrowLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" />
                  Previous Guide
                </div>
                <div className="text-xs font-bold text-[#0b1528] group-hover:text-[#0062ff] transition-colors line-clamp-1">
                  {prevArticle.title}
                </div>
              </Link>
            ) : <div />}

            {nextArticle ? (
              <Link
                to={`/blog/${nextArticle.slug}`}
                className="p-4 rounded-xl border border-[#e2e8f0] bg-white hover:border-[#0062ff] group transition-all text-right"
              >
                <div className="text-[11px] font-semibold text-[#64748b] flex items-center justify-end gap-1 mb-1">
                  Next Guide
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </div>
                <div className="text-xs font-bold text-[#0b1528] group-hover:text-[#0062ff] transition-colors line-clamp-1">
                  {nextArticle.title}
                </div>
              </Link>
            ) : <div />}
          </div>

          {/* Moderated Comments */}
          <section className="mt-16 pt-10 border-t border-[#e2e8f0]">
            <CommentSection articleId={article.id} />
          </section>
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-4 space-y-8">
          {/* Table of Contents */}
          <TableOfContents content={article.content} />

          {/* Sidebar Advertisement */}
          <AdSlot type="sidebar" />

          {/* Related Articles */}
          {related.length > 0 && (
            <div className="rounded-2xl bg-white border border-[#e2e8f0] p-6 shadow-xs">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#0b1528] mb-4">
                Related {category?.name || 'Guides'}
              </h4>
              <div className="space-y-4 divide-y divide-[#f1f5f9]">
                {related.map((item, idx) => (
                  <div key={item.id} className={idx > 0 ? 'pt-4' : ''}>
                    <Link
                      to={`/blog/${item.slug}`}
                      className="group block space-y-1"
                    >
                      <h5 className="text-xs font-bold text-[#1e293b] group-hover:text-[#0062ff] transition-colors line-clamp-2 leading-snug">
                        {item.title}
                      </h5>
                      <span className="text-[11px] text-[#94a3b8]">
                        {formatDate(item.published_at)} · {item.reading_time} min read
                      </span>
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          )}
        </aside>
      </div>
    </article>
  );
}
