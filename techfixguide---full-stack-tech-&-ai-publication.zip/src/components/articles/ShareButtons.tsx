import React, { useState } from 'react';
import { Share2, Check, Copy, Twitter, Linkedin } from 'lucide-react';

interface ShareButtonsProps {
  title: string;
  url: string;
}

export function ShareButtons({ title, url }: ShareButtonsProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const tweetUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
    title
  )}&url=${encodeURIComponent(url)}&via=TechFixGuide`;

  const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
    url
  )}`;

  return (
    <div className="flex items-center gap-2">
      <span className="text-xs font-semibold text-[#64748b] mr-1 flex items-center gap-1">
        <Share2 className="w-3.5 h-3.5" />
        Share
      </span>

      <a
        href={tweetUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on X / Twitter"
        className="w-8 h-8 rounded-lg bg-[#f1f5f9] text-[#0b1528] hover:bg-[#0062ff] hover:text-white flex items-center justify-center transition-colors"
      >
        <Twitter className="w-4 h-4" />
      </a>

      <a
        href={linkedinUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on LinkedIn"
        className="w-8 h-8 rounded-lg bg-[#f1f5f9] text-[#0b1528] hover:bg-[#0062ff] hover:text-white flex items-center justify-center transition-colors"
      >
        <Linkedin className="w-4 h-4" />
      </a>

      <button
        onClick={handleCopy}
        aria-label="Copy link to clipboard"
        className="px-2.5 h-8 rounded-lg bg-[#f1f5f9] text-[#0b1528] hover:bg-slate-200 flex items-center gap-1.5 text-xs font-semibold transition-colors"
      >
        {copied ? (
          <>
            <Check className="w-3.5 h-3.5 text-emerald-600" />
            <span className="text-emerald-700">Copied!</span>
          </>
        ) : (
          <>
            <Copy className="w-3.5 h-3.5" />
            <span>Copy</span>
          </>
        )}
      </button>
    </div>
  );
}
