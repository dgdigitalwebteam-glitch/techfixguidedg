import React, { useState } from 'react';
import { useAppStore, AppStore } from '../../lib/store';
import { formatFileSize, formatDate } from '../../lib/utils';
import { Upload, Search, Trash2, Copy, Check, Image as ImageIcon, Plus } from 'lucide-react';

export function AdminMediaPage() {
  const { media } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Filter media by search name or alt text
  const filteredMedia = media.filter(
    (m) =>
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.alt_text.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCopy = (id: string, url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Delete media asset "${name}" from storage?`)) {
      AppStore.deleteMediaItem(id);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // File validation: Size limit 5MB
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('File exceeds maximum 5MB size limit.');
      return;
    }

    if (!file.type.startsWith('image/')) {
      setUploadError('Only image files (JPEG, PNG, WebP, SVG) are permitted.');
      return;
    }

    setIsUploading(true);
    setUploadError(null);

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      AppStore.addMediaItem({
        name: file.name,
        url: dataUrl,
        size: file.size,
        mime_type: file.type,
        alt_text: file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '),
      });
      setIsUploading(false);
      e.target.value = '';
    };
    reader.onerror = () => {
      setUploadError('Failed to read file.');
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6 max-w-6xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
            Media Library & Storage
          </h1>
          <p className="text-xs text-[#64748b]">
            Manage technical diagrams, screenshots, and article header assets.
          </p>
        </div>

        {/* Upload Button */}
        <label className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] cursor-pointer shadow-xs">
          <Upload className="w-4 h-4" />
          <span>{isUploading ? 'Uploading to Storage...' : 'Upload Media Asset'}</span>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </label>
      </div>

      {uploadError && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl">
          {uploadError}
        </div>
      )}

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-[#e2e8f0] shadow-xs flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            placeholder="Search media by filename or alt text..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-[#cbd5e1] pl-9 pr-3 py-2 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
          />
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
        </div>
        <div className="text-xs text-[#64748b]">
          {filteredMedia.length} assets registered
        </div>
      </div>

      {/* Media Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredMedia.map((item) => (
          <div
            key={item.id}
            className="group bg-white rounded-2xl border border-[#e2e8f0] overflow-hidden shadow-xs flex flex-col justify-between hover:border-[#0062ff] transition-all"
          >
            <div className="relative aspect-[16/10] bg-slate-100 overflow-hidden">
              <img
                src={item.url}
                alt={item.alt_text}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-2 left-2 text-[10px] bg-[#0b1528]/80 text-white px-2 py-0.5 rounded font-mono">
                {formatFileSize(item.size)}
              </span>
            </div>

            <div className="p-3.5 space-y-2 flex-1 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-bold text-[#0b1528] truncate" title={item.name}>
                  {item.name}
                </h4>
                <p className="text-[11px] text-[#64748b] truncate mt-0.5" title={item.alt_text}>
                  Alt: {item.alt_text}
                </p>
                <div className="text-[10px] text-[#94a3b8] mt-1">
                  {formatDate(item.created_at)}
                </div>
              </div>

              <div className="pt-2 border-t border-[#f1f5f9] flex items-center justify-between text-xs">
                <button
                  onClick={() => handleCopy(item.id, item.url)}
                  className="inline-flex items-center gap-1 text-[#0062ff] hover:underline font-semibold"
                >
                  {copiedId === item.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy URL</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => handleDelete(item.id, item.name)}
                  className="text-slate-400 hover:text-red-600 p-1 rounded"
                  title="Delete asset"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredMedia.length === 0 && (
        <div className="p-16 text-center rounded-2xl bg-white border border-[#e2e8f0] text-xs text-[#64748b]">
          No media files match your search query.
        </div>
      )}
    </div>
  );
}
