import React from 'react';
import { Link } from 'react-router-dom';
import { useAppStore } from '../lib/store';
import { ArrowLeft, Shield } from 'lucide-react';

export function AdsTxtPage() {
  const { adSettings } = useAppStore();

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-[#0b1528]">Google AdSense / ads.txt Directive</h1>
        <Link to="/" className="text-xs text-[#0062ff] font-semibold flex items-center gap-1">
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Home
        </Link>
      </div>
      <p className="text-xs text-[#64748b]">
        Authorized Digital Sellers verification record configured dynamically via the Admin CMS.
      </p>
      <pre className="p-4 rounded-xl bg-[#0b1528] text-amber-300 font-mono text-xs overflow-x-auto border border-[#1e2c45]">
        {adSettings.ads_txt_content}
      </pre>
      <div className="text-xs text-[#64748b] flex items-center gap-2">
        <Shield className="w-3.5 h-3.5 text-[#0062ff]" />
        <span>This directive is monitored and validated against your AdSense publisher account ID ({adSettings.publisher_id}).</span>
      </div>
    </div>
  );
}
