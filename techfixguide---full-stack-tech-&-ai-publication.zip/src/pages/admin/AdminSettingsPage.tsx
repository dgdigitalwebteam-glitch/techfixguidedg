import React, { useState, useEffect } from 'react';
import { useAppStore, AppStore } from '../../lib/store';
import { SiteSettings } from '../../types';
import { Sliders, Save, CheckCircle2, RotateCcw, Download, ShieldCheck } from 'lucide-react';

export function AdminSettingsPage() {
  const { siteSettings } = useAppStore();
  const [settings, setSettings] = useState<SiteSettings>({ ...siteSettings });
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    setSettings({ ...siteSettings });
  }, [siteSettings]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    AppStore.saveSiteSettings(settings);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleExportJSON = () => {
    const backup = {
      exportedAt: new Date().toISOString(),
      articles: AppStore.getArticles(),
      categories: AppStore.getCategories(),
      authors: AppStore.getAuthors(),
      media: AppStore.getMedia(),
      subscribers: AppStore.getSubscribers(),
      adSettings: AppStore.getAdSettings(),
      siteSettings: AppStore.getSiteSettings(),
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `techfixguide-full-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResetDemo = () => {
    if (
      confirm(
        'Reset publication to initial seed content? This will restore the 3 featured articles, 9 categories, 6 drafts, and sample records.'
      )
    ) {
      AppStore.resetToDefault();
      setSettings(AppStore.getSiteSettings());
      alert('Publication database restored to pristine initial seed state.');
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
        <div>
          <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
            Publication Settings
          </h1>
          <p className="text-xs text-[#64748b]">
            Configure global metadata, canonical domain, editorial email, and platform backups.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] shadow-xs"
        >
          <Save className="w-4 h-4" />
          Save Settings
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>Site settings have been updated and broadcast across the publication.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
            Brand Identity & Meta
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Publication Name
              </label>
              <input
                type="text"
                required
                value={settings.site_name}
                onChange={(e) => setSettings({ ...settings, site_name: e.target.value })}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Tagline
              </label>
              <input
                type="text"
                required
                value={settings.site_tagline}
                onChange={(e) => setSettings({ ...settings, site_tagline: e.target.value })}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Site Description (SEO & OpenGraph)
              </label>
              <textarea
                rows={2}
                value={settings.site_description}
                onChange={(e) => setSettings({ ...settings, site_description: e.target.value })}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Canonical Site URL
              </label>
              <input
                type="url"
                required
                value={settings.site_url}
                onChange={(e) => setSettings({ ...settings, site_url: e.target.value })}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Editorial Contact Email
              </label>
              <input
                type="email"
                required
                value={settings.support_email}
                onChange={(e) => setSettings({ ...settings, support_email: e.target.value })}
                className="w-full rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>
          </div>
        </div>

        {/* Discussions & Pagination */}
        <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
            Discussion & Layout Parameters
          </h3>

          <div className="space-y-4">
            <label className="flex items-center gap-3 text-xs font-bold text-[#0b1528] cursor-pointer">
              <input
                type="checkbox"
                checked={settings.comments_enabled_globally}
                onChange={(e) =>
                  setSettings({ ...settings, comments_enabled_globally: e.target.checked })
                }
                className="w-4 h-4 rounded text-[#0062ff]"
              />
              Enable Reader Comments Globally across Articles
            </label>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                Articles Per Pagination Page
              </label>
              <input
                type="number"
                min={2}
                max={24}
                value={settings.posts_per_page}
                onChange={(e) =>
                  setSettings({ ...settings, posts_per_page: parseInt(e.target.value) || 6 })
                }
                className="w-32 rounded-xl border border-[#cbd5e1] p-2.5 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
              />
            </div>
          </div>
        </div>

        {/* Backup & Seed Management */}
        <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#0b1528]">
            Database Operations & Disaster Recovery
          </h3>

          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={handleExportJSON}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#cbd5e1] bg-white text-xs font-bold text-[#0b1528] hover:bg-[#f8fafc] shadow-xs"
            >
              <Download className="w-4 h-4 text-[#0062ff]" />
              Download Full JSON Database Backup
            </button>

            <button
              type="button"
              onClick={handleResetDemo}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-red-200 bg-red-50 text-xs font-bold text-red-700 hover:bg-red-100"
            >
              <RotateCcw className="w-4 h-4" />
              Reset Database to Initial Sample Seed
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
