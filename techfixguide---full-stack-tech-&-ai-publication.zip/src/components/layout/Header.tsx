import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Logo } from '../ui/Logo';
import { useAppStore } from '../../lib/store';
import { Search, Menu, X, Shield, ArrowRight } from 'lucide-react';

const TOP_CATEGORIES = [
  { name: 'All Guides', href: '/blog' },
  { name: 'Artificial Intelligence', href: '/category/artificial-intelligence' },
  { name: 'Web Dev', href: '/category/web-development' },
  { name: 'Cybersecurity', href: '/category/cybersecurity' },
  { name: 'Free Tools', href: '/category/free-online-tools' },
  { name: 'Tech Tutorials', href: '/category/tech-tutorials' },
];

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const { auth } = useAppStore();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#e2e8f0] bg-white/95 backdrop-blur-md transition-all">
      {/* Top Editorial Bar */}
      <div className="hidden md:block bg-[#0b1528] text-white text-[11px] py-1.5 px-4 font-medium tracking-wide">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3 text-slate-300">
            <span className="font-bold text-[#0062ff] uppercase tracking-wider text-[10px]">Verified Signal</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Peer-reviewed technical blueprints, zero AI slop, verified code runtimes.</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <Link to="/about" className="hover:text-white transition-colors">Editorial Standards</Link>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <Link to="/contact" className="hover:text-white transition-colors">Submit Fix or Story</Link>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <Link to={auth.isAuthenticated ? "/admin" : "/admin/login"} className="flex items-center gap-1.5 text-slate-200 hover:text-[#0062ff] transition-colors font-semibold">
              <Shield className="w-3 h-3 text-[#0062ff]" />
              {auth.isAuthenticated ? 'CMS Admin Panel' : 'Staff Login'}
            </Link>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
        <Logo />

        {/* Desktop Navigation Links (Text with hover underlines, zero pill capsules) */}
        <nav className="hidden lg:flex items-center gap-7">
          {TOP_CATEGORIES.map((cat) => (
            <Link
              key={cat.name}
              to={cat.href}
              className="text-sm font-semibold text-[#1e293b] hover:text-[#0062ff] transition-colors py-1 relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-[#0062ff] hover:after:w-full after:transition-all"
            >
              {cat.name}
            </Link>
          ))}
        </nav>

        {/* Search Bar */}
        <div className="hidden md:flex items-center gap-3 flex-1 max-w-xs ml-4">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <input
              type="text"
              placeholder="Search guides, fixes, code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-[#cbd5e1] bg-[#f8fafc] pl-9 pr-4 py-2 text-xs text-[#0b1528] placeholder-[#94a3b8] focus:outline-none focus:border-[#0062ff] focus:bg-white transition-all shadow-xs"
            />
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
          </form>
        </div>

        {/* Right CTA */}
        <div className="flex items-center gap-3">
          <Link
            to={auth.isAuthenticated ? "/admin" : "/admin/login"}
            className="hidden sm:inline-flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border border-[#cbd5e1] bg-white text-[#0b1528] hover:border-[#0062ff] hover:text-[#0062ff] transition-all shadow-xs"
          >
            <Shield className="w-3.5 h-3.5 text-[#0062ff]" />
            {auth.isAuthenticated ? 'Admin CMS' : 'Editor Access'}
          </Link>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#0b1528] lg:hidden rounded-lg hover:bg-[#f1f5f9]"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#e2e8f0] bg-white px-4 pt-4 pb-6 space-y-4 shadow-xl">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <input
              type="text"
              placeholder="Search tutorials, code, fixes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-[#cbd5e1] bg-[#f8fafc] pl-10 pr-4 py-2.5 text-sm text-[#0b1528]"
            />
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3.5 top-3.5" />
          </form>

          <div className="flex flex-col space-y-1">
            {TOP_CATEGORIES.map((cat) => (
              <Link
                key={cat.name}
                to={cat.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 text-sm font-semibold text-[#1e293b] hover:bg-[#f8fafc] rounded-lg flex items-center justify-between"
              >
                <span>{cat.name}</span>
                <ArrowRight className="w-4 h-4 text-[#94a3b8]" />
              </Link>
            ))}
            <div className="pt-3 border-t border-[#f1f5f9] flex flex-col space-y-2">
              <Link
                to={auth.isAuthenticated ? "/admin" : "/admin/login"}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 text-sm font-bold text-[#0062ff] hover:bg-[#eff6ff] rounded-lg flex items-center gap-2"
              >
                <Shield className="w-4 h-4" />
                {auth.isAuthenticated ? 'Open Admin CMS Dashboard' : 'Editor Staff Login'}
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
