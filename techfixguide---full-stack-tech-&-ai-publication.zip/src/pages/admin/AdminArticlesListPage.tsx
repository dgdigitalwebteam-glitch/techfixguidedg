import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useAppStore, AppStore } from '../../lib/store';
import { formatDate } from '../../lib/utils';
import {
  PlusCircle,
  Search,
  Filter,
  Trash2,
  Edit,
  ExternalLink,
  Eye,
  CheckCircle,
  Clock,
  Archive,
} from 'lucide-react';

export function AdminArticlesListPage() {
  const { articles, categories, authors } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredArticles = useMemo(() => {
    return articles.filter((art) => {
      const matchSearch =
        art.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        art.slug.toLowerCase().includes(searchTerm.toLowerCase());
      const matchStatus = selectedStatus === 'all' || art.status === selectedStatus;
      const matchCategory = selectedCategory === 'all' || art.category_id === selectedCategory;
      return matchSearch && matchStatus && matchCategory;
    });
  }, [articles, searchTerm, selectedStatus, selectedCategory]);

  const handleDelete = (id: string, title: string) => {
    if (confirm(`Are you sure you want to delete "${title}"? This cannot be undone.`)) {
      AppStore.deleteArticle(id);
    }
  };

  const togglePublishStatus = (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'published' ? 'draft' : 'published';
    AppStore.saveArticle({
      id,
      status: newStatus as any,
      published_at: newStatus === 'published' ? new Date().toISOString() : null,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-[#0b1528] tracking-tight">
            Article Management
          </h1>
          <p className="text-xs text-[#64748b]">
            Create, edit, schedule, or unpublish technical guides across your publication.
          </p>
        </div>

        <Link
          to="/admin/articles/new"
          className="inline-flex items-center gap-2 rounded-xl bg-[#0062ff] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#004ecc] shadow-xs"
        >
          <PlusCircle className="w-4 h-4" />
          Draft New Guide
        </Link>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 min-w-[240px]">
          <input
            type="text"
            placeholder="Search by title or slug..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-xl border border-[#cbd5e1] pl-9 pr-3 py-2 text-xs text-[#0b1528] focus:outline-none focus:border-[#0062ff]"
          />
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-[#64748b] font-medium">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 text-xs text-[#0b1528] bg-[#f8fafc]"
            >
              <option value="all">All ({articles.length})</option>
              <option value="published">
                Published ({articles.filter((a) => a.status === 'published').length})
              </option>
              <option value="draft">
                Drafts ({articles.filter((a) => a.status === 'draft').length})
              </option>
              <option value="scheduled">
                Scheduled ({articles.filter((a) => a.status === 'scheduled').length})
              </option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-[#64748b] font-medium">Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 text-xs text-[#0b1528] bg-[#f8fafc]"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Articles Table */}
      <div className="bg-white rounded-2xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#64748b] font-semibold border-b border-[#e2e8f0]">
              <tr>
                <th className="p-4">Title & Details</th>
                <th className="p-4">Category</th>
                <th className="p-4">Author</th>
                <th className="p-4">Status</th>
                <th className="p-4">Views</th>
                <th className="p-4">Date</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9] text-[#1e293b]">
              {filteredArticles.map((art) => {
                const category = categories.find((c) => c.id === art.category_id);
                const author = authors.find((a) => a.id === art.author_id);

                return (
                  <tr key={art.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="p-4 max-w-sm">
                      <div className="font-bold text-[#0b1528] line-clamp-1 mb-0.5">
                        <Link
                          to={`/admin/articles/edit/${art.id}`}
                          className="hover:text-[#0062ff]"
                        >
                          {art.title}
                        </Link>
                      </div>
                      <div className="text-[11px] text-[#94a3b8] font-mono truncate">
                        /blog/{art.slug}
                      </div>
                    </td>

                    <td className="p-4 text-[#475569]">
                      {category?.name || '—'}
                    </td>

                    <td className="p-4 text-[#475569] font-medium">
                      {author?.full_name || 'Staff'}
                    </td>

                    <td className="p-4">
                      <button
                        onClick={() => togglePublishStatus(art.id, art.status)}
                        title="Click to toggle publish status"
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase transition-all ${
                          art.status === 'published'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                            : art.status === 'draft'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100'
                            : 'bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100'
                        }`}
                      >
                        {art.status}
                      </button>
                    </td>

                    <td className="p-4 text-[#64748b]">
                      {art.view_count.toLocaleString()}
                    </td>

                    <td className="p-4 text-[#64748b]">
                      {formatDate(art.published_at || art.created_at)}
                    </td>

                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link
                          to={`/admin/articles/edit/${art.id}`}
                          className="p-1.5 text-slate-500 hover:text-[#0062ff] hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit Guide"
                        >
                          <Edit className="w-4 h-4" />
                        </Link>

                        {art.status === 'published' && (
                          <Link
                            to={`/blog/${art.slug}`}
                            target="_blank"
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            title="View on Live Site"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Link>
                        )}

                        <button
                          onClick={() => handleDelete(art.id, art.title)}
                          className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Article"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredArticles.length === 0 && (
          <div className="p-12 text-center text-xs text-[#64748b]">
            No articles match your current search and filter criteria.
          </div>
        )}
      </div>
    </div>
  );
}
